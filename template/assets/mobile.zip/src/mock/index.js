import Mock from 'mockjs'

// user相关数据
import userData from '@/framework/mock/user-data'

// 角色权限列表数据 /userInfo/myRole
import roleData from './role-data'

Mock.setup({
  timeout: 800 // 设置延迟响应，模拟向后端请求数据
})

const mockArr = [
  ...userData,
  ...roleData
]
console.log(mockArr)
mockArr.forEach(ele => {
  Mock.mock(ele.url, ele.method, ele.data)
})

/**
 * mock数据示例
 */
Mock.mock(RegExp('/request/path' + '.*'), 'get', {
  'errcode': 200,
  'errmsg': '',
  'data': {
    'id': '@id',
    'name': '@cname'
  }
})
