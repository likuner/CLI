/**
 * 国际化 英文
 * 请勿删除该文件
 */
export default {
  /* error: {
    test: 'test'
  } */
}
