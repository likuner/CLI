/**
 * 国际化 中文
 * 请勿删除该文件
 */
export default {
  /* error: {
    test: '测试'
  } */
}