import Vue from 'vue'
// 1.Tabbar
import { Tabbar, TabbarItem } from 'vant'
Vue.use(Tabbar).use(TabbarItem)
import { Icon } from 'vant'
Vue.use(Icon)
// 搜索框
import { Search } from 'vant'

Vue.use(Search)

//文字提示
import { Toast } from 'vant'

Vue.use(Toast)
//下拉刷新+长列表
import { PullRefresh, List } from 'vant'
Vue.use(PullRefresh).use(List)
// 输入框
import { Field } from 'vant'

Vue.use(Field)
//Rate评分
import { Rate } from 'vant'

Vue.use(Rate)
//按钮
import { Button } from 'vant'

Vue.use(Button)
// pop弹层
import { Popup } from 'vant'

Vue.use(Popup)
//时间选择
import { DatetimePicker } from 'vant'

Vue.use(DatetimePicker)
//进度条
import { Progress } from 'vant'

Vue.use(Progress)
//Picker选择器
import { Picker } from 'vant'

Vue.use(Picker)
//checkbox复选框
import { Checkbox, CheckboxGroup } from 'vant'

Vue.use(Checkbox)
Vue.use(CheckboxGroup)
//Radio单选框
import { RadioGroup, Radio } from 'vant'
Vue.use(Radio)
Vue.use(RadioGroup)
//Dialog 弹出框
import { Dialog } from 'vant'
Vue.use(Dialog)
//倒计时
import { CountDown } from 'vant'
Vue.use(CountDown)

// 图片
import { Image as VanImage } from 'vant'
Vue.use(VanImage)

// loading
import { Loading } from 'vant'
Vue.use(Loading)
