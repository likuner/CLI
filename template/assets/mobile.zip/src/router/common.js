import { notInlanxin, errorLisence, noNetwork, page401, page403, page404, page500, feedback } from '@/framework/pages'

export const commonRouter = [
  {
    path: '/feedback/index',
    name: 'feedback',
    component: feedback
  },
  {
    path: '/error/not-in-lanxin',
    name: 'not-in-lanxin',
    component: notInlanxin
  },
  {
    path: '/error/lisence',
    name: 'error-lisence',
    component: errorLisence
  },
  {
    path: '/error/401',
    name: 'page401',
    component: page401
  },
  {
    path: '/error/403',
    name: 'page403',
    component: page403
  },
  {
    path: '/error/404',
    name: 'page404',
    component: page404
  },
  {
    path: '/error/500',
    name: 'page500',
    component: page500
  },
  {
    path: '/error/no-network',
    name: 'no-network',
    component: noNetwork
  },
  {
    path: '*',
    redirect: '/error/404'
  }
]
