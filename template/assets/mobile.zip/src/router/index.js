import Vue from 'vue'
import Router from 'vue-router'
import { commonRouter } from './common'

Vue.use(Router)

const routes = [
  // 根路径
  {
    path: '/',
    redirect: '/home'
  },
  {
    path: '/home',
    name: 'home',
    component: () => import('@/pages/home')
  },
  ...commonRouter /* 必须添加且必须在最后 */
]

export default new Router({
  routes,
  strict: false
})
