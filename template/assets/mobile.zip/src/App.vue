<template>
  <div id="app">
    <lx-loading msg="页面加载中..." v-if="!loaded"></lx-loading>
    <keep-alive :include="includecomponents">
      <router-view
        v-show="loaded"
        @hook:created="loaded = true"
      />
    </keep-alive>

  </div>
</template>

<script>
import { report } from './framework/service/track-service'
import LxLoading from '@/framework/components/lx-loading'

export default {
  name: 'app',
  data() {
    return {
      loaded: false
    }
  },
  components: {
    [LxLoading.name]: LxLoading
  },
  created() {
    // 前端打点
    setTimeout(() => { report({ taskType: 'page-performance', expand: { performance: window.performance }}) }, 5000)
    const trackReport = () => report({ taskType: 'page-leave' }, true)
    window.addEventListener('beforeunload', trackReport)
    this.$once('hook:beforeDestory', () => {
      window.removeEventListener('beforeunload', trackReport)
    })
  },
  computed: {
    includecomponents() {
      return this.$store.getters.cachedPages
    }
  }
}
</script>
