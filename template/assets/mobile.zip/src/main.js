import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import './router-interceptor'
import './framework/index'
import '@/style/common.scss'
import '@/style/reset.scss'

// 全局引入UI库 vant
import './plugins/vant'

import '@/mock'
Vue.config.productionTip = false

new Vue({
  render: h => h(App),
  router,
  store
}).$mount('#app')
