import router from '@/router'
import store from '@/store'
import { report } from '@/framework/service/track-service'
import { deepGet, getQueryParams } from '@/framework/utils/common'
import { inLanxin } from '@/framework/utils/dev'

const defaultPowerType = getQueryParams('powerType')
const defaultPowerCode = getQueryParams('powerCode')

const whiteList = ['page401', 'page403', 'page404', 'no-network', 'not-in-lanxin', 'error-lisence']
router.beforeEach(async(to, from, next) => {
  console.log(to)

  // 验证是否在白名单内
  if (whiteList.indexOf(to.name) > -1) {
    return next()
  }
  // navigator.onLine不稳定 模板工程中先删除该判定
  // if (!navigator.onLine) {
  //   return next({ name: 'no-network' })
  // }

  //验证是否在蓝信宿主环境内（只验证正式发布版本）
  if (process.env.NODE_ENV === 'production' && !inLanxin) {
    return next({ name: 'not-in-lanxin' })
  }

  // 获取token
  const token = store.getters.token || await store.dispatch('user/login')

  // 判断用户身份是否合法
  if (!token) {
    //登录失败，跳转错误页面
    return next({ name: 'page401', replace: true })
  }

  // 切换到默认角色
  if (!store.getters.currentRole &&
    defaultPowerType &&
    defaultPowerCode &&
    !await store.dispatch('user/setCurrentRole', { powerCode: defaultPowerCode, powerType: defaultPowerType })
  ) {
    return next({ path: '/error/403', replace: true })
  }

  // lisence过期（本地开发环境不生效）
  if (process.env.NODE_ENV === 'production' && deepGet(store, 'getters.lisence.status') !== 1) {
    return next({ name: 'error-lisence', replace: true })
  }

  // 通过所有验证，跳转页面
  return next()
})

router.afterEach((to) => {
  // 行为记录
  report({ actionName: 'see', dataSource: 'framework', taskType: 'route-change', expand: to.meta })
})

