/**
 * framework组件国际化 zh
 */
export default {
}
