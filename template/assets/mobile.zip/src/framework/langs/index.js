import Vue from 'vue'
import VueI18n from 'vue-i18n'
import { Locale } from 'vant'
import VantEnUSLocale from 'vant/lib/locale/lang/en-US'
import VantZhCNLocale from 'vant/lib/locale/lang/zh-CN'
import enLocale from '@/langs/en'
import zhLocale from '@/langs/zh'
import frameworkEnLocale from './en'
import frameworkZhLocale from './zh'

Vue.use(VueI18n)

const messages = {
  en: {
    ...enLocale,
    ...VantEnUSLocale,
    ...frameworkEnLocale
  },
  zh: {
    ...zhLocale,
    ...VantZhCNLocale,
    ...frameworkZhLocale
  }
}
export function getDefaultLanguage() {
  const language = (navigator.language || navigator.browserLanguage).toLowerCase()
  const locales = Object.keys(messages)
  for (const locale of locales) {
    if (language.indexOf(locale) > -1) {
      return locale
    }
  }
  return 'zh'
}

export function changeLanguage(language) {
  if (language === 'en') {
    Locale.use(language, VantEnUSLocale)
  } else {
    Locale.use(language, VantZhCNLocale)
  }
}

export const i18n = new VueI18n({
  locale: getDefaultLanguage(),
  messages
})
