/**
 * framework组件国际化 en
 */
export default {
}
