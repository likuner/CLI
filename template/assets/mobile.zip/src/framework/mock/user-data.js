const userLogIn = {
  url: RegExp('/user/testLogIn' + '.*'),
  method: 'post',
  data: {
    'errcode': 200,
    'errmsg': '成功',
    data: {
      'expiresIn': 1800,
      'token': 'test-59d76473-9aa4-4bd8-945e-d6ee2218b8ad',
      'staffId': '@id',
      'name': '张飞',
      'licenseCheckInfo': { 'status': 1, 'desc': null, 'licenseEndTime': 4102444800000, 'remainingDays': 99999 }
    }
  }
}

const testLogin = {
  url: RegExp('/user/login' + '.*'),
  method: 'post',
  data: {
    'errcode': 200,
    'errmsg': '成功',
    'data': {
      'expiresIn': 1800,
      'token': 'test-59d76473-9aa4-4bd8-945e-d6ee2218b8ad',
      'staffId': '@id',
      'name': '张飞',
      'licenseCheckInfo': { 'status': 1, 'desc': null, 'licenseEndTime': 4102444800000, 'remainingDays': 99999 }
    }
  }
}

const userDetailInfo = {
  url: RegExp('/user/getUserInfo' + '.*'),
  method: 'get',
  data: {
    'errcode': 200,
    'errmsg': '成功',
    'data': {
      'staffId': '11232000-K2uLeSRDVLYVIPPelPmcJKazehPoReK5',
      'orgId': '11232000',
      'orgName': '应用联调测试组织',
      'name': '冯成雪',
      'loginName': null,
      'employeeNumber': null,
      'gender': 0,
      'avatarId': null,
      'avatarUrl': null,
      'email': null,
      'signature': null,
      'nationality': null,
      'birthdate': '1970-01-01',
      'mobilePhone': {
        'countryCode': '86',
        'number': '18501130598'
      },
      'extraPhones': null,
      'introduction': null,
      'education': null,
      'career': null,
      'departments': [{
        'id': '11232000-jzuJwIPVXKKvF00Gk0EFoDYrlHnz9PW',
        'structUniId': '11232000-jzuJwIPVXKKvF00Gk0EFoDYrlHnz9PW',
        'level': 2,
        'code': '11232000|11232000-Wyuagta8y7LhGGazGpcOaKYLHmn',
        'queryCode': '11232000|11232000-Wyuagta8y7LhGGazGpcOaKYLHmn|11232000-jzuJwIPVXKKvF00Gk0EFoDYrlHnz9PW',
        'path': '应用联调测试组织-应用研发部',
        'orgId': null,
        'name': '应用研发部',
        'parentId': '11232000-Wyuagta8y7LhGGazGpcOaKYLHmn',
        'orderNumber': 0,
        'order': 10,
        'tagList': null,
        'inactiveMembers': 1,
        'normalMembers': 41,
        'frozenMembers': 0,
        'deletedMembers': 0,
        'membersCount': null,
        'ancestorDepartments': [{
          'id': '11232000-Wyuagta8y7LhGGazGpcOaKYLHmn',
          'structUniId': null,
          'level': null,
          'code': null,
          'queryCode': null,
          'path': null,
          'orgId': null,
          'name': '应用联调测试组织',
          'parentId': null,
          'orderNumber': null,
          'order': 0,
          'tagList': null,
          'inactiveMembers': null,
          'normalMembers': null,
          'frozenMembers': null,
          'deletedMembers': null,
          'membersCount': null,
          'ancestorDepartments': null,
          'hasChildren': null,
          'isLeaf': null
        }],
        'hasChildren': true,
        'isLeaf': false
      }],
      'tagList': null,
      'status': 1,
      'extraFieldSet': null,
      'department': null,
      'path': null,
      'code': null,
      'queryCode': null,
      'idNumber': null,
      'nativePlace': null,
      'parties': null,
      'duties': null,
      'mobile': '18501130598',
      'maskMobile': '185****0598'
    }
  }
}

export default [
  userLogIn,
  testLogin,
  userDetailInfo
]
