const successResult = {
  'errcode': 200,
  'errmsg': '成功',
  'data': null
}

const cmcList = {
  url: RegExp('/cmc/list' + '.*'),
  method: 'get',
  data: {
    'errcode': 200,
    'errmsg': '成功',
    'data': {
      'current': 1,
      'orders': [],
      'pages': 1,
      'result': [{
        'cmcName': 'CMC名称1',
        'id': 19,
        'manageScopes': [{
          'id': 22,
          'objId': '3064064-DGtRHJ6Do9tDqOr77t6gE7RK@3064064',
          'objName': '蓝图对接测试组织',
          'type': 2
        }, {
          'id': 23,
          'objId': '3064064-jetwtPyePp3fAKMvYYIO0ExAHW7y@3064064',
          'objName': '新蓝信蓝图对接组',
          'type': 2
        }, {
          'id': 24,
          'objId': '3064064-E5tjaSbr85OKH5AzVmmfkkjycVMrnW@3064064',
          'objName': '马晓烨',
          'type': 1
        }, {
          'id': 25,
          'objId': '3064064-zGt7jCp7j98et8wyK77FaaXkHDJ2M5@3064064',
          'objName': '郑鹏飞',
          'type': 1
        }],
        'managers': [{
          'id': 17,
          'objId': '3064064-E5tjaSbr85OKH5AzVmmfkkjycVMrnW@3064064',
          'objName': '马晓烨',
          'type': 1
        }]
      }, {
        'cmcName': 'CMC名称2',
        'id': 16,
        'manageScopes': [{
          'id': 12,
          'objId': '3064064-DGtRHJ6Do9tDqOr77t6gE7RK@3064064',
          'objName': '蓝图对接测试组织',
          'type': 2
        }],
        'managers': [{
          'id': 14,
          'objId': '3064064-E5tjaSbr85OKH5AzVmmfkkjycVMrnW@3064064',
          'objName': '马晓烨',
          'type': 1
        }]
      }],
      'searchCount': true,
      'size': 10,
      'total': 2
    }
  }
}

const cmcAdd = {
  url: RegExp('/cmc/add' + '.*'),
  method: 'post',
  data: successResult
}

const cmcUpdate = {
  url: RegExp('/cmc/update' + '.*'),
  method: 'post',
  data: successResult
}

const cmcDelete = {
  url: RegExp('/cmc/delete' + '.*'),
  method: 'post',
  data: successResult
}

export default [
  cmcList,
  cmcAdd,
  cmcUpdate,
  cmcDelete
]
