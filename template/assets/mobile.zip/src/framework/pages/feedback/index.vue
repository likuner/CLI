<template>
  <div class="feedback lx-page">
    <titlebar title="关于"></titlebar>
    <div class="lx-container">
      <van-cell title="日志上传" is-link @click="uploadLog" style="margin-top: 10px;" />
    </div>
  </div>
</template>

<script>
import { uploadFileToServer, getResourceUrl } from '@/framework/service/file-service'
import { Dialog, Toast, Cell } from 'vant'
import TitleBar from '@/framework/components/titlebar'
import ClipboardJS from 'clipboard'
export default {
  data() {
    return {
      clipboard: null
    }
  },
  components: {
    [TitleBar.name]: TitleBar,
    [Cell.name]: Cell
  },
  beforeDestroy() {
    if (this.clipboard) {
      this.clipboard = null
      this.clipboard.destory()
    }
  },
  methods: {
    async uploadLog() {
      if (this.clipboard) {
        this.clipboard = null
        this.clipboard.destory()
      }
      let toast = null
      try {
        toast = Toast.loading({
          duration: 0, // 持续展示 toast
          forbidClick: true,
          message: '上传中...'
        })
        const logFile = await window.yflog.getLogFile()
        const result = await uploadFileToServer(logFile)
        toast.clear()
        if (result && result.resourceId) {
          Dialog.confirm({
            title: '提示',
            message: `本地日志上传成功，请将复制日志地址【${getResourceUrl(result.resourceId)}】并发送给蓝信技术人员。`,
            confirmButtonText: '复制链接'
          }).then(() => {
            this.clipboard = new ClipboardJS('.van-dialog__confirm', {
              text: () => getResourceUrl(result.resourceId)
            })
            this.clipboard.on('success', () => {
              Toast.success('复制成功')
            })
            this.clipboard.on('error', () => {
              Toast.fail('复制失败')
            })
          })
        }
      } catch (e) {
        toast.clear()
        Toast.fail('日志上传失败')
      }
    }
  }
}
</script>
