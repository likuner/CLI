import notInlanxin from './error/not-in-lanxin'
import errorLisence from './error/lisence'
import noNetwork from './error/no-network'
import page401 from './error/page401'
import page403 from './error/page403'
import page404 from './error/page404'
import page500 from './error/page500'
import feedback from './feedback/index'

export default {
  notInlanxin,
  errorLisence,
  noNetwork,
  page401,
  page403,
  page404,
  page500,
  feedback
}
export {
  notInlanxin,
  errorLisence,
  noNetwork,
  page401,
  page403,
  page404,
  page500,
  feedback
}
