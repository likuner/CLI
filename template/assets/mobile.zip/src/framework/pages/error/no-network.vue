<template>
  <div class="no-network lx-page">
    <div class="lx-container">
      <titlebar></titlebar>
      <img :src="require('@/framework/assets/images/no-network.png')" @click="retry"/>
      <label>哎呀，没有网了……</label>
    </div>
  </div>
</template>
<script>
import Titlebar from '@/framework/components/titlebar'
export default {
  name: 'no-network',
  data() {
    return {}
  },
  components: {
    Titlebar
  },
  methods: {
    retry() {
      this.$router.push('/')
    }
  }
}
</script>
<style scoped lang="scss">
.no-network {
  text-align: center;
  img {
    width: 140px;
    margin: 130px auto 40px;
    display: block;
    cursor: pointer;
  }
  label {
    font-size: 14px;
    color: #9b9fab;
    text-align: center;
  }
}
</style>
