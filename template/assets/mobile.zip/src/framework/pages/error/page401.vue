<template>
  <div class="page401 lx-page">
    <div class="lx-container">
      <titlebar></titlebar>
      <img :src="require('@/framework/assets/images/lock.png')" @click="retry"/>
      <label>认证失败，点击页面重试！</label>
    </div>
  </div>
</template>
<script>
import Titlebar from '@/framework/components/titlebar'
export default {
  name: 'page401',
  data() {
    return {}
  },
  components: {
    Titlebar
  },
  methods: {
    retry() {
      this.$router.push('/')
    }
  }
}
</script>
<style scoped lang="scss">
.page401 {
  text-align: center;
  img {
    width: 140px;
    margin: 130px auto 40px;
    display: block;
    cursor: pointer;
  }
  label {
    font-size: 14px;
    color: #9b9fab;
    text-align: center;
  }
}
</style>
