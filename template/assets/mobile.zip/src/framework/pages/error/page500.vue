<template>
  <div class="page500 lx-page">
    <div class="lx-container">
      <titlebar></titlebar>
      <img :src="require('@/framework/assets/images/server-error.png')" />
      <label>哎呀，服务器出了点小问题……</label>
    </div>
  </div>
</template>
<script>
import Titlebar from '@/framework/components/titlebar'
export default {
  name: 'page500',
  data() {
    return {}
  },
  components: {
    Titlebar
  }
}
</script>
<style scoped lang="scss">
.page500 {
  text-align: center;
  img {
    width: 140px;
    margin: 130px auto 40px;
    display: block;
  }
  label {
    font-size: 14px;
    color: #9b9fab;
    text-align: center;
  }
}
</style>
