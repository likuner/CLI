<template>
  <div class="lisence lx-page">
    <div class="error-container">
      <div class="header">
        <img class="left-img" :src="require('@/framework/assets/images/whiteback.png')" @click="goBack"/>
        <div class="title">提示</div>
      </div>
      <div class="center">
        <img class="center-img" :src="require('@/framework/assets/images/nolisence.png')" />
        <div class="center-info">很抱歉，当前应用缺少许可文件，暂时无法使用，请联系蓝信管理员获取许可文件。</div>
      </div>
      <van-button type="info" class="bottom" :style="{'visibility': isExpansion ? 'hidden' : 'visible'}" @click="goBack">返回</van-button>
    </div>
  </div>
</template>
<script>
import { Button } from 'vant'
import { mapMutations } from 'vuex'
import { getQueryParams } from '@/framework/utils/common'

export default {
  name: 'lisence',
  data() {
    return {}
  },
  components: {
    [Button.name]: Button
  },
  computed: {
    isExpansion() {
      //应用是否在扩展屏
      return getQueryParams('entrance') === 'expand'
    }
  },
  created() {
    this.SET_TOKEN(null)
  },
  methods: {
    ...mapMutations('user', ['SET_TOKEN']),
    goBack() {
      window.lx.ui.closeWindow()
    }
  }
}
</script>
<style scoped lang="scss">
.error-container{
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  background: #FFFFFF;
  padding-bottom: constant(safe-area-inset-bottom);
  padding-bottom: env(safe-area-inset-bottom);
  .header{
    visibility: hidden;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 44px;
    font-size: 18px;
    color: #FFFFFF;
    background: #4E74BB;
    position: relative;
    box-sizing: content-box;
    padding-top: constant(safe-area-inset-top);
    padding-top: env(safe-area-inset-top);
    .left-img{
      width: 22px;
      height: 22px;
      position: absolute;
      z-index: 1;
      left: 16px;
      bottom: 10px;
    }
    .title{
      height: 44px;
      line-height: 44px;
      text-align: center;
      margin: 0 70px;
      font-weight: bold;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }
  .center{
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-bottom: 12vh;
    .center-img{
      width: 150px;
      height: 126.6px;
    }
    .center-info{
      font-size: 14px;
      color: #323233;
      line-height: 24px;
      text-align: center;
      margin: 10px 50px 0;
    }
  }
  .bottom{
    height: 44px;
    line-height: 44px;
    text-align: center;
    font-size: 14px;
    color: #FFFFFF;
    background: #5A8BE0;
    border-radius: 100px;
    margin: 0 16px 50px;
    border: 1px solid #5A8BE0;
  }
}
</style>
