<template>
  <div class="page404 lx-page">
    <div class="lx-container">
      <titlebar></titlebar>
      <img :src="require('@/framework/assets/images/404.png')" />
      <label>您要访问的资源已飞走！</label>
    </div>
  </div>
</template>
<script>
import Titlebar from '@/framework/components/titlebar'
export default {
  name: 'page401',
  data() {
    return {}
  },
  components: {
    Titlebar
  }
}
</script>
<style scoped lang="scss">
.page404 {
  text-align: center;
  img {
    width: 140px;
    margin: 130px auto 40px;
    display: block;
  }
  label {
    font-size: 14px;
    color: #9b9fab;
    text-align: center;
  }
}
</style>
