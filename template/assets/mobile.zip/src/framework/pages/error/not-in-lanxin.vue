<template>
  <div class="not-in-lanxin lx-page">
    <div class="lx-container">
      <div class="error-info">当前信息仅可在移动端查看</div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'not-in-lanxin',
  data: function() {
    return {}
  },
  components: {},
  /* 计算属性 */
  computed: {},
  /* 生命周期钩子 */
  created() {},
  mounted() {},
  /* 方法 */
  methods: {}
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.lx-container{
  display: flex;
  justify-content: center;
  align-items: center;
  background: #FFFFFF;
  .error-info{
    color: #909399;
    font-size: 18px;
    margin: 0 30px 15vh;
    text-align: center;
  }
}
</style>
