<template>
  <div class="page403 lx-page">
    <div class="lx-container">
      <titlebar></titlebar>
      <img :src="require('@/framework/assets/images/permission-denied.png')" />
      <label>啥都看不到！</label>
      <label>没有权限查看本信息</label>
    </div>
  </div>
</template>
<script>
import Titlebar from '@/framework/components/titlebar'
export default {
  name: 'page403',
  data() {
    return {}
  },
  components: {
    Titlebar
  }
}
</script>
<style scoped lang="scss">
.page403 {
  text-align: center;
  img {
    width: 140px;
    margin: 130px auto 40px;
    display: block;
  }
  label {
    display: block;
    font-size: 14px;
    color: #9b9fab;
    text-align: center;
  }
}
</style>
