/**
 * sdk的web实现 方便调试
 */
const LX = window.lx
/**
 * 模拟移动端获取authcode
 */
LX.biz.getAuthCode = function(/* options */) {
  return 'web-sdk-authcode'
}

LX.ready = function(cb) {
  setTimeout(() => {
    cb()
  }, 1000)
}

/**
 * config 错误回调
 */
LX.error = function(/* cb */) {

}

/**
 * config 成功的回调
 */
LX.config = function(/* options */) {
  setTimeout(() => {
    console.log(`[lanxin] config success`)
  }, 1000)
}

