import allFilters from '../filters'
export default {
  install: function(Vue) {
    allFilters.forEach(ele => {
      Vue.filter(ele.name, ele.value)
    })
  }
}
