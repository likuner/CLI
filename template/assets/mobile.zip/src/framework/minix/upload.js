import { deepClone, deepGet } from '@/framework/utils/common'
import { cancelUploadFile } from '@/framework/service/file-service'
export default {
  data() {
    return {
      // 资源数组
      list: [],
      // 资源加载
      resourceLoaded: false
    }
  },
  props: {
    /**
     * 最大数量
     */
    maxNum: {
      type: Number
    },
    /**
     * 文件最大大小 B
     */
    maxSize: {
      type: Number,
      default: 1024 * 1024 * 500
    },
    maxSizeErrorTip: {
      type: String,
      default: '您上传的文件超过限定的大小'
    },
    /**
     * 是否可用
     */
    disabled: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    /**
     * 当前文件数量
     */
    count() {
      return this.list ? this.list.length : 0
    },
    /**
     * 当前资源id数组
     */
    resourceIds() {
      return this.list.map(ele => {
        return deepGet(ele, 'resource.resourceId')
      })
    },
    /**
     * 是否可以添加新的资源
     */
    canAdd() {
      return !this.maxNum || this.count < this.maxNum
    },
    /**
     * 上传状态
     */
    uploadStatus() {
      const result = {
        total: this.list.length,
        uploaded: 0,
        error: 0,
        pending: 0
      }
      this.list.forEach(ele => {
        if (ele.status === 'uploaded') {
          result['uploaded']++
        } else if (ele.status === 'error') {
          result['error']++
        } else if (ele.status === 'pending') {
          result['pending']++
        }
      })
      return result
    }
  },
  methods: {
    // 获取上传状态
    getUploadStatus() {
      return this.uploadStatus
    },
    // 获取上传文件的resourceid列表
    getResourceIds() {
      return this.resourceIds
    },
    // 获取资源完整信息
    getList() {
      return deepClone(this.list)
    },
    // 清空资源列表
    clear() {
      if (this.list.length === 0) return
      // 取消文件上传
      this.list.forEach(file => {
        if (file.status === 'pending' && file.uploadTaskId) {
          cancelUploadFile(file.uploadTaskId)
        }
      })
      this.triggerUploadChange(this.list)
      // 清空资源列表
      this.list = []
    },
    triggerExceedMaxSize(target) {
      this.$emit('exceed-max-size', target)
    },
    triggerUploadChange(target) {
      this.$emit('upload-change',
        deepClone({
          status: this.uploadStatus,
          resourceIds: this.resourceIds,
          target,
          list: this.list
        }))
    },
    /**
     * 删除图片
     */
    deleteClick(idx) {
      const deletedFile = this.list.splice(idx, 1)[0]
      this.triggerUploadChange(deletedFile)
      if (deletedFile.status === 'pending' && deletedFile.uploadTaskId) {
        cancelUploadFile(deletedFile.uploadTaskId)
      }
    }
  }
}
