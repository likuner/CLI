import { shortNum } from '../utils/common'
export default [
  {
    name: 'num',
    value: shortNum
  }
]
