import { getStaffAvatar } from '@/framework/service/user-service'
import { getResourceUrl } from '@/framework/service/file-service'

/**
 * 用户id转头像
 * @param {} value
 */
function staffId2Avatar(value) {
  return getStaffAvatar(value)
}

function resourceId2Url(value) {
  return getResourceUrl(value)
}

export default [{
  name: 'staffId2Avatar',
  value: staffId2Avatar
}, {
  name: 'resourceId2Url',
  value: resourceId2Url
}]
