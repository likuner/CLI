import dateFilters from './date'
import fileFilters from './file'
import numberFilters from './number'
import imageFilters from './image'
export default [
  ...dateFilters,
  ...fileFilters,
  ...numberFilters,
  ...imageFilters
]

