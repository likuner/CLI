<template>
  <div class="titlebar" @click="titleClick">
    <div class="titlebar_wrapper" :class="{'titlebar-border': border}">
      <div class="left" @click="backClick" v-if="leftArrow" ref="leftbtn">
        <img :src="require('@/framework/assets/images/back.png')" class="back" />
      </div>
      <div class="title" v-if="title">{{ title }}</div>
      <div class="right">
        <slot name="right" class="right"></slot>
      </div>
    </div>
  </div>
</template>
<script>
import { deepGet } from '../../utils/common'
export default {
  name: 'titlebar',
  data() {
    return {
      clickNum: 0,
      lastClickTime: Date.now()
    }
  },
  props: {
    leftArrow: {
      type: Boolean,
      default: true
    },
    title: {
      type: String,
      default: ''
    },
    border: {
      type: Boolean,
      default: false
    },
    leftFun: {
      type: Function
    }
  },
  methods: {
    titleClick(event) {
      if (deepGet(event, 'path', []).indexOf(this.$refs.leftbtn) > -1) {
        return
      }
      const nowTime = Date.now()
      if (nowTime - this.lastClickTime > 500) {
        this.clickNum = 1
      } else {
        this.clickNum++
      }
      if (this.clickNum >= 8) {
        this.$router.push('/feedback/index')
      }
      this.lastClickTime = nowTime
    },
    backClick() {
      if (this.leftFun) {
        this.leftFun()
        return
      }
      const oldHref = window.location.href
      history.back()
      setTimeout(() => {
        if (oldHref === window.location.href) {
          window.lx.ui.closeWindow()
        }
      }, 50)
    }
  }
}
</script>

<style lang="scss" scoped>
.titlebar-border {
  box-shadow: 0 3px 4px 0 #d3d3d3;
}
.titlebar_wrapper {
  background: #fff;
  height: 44px;
  display: flex;
  align-items: center;
  position: relative;
  cursor: pointer;
  z-index: 999;
  .left {
    display: flex;
    align-items: center;
    position: absolute;
    padding: 0 16px;
    left: 0;
    top: 0;
    bottom: 0;
    .back {
      width: 22px;
      height: 22px;
      margin-top: 2px;
    }
  }
  .title {
    margin: 0 auto;
    max-width: 60%;
    word-break: break-all;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .right {
    display: flex;
    align-items: center;
    position: absolute;
    top: 0;
    bottom: 0;
    right: 0;
    padding: 0 16px;
    font-size: 16px;
    color: #3388ff;
  }
  .title {
    text-align: center;
    font-size: 18px;
    color: #333;
    font-weight: bold;
  }
}
</style>
