<template>
  <div class="lx-member-wrap">
    <div class="lx-member-list">
      <div
        class="lx-member-item lx-choose-contacts"
        :style="{'width': width + 'px'}"
        v-for="(item, index) in value"
        :key="index"
        @click="memberClick(index,item.staffId)"
      >
        <van-image class="staff-avatar" :width="width" :height="height" :radius="radius" :fit="fit" :src="item.staffId | staffId2Avatar">
          <template v-slot:loading><img class="staff-avatar" :src="defaultAvatar"/></template>
          <template v-slot:error ><img class="staff-avatar" :src="defaultAvatar"/></template>
        </van-image>
        <div class="lx-choose-name">{{ item.name }}</div>
      </div>
      <van-image
        v-if="!disabled && (!max || max > count)"
        class="staff-avatar"
        :width="width"
        :height="height"
        :radius="radius"
        :src="require('@/framework/assets/images/add.png')"
        @click="addMembers"
      />
    </div>
  </div>
</template>

<script>
export default {
  name: 'staff-selector',
  model: {
    prop: 'value',
    event: 'dataChange'
  },
  props: {
    title: {
      type: String,
      default: '选择人员'
    },
    max: {
      type: Number,
      default: 0
    },
    defaultAvatar: {
      type: String,
      default: require('@/framework/assets/images/head@2x.png')
    },
    multiple: {
      type: Boolean,
      default: true
    },
    value: {
      type: Array,
      default: () => []
    },
    width: {
      type: [Number, String],
      default: 55
    },
    height: {
      type: [Number, String],
      default: 55
    },
    radius: {
      type: [Number, String],
      default: 4
    },
    fit: {
      type: String,
      default: 'cover'
    },
    disabled: {
      type: [Boolean, String],
      default: false
    }
  },
  data() {
    return { }
  },
  computed: {
    count() {
      return this.value?.length
    }
  },
  methods: {
    /**添加人员 */
    addMembers() {
      const memberIds = this.value.map(e => e.staffId)
      const param = {
        title: this.title, // 选择窗体标题
        multiple: this.multiple, // 是否允许多选
        type: ['staff'], // 选择联系人窗体tab选项卡类型，friend 好友，staff 组织人员， sector 组织部门/分支
        canChooseExternal: false, // 是否可以选择跨组织的外部联系人
        maxTip: '选择数量超出最大限制', //选择数量超出最大限制提示
        existentStaffs: memberIds || [] // 已经选择的联系人列表
      }
      this.max && (param.max = this.max)
      window.lx.biz.chooseContacts({
        ...param,
        success: (res) => {
          if (!res.contacts) return false
          this.$emit('dataChange', res.contacts.map(e => {
            return { staffId: e.staffId, name: e.name }
          }))
        },
        fail: (err) => {
          if (err?.code === -7) { //选人控件没有确定,直接取消了
            return
          } else {
            console.log('选人控件内部fail', err)
            this.$toast('数据异常')
          }
        }
      })
    },
    /**点击人员 */
    memberClick(index, staffId) {
      if (!this.disabled) {
        //删除所选人员
        this.value.splice(index, 1)
      } else {
        if (!staffId) return
        // 打开蓝名片
        window.lx.biz.openContactsCard({ staffId })
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.lx-member-wrap {
  overflow: hidden;
}
.lx-member-list {
  overflow: hidden;
}

.staff-avatar {
  width: 100%;
  height: 100%;
  float: left;
}

.lx-choose-contacts {
  font-family: PingFangSC-Regular;
  font-size: 12px;
  color: #999999;
  float: left;
  margin-right: 10px;
  margin-bottom: 10px;
  overflow: hidden;
  text-align: center;
  img {
    width: 100%;
    height: 100%;
    border-radius: 5px;
  }
  .lx-choose-name {
    width: 100%;
    text-align: center;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
}
/deep/ .van-image__error {
  background-color: transparent;
}
</style>
