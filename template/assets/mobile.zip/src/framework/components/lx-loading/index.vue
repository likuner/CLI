<template>
  <div class="lx-loading">
    <i></i>
    <span class="loading-text" v-if="msg">{{msg}}</span>
  </div>
</template>

<script>
export default {
  name: 'lx-loading',
  data() {
    return {}
  },
  props: {
    msg: String
  }
}
</script>

<style lang="scss" scoped>
/* 样式在loading.scss中 为了保证index.html中共用样式 */
</style>
