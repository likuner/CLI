<template>
  <div class="file-upload" v-if="!disabled || count > 0">
    <ul :class="{'last-no-border': disabled}">
      <li v-for="(file, index) in list" :key="index" @click="previewFileClick(index)">
        <template v-if="!resourceLoaded">
          <div class="skeleton-file-info">
            <div class="skeleton-file-type"></div>
            <div class="skeleton-name-size">
              <div class="skeleton-name"></div>
              <div class="skeleton-size"></div>
            </div>
          </div>
        </template>
        <template v-else>
          <div class="file-info">
            <img :src="getFileIcon(file.resource)" class="file-type" />
            <div class="name-size">
              <div class="name o-ellipsis">{{file.resource.fileName}}</div>
              <div class="size o-ellipsis">{{file.resource.size | format-filesize(1)}}</div>
            </div>
            <div class="ctrl-icons">
              <img
                :src="require('@/framework/assets/images/delete.png')"
                class="ctrl-btn"
                @click.stop="deleteClick(index)"
                v-if="!disabled"
              />
            </div>
          </div>
          <div :class="['upload-status', `upload-status-${file.status}`]" v-if="!disabled">
            <img
              class="upload-status-image"
              v-if="file.status === 'uploaded'"
              :src="require('@/framework/assets/images/seleted.png')"
            />
            <img
              class="upload-status-image"
              v-else-if="file.status === 'error'"
              :src="require('@/framework/assets/images/close.png')"
            />
            <img
              class="upload-status-image"
              v-else-if="file.status === 'pending'"
              :src="require('@/framework/assets/images/upload.png')"
            />
          </div>
          <div
            class="bg-progress"
            :style="{'width': file.uploadProgress + '%'}"
            v-if="file.status === 'pending'"
          ></div>
        </template>
      </li>
    </ul>
    <template v-if="canAdd && !disabled">
      <div class="add-file-btn" @click="addFileClick">{{label}}</div>
    </template>
  </div>
</template>

<script>
import { getExtNameByMimeType, deepGet } from '@/framework/utils/common'
import {
  getResourceInfos,
  uploadFileToServer
} from '@/framework/service/file-service'
import { openFileChoose } from '../../utils/file'
import Upload from '@/framework/minix/upload'
import { Toast } from 'vant'
import { getResourceUrl } from '@/framework/service/file-service'
const FILE_BLACKLIST = ['.exe', '.swf', '.py', '.htaccess', '.dtd', '.mno', '.vml', '.xsl', '.xht', '.svg', '.svgz', '.xml', '.xsd', '.xsf', '.svgz', '.xslt', '.wsdl', '.rdf', '.apk', '.bat', '.msi', '.', '.asp', '.aspx', '.asa', '.asax', '.ascx', '.ashx', '.asmx', '.cer', '.aSp', '.aSpx', '.aSa', '.aSax', '.aScx', '.aShx', '.aSmx', '.cEr', '.php', '.php5', '.php4', '.php3', '.php2', '.pHp', '.pHp5', '.pHp4', '.pHp3', '.pHp2', '.html', '.htm', '.phtml', '.pht', '.Html', '.Htm', '.pHtml', '.stm', '.shtm', '.shtml', '.xht', '.xhtml', '.jsp', '.jspa', '.jspx', '.jsw', '.jsv', '.jspf', '.jtml', '.jSp', '.jSpx', '.jSpa', '.jSw', '.jSv', '.jSpf', '.jHtml', '.js', '.css']
export default {
  name: 'file-upload',
  data: function() {
    return {}
  },
  props: {
    label: {
      type: String,
      default: '上传附件'
    },
    initResourceIds: {
      type: Array
    }
  },
  mixins: [Upload],
  created() {
    this.initFileList()
  },
  methods: {
    /**
     * 初始化fileList
     */
    initFileList() {
      if (!this.initResourceIds || this.initResourceIds.length === 0) {
        this.resourceLoaded = true
        return
      }
      this.initResourceIds.forEach((resourceId, index) => {
        if (resourceId) {
          this.list.push({
            order: index,
            status: 'uploaded',
            resource: {
              resourceId
            }
          })
        }
      })
      getResourceInfos(this.initResourceIds).then(resourceInfoMap => {
        if (resourceInfoMap) {
          this.list.forEach(file => {
            const resourceInfo = resourceInfoMap[file.resource.resourceId]
            if (resourceInfo) {
              this.$set(file, 'resource', resourceInfo)
            }
          })
        }
        this.resourceLoaded = true
      })
    },
    /**
     * 添加文件
     */
    async addFileClick() {
      const oFileList = await openFileChoose(true)
      const blacklist = new Set()
      const exceedMaxSizeFiles = []
      for (const oFile of oFileList) {
        if (!this.canAdd) break
        const fileExt = this.getExt(oFile.name)
        if (FILE_BLACKLIST.includes(fileExt)) {
          blacklist.add(fileExt)
          continue
        }
        if (this.maxSize > 0 && oFile.size > this.maxSize) {
          exceedMaxSizeFiles.push(oFile)
          continue
        }
        const file = {
          resourceId: '',
          order: this.list.length,
          status: 'pending',
          resource: {
            fileName: oFile.name,
            size: oFile.size,
            mimeType: oFile.type
          },
          uploadProgress: 0,
          uploadTaskId: ''
        }
        // 图片上传到服务器
        uploadFileToServer(oFile, '', function(uploadProgress, uploadTaskId) {
          // 上传进度
          file.uploadProgress = uploadProgress
          file.uploadTaskId = uploadTaskId
        }).then(resourceInfo => {
          if (resourceInfo) {
            file.status = 'uploaded'
            this.$set(file, 'resource', resourceInfo)
          } else {
            file.status = 'error'
          }
          this.triggerUploadChange(file)
          console.log(this.list)
        })
        this.list.push(file)
        this.triggerUploadChange(file)
      }
      if (blacklist.size > 0) {
        this.$toast.fail(`暂不支持上传${Array.from(blacklist).join('、')}类型的文件`)
      } else if (exceedMaxSizeFiles.length > 0) {
        this.$toast.fail(this.maxSizeErrorTip)
        this.triggerExceedMaxSize(exceedMaxSizeFiles)
      }
    },
    /**
     * 根据文件名称获取文件后缀
     */
    getExt(fileName) {
      const index = fileName && fileName.lastIndexOf('.')
      let extension = ''
      if (index >= 0) {
        extension = fileName.substring(index)
        extension = extension.toLowerCase()
      }
      return extension
    },
    /**
     * 获取文件类型对应的icon
     */
    getFileIcon(file) {
      const { fileName, mimeType } = file
      let extension = this.getExt(fileName)
      if (extension === '' && mimeType) {
        extension = `.${getExtNameByMimeType(mimeType)}`
      }

      switch (extension) {
        case '.png':
        case '.jpg':
        case '.gif':
        case '.jpeg':
          return require('@/framework/assets/images/file-icons/img.png')
        case '.mp4':
        case '.avi':
          return require('@/framework/assets/images/file-icons/mov.png')
        case '.doc':
        case '.docx':
          return require('@/framework/assets/images/file-icons/doc.png')
        case '.html':
          return require('@/framework/assets/images/file-icons/html.png')
        case '.js':
          return require('@/framework/assets/images/file-icons/js.png')
        case '.mp3':
          return require('@/framework/assets/images/file-icons/audio.png')
        case '.pdf':
          return require('@/framework/assets/images/file-icons/pdf.png')
        case '.ppt':
          return require('@/framework/assets/images/file-icons/ppt.png')
        case '.txt':
          return require('@/framework/assets/images/file-icons/txt.png')
        case '.xls':
        case '.xlsx':
        case '.xlsm':
          return require('@/framework/assets/images/file-icons/xls.png')
        case '.zip':
        case '.rar':
          return require('@/framework/assets/images/file-icons/zip.png')
        default:
          return require('@/framework/assets/images/file-icons/unknow.png')
      }
    },
    /**
     * 打开文件
     */
    previewFileClick(idx) {
      const resource = deepGet(this.list, `[${idx}].resource`)
      const status = deepGet(this.list, `[${idx}].status`)
      if (status === 'pending' || status === 'error') return
      if (resource) {
        this.$emit('download', deepGet(this.list, `[${idx}]`), idx)
        const params = {
          url: getResourceUrl(resource.resourceId),
          name: resource.fileName,
          size: resource.size,
          type: resource.suffix,
          fail: function() {
            Toast.fail('文件下载失败')
          }
        }
        console.log(params)
        window.lx.utils.previewFile(params)
      } else {
        Toast.fail('文件上传失败或文件已丢失')
      }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.file-upload {
  min-width: 200px;
  position: relative;
  &::before {
    content: "";
    position: absolute;
    top: -50%;
    bottom: -50%;
    left: -50%;
    right: -50%;
    width: 200%;
    height: 200%;
    -webkit-transform: scale(0.5);
    transform: scale(0.5);
    border: solid 1px #e8e8ec;
    box-sizing: border-box;
  }
}
.add-file-btn {
  height: 36px;
  color: #409eff;
  line-height: 36px;
  text-align: center;
  cursor: pointer;
  position: relative;
}
.ctrl-btn {
  cursor: pointer;
  width: 20px;
  height: 20px;
}
ul {
  &.last-no-border li:last-child:after {
    content: none;
  }
  li {
    position: relative;
    display: flex;
    overflow: hidden;
    &::after {
      content: " ";
      position: absolute;
      width: 200%;
      left: 0;
      bottom: 0;
      transform: scale(0.5);
      transform-origin: 0 0;
      border-bottom: solid 1px #e8e8ec;
    }
    .file-info {
      flex: 1 0 0;
      display: flex;
      overflow: hidden;
      align-items: center;
      padding: 12px 16px;
      .file-type {
        width: 36px;
        height: 36px;
      }
      .name-size {
        overflow: hidden;
        margin-left: 6px;
        margin-right: 6px;
        flex: 1;
        .name {
          font-size: 14px;
          line-height: 20px;
          height: 20px;
        }
        .size {
          color: #999999;
          height: 16px;
          line-height: 16px;
          font-size: 12px;
        }
      }

      .ctrl-icons {
        font-size: 18px;
        i {
          margin: 2px;
          cursor: pointer;
        }
      }
    }
    .skeleton-file-info {
      flex: 1 0 0;
      display: flex;
      overflow: hidden;
      align-items: center;
      padding: 12px 16px;
      .skeleton-file-type {
        width: 36px;
        height: 36px;
        background-color: #ebeef5;
        border-radius: 4px;
      }
      .skeleton-name-size {
        overflow: hidden;
        margin-left: 6px;
        margin-right: 6px;
        flex: 1;
        .skeleton-name {
          width: 80%;
          height: 16px;
          margin-bottom: 6px;
          background-color: #ebeef5;
        }
        .skeleton-size {
          width: 30%;
          height: 12px;
          background-color: #ebeef5;
        }
      }
    }

    .upload-status {
      position: absolute;
      right: -17px;
      top: -7px;
      width: 46px;
      height: 26px;
      text-align: center;
      transform: rotate(45deg);
      .upload-status-image {
        margin-top: 8px;
        width: 16px;
        height: 16px;
        transform: rotate(-45deg);
      }
    }
    .upload-status-uploaded {
      background: #409eff;
    }
    .upload-status-error {
      background: #f56c6c;
    }
    .upload-status-pending {
      background: #909399;
    }
    .bg-progress {
      position: absolute;
      height: 100%;
      background-color: #409eff;
      opacity: 0.2;
      z-index: 0;
      transition: width 0.3s;
    }
  }
}
.o-ellipsis {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>
