<template>
  <van-image
    class="staff-avatar"
    :src="staffId | staffId2Avatar"
    :width="width"
    :height="height"
    :fit="fit"
    :radius="radius"
    @click="avatarClick"
  >
    <template v-slot:loading>
      <img :src="defaultAvatar"/>
    </template>
    <template v-slot:error>
      <img :src="defaultAvatar"/>
    </template>
  </van-image>
</template>

<script>
export default {
  name: 'staff-avatar',
  data() {
    return { }
  },
  props: {
    staffId: {
      type: String,
      required: true
    },
    defaultAvatar: {
      type: String,
      default: require('@/framework/assets/images/head@2x.png')
    },
    width: {
      type: [Number, String],
      default: 40
    },
    height: {
      type: [Number, String],
      default: 40
    },
    fit: {
      type: String,
      default: 'cover'
    },
    radius: {
      type: [Number, String],
      default: 4
    },
    openContactsCard: {
      type: Boolean,
      default: true
    }
  },
  methods: {
    /**
     * 头像点击事件
     */
    avatarClick() {
      if (!this.openContactsCard) return
      if (!this.staffId) return
      // 打开蓝名片
      window.lx.biz.openContactsCard({
        staffId: this.staffId
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.staff-avatar{
  img{
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
}
/deep/ .van-image__error{
  background-color: transparent
}
</style>
