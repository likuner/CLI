<template>
  <div class="department-path">
    <label class="path">{{ content }}</label>
  </div>
</template>

<script>
import { deepGet } from '../../utils/common'
export default {
  name: 'department-path',
  props: {
    departments: Array
  },
  computed: {
    content() {
      return deepGet(this.departments, 'departments[0].path')
    }
  }
}
</script>

<style lang="scss" scoped>
.frontellipsislabel{
    display: flex;
}
.path {
  font-size: 12px;
  color: #909399;
  margin-top: 2px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  direction: rtl;
}
</style>
