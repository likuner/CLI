<template>
  <div class="image-text">
    <img :src="image" v-if="image">
    <span class="tip" v-if="text">{{text}}</span>
  </div>
</template>
<script>
export default {
  name: 'image-text',
  props: {
    image: String,
    text: String
  }
}
</script>
<style lang="scss" scoped>
.image-text{
  height: 100%;
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
}
img {
  width: 150px;
  height: auto;
}
.tip {
  font-size: 14px;
  margin-top: 20px;
  color: #909399;
  text-align: center;
  line-height: 14px;
}
</style>
