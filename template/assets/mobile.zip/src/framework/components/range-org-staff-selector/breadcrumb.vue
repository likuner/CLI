<template>
  <div class="breadcrumb">
    <div class="home" @click="itemClickHandle(-1)">
      <van-icon name="wap-home-o" size="18px" />
    </div>
    <ul class="path-list" ref="list">
      <li v-for="(name, index) of path" :key="index" @click="itemClickHandle(index)">
        <span>{{name}}</span>
        <van-icon class="right-arrow" name="arrow" color="rgba(0,0,0,0.2)" size="12px"/>
      </li>
    </ul>
  </div>
</template>
<script>
import { Icon } from 'vant'
export default {
  name: 'breadcrumb',
  props: {
    path: {
      type: Array,
      required: true
    }
  },
  components: {
    [Icon.name]: Icon
  },
  watch: {
    path: {
      handler() {
        this.$nextTick(() => {
          if (this.$refs.list) {
            const lastChild = this.$refs.list.querySelector('li:last-child')
            lastChild && lastChild.scrollIntoView()
          }
        })
      }
    }
  },
  methods: {
    itemClickHandle(index) {
      // 最后一级不可点击
      if (index < this.path.length - 1) {
        this.$emit('item-click', index)
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.breadcrumb{
  display: flex;
  height: 50px;
  .home {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 50px;
    cursor: pointer;
  }
  .path-list{
    flex: 1;
    display: flex;
    align-items: stretch;
    overflow-x: auto;
    li {
      display: flex;
      align-items: center;
      font-size: 16px;
      color: #347AFC;
      cursor: pointer;
      flex-shrink: 0;
      .right-arrow{
        margin: 0 6px;
      }
      &:last-child{
        color: #303133;
        .right-arrow {
          visibility: hidden;
        }
      }
    }
  }
}

</style>

