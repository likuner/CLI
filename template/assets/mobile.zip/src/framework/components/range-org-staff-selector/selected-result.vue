<template>
  <div class="selected-result" v-if="visible">
    <titlebar title="已选" :leftFun="close"></titlebar>
    <van-tabs class="selected-tabs">
      <van-tab :title="memberTabTitle">
        <div class="memberList" v-if="selectedMembers.length > 0">
          <div v-for="(item, index) in selectedMembers" :key="index" class="member-info">
            <staff-avatar :openContactsCard="false" width="36px" height="36px" :staffId="item.staffId" style="margin:0 20px"></staff-avatar>
            <div class="member-info-body">
              <div class="member-info-text">
                <label class="name">{{ item.name }}</label>
                <department-path :departments="item.departments"></department-path>
              </div>
              <img
                @click="removeMember(item)"
                :src="require('@/framework/assets/images/delete-staff.png')"
              />
            </div>
          </div>
        </div>
        <image-text
          v-if="selectedMembers.length === 0"
          :image="require('@/framework/assets/images/empty.png')"
          text="未选中任何人员"
        ></image-text>
      </van-tab>
      <van-tab :title="structTabTitle">
        <div class="structList" v-if="selectedStructs.length > 0">
          <div v-for="(item, index) in selectedStructs" :key="index" class="structInfo">
            <img :src="require('@/framework/assets/images/ic_org.png')" />
            <div class="structInfo-body">
              <div class="structInfo-text">
                <div class="structInfo-text-top">
                  <label class="name">{{ item.name }}</label>
                </div>
                <department-path :Content="item.path"></department-path>
                <department-path :departments="item.departments"></department-path>
              </div>
              <img
                @click="removeStruct(item)"
                :src="require('@/framework/assets/images/delete-staff.png')"
              />
            </div>
          </div>
        </div>
        <image-text
          v-if="selectedStructs.length === 0"
          :image="require('@/framework/assets/images/empty.png')"
          text="未选中任何部门"
        ></image-text>
      </van-tab>
    </van-tabs>
  </div>
</template>

<script>
import Titlebar from '@/framework/components/titlebar'
import DepartmentPath from '@/framework/components/range-org-staff-selector/department-path'
import { Tabbar, TabbarItem, Tab, Tabs } from 'vant'
import ImageText from './image-text'
import StaffAvatar from '../staff-avatar'

export default {
  name: 'selected-result',
  components: {
    [Titlebar.name]: Titlebar,
    [DepartmentPath.name]: DepartmentPath,
    [Tabbar.name]: Tabbar,
    [TabbarItem.name]: TabbarItem,
    [Tab.name]: Tab,
    [Tabs.name]: Tabs,
    [ImageText.name]: ImageText,
    [StaffAvatar.name]: StaffAvatar
  },
  props: {
    visible: Boolean,
    selectedMembers: {
      //传入的选中人员数组
      type: Array,
      default: function() {
        return []
      }
    },
    selectedStructs: {
      //传入的选中分支数组
      type: Array,
      default: function() {
        return []
      }
    }
  },
  computed: {
    memberTabTitle() {
      return '人员 ' + this.selectedMembers.length
    },
    structTabTitle() {
      return '分支 ' + this.selectedStructs.length
    }
  },
  methods: {
    getStaffPath(staff) {
      if (
        staff &&
        staff.departments &&
        staff.departments.length > 0 &&
        staff.departments[0].path
      ) {
        return staff.departments[0].path
      }
      return ''
    },
    removeMember(data) {
      this.$emit('remove', 1, data)
    },
    removeStruct(data) {
      this.$emit('remove', 2, data)
    },
    //关闭页面
    close() {
      this.$emit('update:visible', false)
    }
  }
}
</script>

<style lang='scss' scoped>
.selected-result {
  background: #f6f6f6;
  display: flex;
  flex-direction: column;
  .selected-tabs {
    flex: 1;
    display: flex;
    flex-direction: column;
    overflow: auto;
    /deep/ .van-tabs__content {
      height: calc(100% - 44px);
    }
    /deep/ .van-tab__pane{
      height: 100%;
      overflow: auto;
    }
  }
  .memberList {
    .member-info {
      display: flex;
      align-items: center;
      background: white;
      .member-info-body {
        flex-grow: 1;
        border-bottom: 1px solid #f6f6f6;
        display: flex;
        flex-direction: row;

        .member-info-text {
          display: flex;
          flex-direction: column;
          justify-content: center;
          flex: 1;
          height: 60px;
          .name {
            font-size: 16px;
            color: #303133;
          }
        }

        img {
          width: 48px;
          height: 48px;
          align-self: center;
          margin: 0 8px;
          padding: 12px;
        }
      }
    }
  }

  .structList {
    .structInfo {
      height: 60px;
      display: flex;
      flex-direction: row;
      background: white;

      img {
        width: 24px;
        height: 24px;
        align-self: center;
        margin: 0 20px;
      }

      .structInfo-body {
        flex-grow: 1;
        border-bottom: 1px solid #f6f6f6;
        display: flex;
        flex-direction: row;

        .structInfo-text {
          flex-grow: 1;
          display: flex;
          flex-direction: column;
          justify-content: center;
          width: 100px;

          .name {
            font-size: 16px;
            color: #303133;
          }

          .membersCount {
            font-size: 16px;
            color: #909399;
            margin-left: 10px;
          }

          .path {
            font-size: 12px;
            color: #909399;
            margin-top: 2px;
          }
        }

        img {
          width: 48px;
          height: 48px;
          align-self: center;
          margin: 0 8px;
          padding: 12px;
        }
      }
    }
  }
}

/deep/ .van-tabs__wrap {
  border-bottom: 1px solid #f6f6f6;
}
</style>
