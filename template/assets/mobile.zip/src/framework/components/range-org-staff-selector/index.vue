<template>
  <div class="range-org-staff-selector">
    <div class="header">
      <!-- titlebar -->
      <titlebar title="选择" :leftFun="back">
        <template slot="right">
          <van-button
            size="mini"
            color="#347AFC"
            :disabled="!selected.length"
            @click="confirmClickHandle"
          >确认</van-button>
        </template>
      </titlebar>
      <!-- 搜索  -->
      <van-search placeholder="请输入搜索关键词" disabled @click.native="showSearch = true" />
      <!-- 面包屑导航 -->
      <breadcrumb :path="structNames" @item-click="breadcrumbItemClick" class="breadcrumb"></breadcrumb>
    </div>
    <div class="main">
      <image-text
        style="background: white"
        v-if="dataEmpty"
        :image="require('@/framework/assets/images/empty.png')"
        text="当前分支没有任何成员"
      ></image-text>
      <network-error v-else-if="dataError" @refresh="reloadData"></network-error>
      <org-staff-skeleton v-else-if="dataLoading"></org-staff-skeleton>
      <template v-else>
        <!-- 人员列表 -->
        <ul class="member-container" v-show="currentMemberList && currentMemberList.length > 0">
          <li v-for="staff of currentMemberList" :key="staff.staffId">
            <div class="head-img">
              <staff-avatar
                :openContactsCard="false"
                width="48px"
                height="48px"
                :staffId="staff.staffId"
              ></staff-avatar>
              <van-checkbox
                v-if="['PersonAndStruct', 'Person'].includes(selectMode)"
                class="person-check"
                icon-size="12px"
                :value="selectedMemberIds.includes(staff.staffId)"
                :disabled="!canCheckPerson"
                @click="checkboxClickHandle(1, staff)"
              />
            </div>
            <div class="user-name">{{staff.name}}</div>
          </li>
          <li v-if="!currentMemberPage.allLoaded">
            <div class="load-more-staff">
              <van-button
                :loading="currentMemberPage.loading"
                class="btn"
                color="#eaf1fe"
                @click="loadNextPageStaff"
              >
                <van-icon name="weapp-nav" />
              </van-button>
            </div>
            <div class="user-name" style="color: #347AFC">更多</div>
          </li>
        </ul>
        <!-- 部门列表 -->
        <ul class="struct-container" v-show="currentStructList && currentStructList.length > 0">
          <li v-for="struct of currentStructList" :key="struct.id">
            <div class="dep-icon">
              <img :src="require('@/framework/assets/images/ic_org.png')" />
            </div>
            <div class="dep-info">
              <div class="dep-name" @click="structClickHandle(struct)">{{struct.name}}</div>
              <van-checkbox
                v-if="['PersonAndStruct', 'Struct'].includes(selectMode)"
                class="dep-check"
                icon-size="12px"
                :value="selectedStructIds.includes(struct.id)"
                @click="checkboxClickHandle(2, struct)"
              />
            </div>
          </li>
        </ul>
      </template>
    </div>
    <div class="footer">
      <!-- 已选择信息 -->
      <ul class="selected-list">
        <template v-for="item of selected">
          <li class="staff" v-if="item.dataType === 1" :key="'staff' + item.staffId">
            <staff-avatar
              :openContactsCard="false"
              width="28px"
              height="28px"
              :staffId="item.staffId"
            ></staff-avatar>
          </li>
          <li class="struct" v-if="item.dataType === 2" :key="'struct' + item.id">{{ item.name }}</li>
        </template>
      </ul>
      <div class="selected-btn" @click="showResult=true">已选{{selected.length}}</div>
    </div>
    <!-- 搜索结果 -->
    <search-result
      :visible.sync="showSearch"
      :selectedMembers="selectedMembers"
      :rangeStructsIds="rangeStructsIds"
      :canCheckPerson="canCheckPerson"
      @check-change="checkboxClickHandle(1, $event)"
      class="search-container"
    ></search-result>
    <!-- 选择结果 -->
    <selected-result
      :visible.sync="showResult"
      :selectedMembers="selectedMembers"
      :selectedStructs="selectedStructs"
      @remove="checkboxClickHandle"
      class="result-container"
    ></selected-result>
  </div>
</template>

<script>
import TitleBar from '../titlebar'
import Breadcrumb from './breadcrumb'
import { Search, Checkbox } from 'vant'
import StaffAvatar from '../staff-avatar'
import OrgStaffSkeleton from './org-staff-skeleton'
import NetworkError from './network-error'
import SelectedResult from './selected-result'
import SearchResult from './search-result'
import ImageText from './image-text'
import {
  fetchOrgMemberListByStaffIds,
  fetchChildrenStructListByOrgStructList,
  fetchOrgMemberList,
  fetchChildrenOpenOrgStructList
} from '../../service/org-service'
import { deepGet } from '../../utils/common'
export default {
  name: 'range-org-staff-selector',
  props: {
    options: Object,
    params: Object
  },
  components: {
    [TitleBar.name]: TitleBar,
    [Search.name]: Search,
    [Checkbox.name]: Checkbox,
    [Breadcrumb.name]: Breadcrumb,
    [StaffAvatar.name]: StaffAvatar,
    [OrgStaffSkeleton.name]: OrgStaffSkeleton,
    [NetworkError.name]: NetworkError,
    [SelectedResult.name]: SelectedResult,
    [SearchResult.name]: SearchResult,
    [ImageText.name]: ImageText
  },
  data() {
    return {
      // 当前面包屑显示的部门路径
      structPath: [],
      // 部门人员信息列表
      selected: [],
      // 当前部门列表
      currentStructList: [],
      // 当前人员列表
      currentMemberList: [],
      // 部门人员信息加载标志位
      dataLoading: true,
      // 部门及人员信息加载失败
      dataError: false,
      // 当前部门人员分页信息
      currentMemberPage: {
        // 下一页数据加载中
        loading: false,
        pageNumber: 1,
        allLoaded: true
      },
      // 显示选择结果
      showResult: false,
      showSearch: false,
      lastLoadTime: 0
    }
  },

  computed: {
    canCheckPerson() {
      if (typeof this.options.maxPerson === 'number') {
        return this.selectedMembers.length < this.options.maxPerson
      } else {
        return true
      }
    },
    /* 已选择员工 */
    selectedMembers() {
      return this.selected.filter(ele => ele.dataType === 1)
    },
    /* 已选择部门 */
    selectedStructs() {
      return this.selected.filter(ele => ele.dataType === 2)
    },
    /* 已选择员工ids */
    selectedMemberIds() {
      return this.selectedMembers.map(ele => ele.staffId)
    },
    /* 已选择部门 */
    selectedStructIds() {
      return this.selectedStructs.map(ele => ele.id)
    },
    /* 面包屑部门列表名称 */
    structNames() {
      return this.structPath.map(ele => ele.name)
    },
    /* 当前显示的部门 */
    currentStruct() {
      return this.structPath[this.structPath.length - 1]
    },
    // 部门及人员信息为空
    dataEmpty() {
      return (
        this.currentStructList.length === 0 &&
        this.currentMemberList.length === 0 &&
        !this.dataError &&
        !this.dataLoading
      )
    },
    rangeStructsIds() {
      return deepGet(this.options, 'rangeStructs', [])
    },
    rangeMemberIds() {
      return deepGet(this.options, 'rangeMembers', [])
    },
    selectMode() {
      return this.options.selectMode
    }
  },
  created() {
    const selectedMembers = deepGet(this.params, 'selectedMembers', [])
    selectedMembers.forEach(ele => { ele.dataType = 1 })
    const selectedStructs = deepGet(this.params, 'selectedStructs', [])
    selectedStructs.forEach(ele => { ele.dataType = 2 })
    this.selected.push(...selectedMembers, ...selectedStructs)
    this.reloadData()
    window.history.pushState(null, '范围选人')
    window.addEventListener('popstate', this.popstateHandle)
  },
  destroyed() {
    window.removeEventListener('popstate', this.popstateHandle)
    if (this.$el && this.$el.parentNode) {
      this.$el.parentNode.removeChild(this.$el)
    }
  },
  mounted() {
    document.body.append(this.$el)
  },
  methods: {
    /**
     * @description: 面包屑点击事件
     * @param idx 点击索引
     */
    breadcrumbItemClick(idx) {
      this.structPath = this.structPath.slice(0, idx + 1)
      this.reloadData()
    },

    /**
     * @description: 加载人员部门数据
     */
    reloadData() {
      this.currentMemberPage.pageNumber = 1
      this.currentMemberPage.allLoaded = true
      this.structPath.length ? this.loadStructData() : this.loadRootData()
    },
    /**
     * @description: 获取根部门的人员及部门
     */
    async loadRootData() {
      const lastLoadTime = Date.now()
      this.lastLoadTime = lastLoadTime
      const req = [
        this.rangeMemberIds.length
          ? fetchOrgMemberListByStaffIds(this.rangeMemberIds)
          : Promise.resolve({ errcode: 200, data: [] }),
        this.rangeStructsIds.length
          ? fetchChildrenStructListByOrgStructList(this.rangeStructsIds)
          : Promise.resolve({ errcode: 200, data: [] })
      ]
      // 当前人员或者部门置空
      this.currentStructList = []
      this.currentMemberList = []
      this.dataLoading = true
      const res = await Promise.all(req)
      this.dataLoading = false
      if (this.lastLoadTime !== lastLoadTime) {
        return
      }
      // 人员或者部门数据加载失败
      if (res.some(ele => ele.errcode !== 200)) {
        this.dataError = true
        return
      }
      this.currentMemberList = deepGet(res, '[0].data', [])
      this.currentStructList = deepGet(res, '[1].data', [])
    },

    /**
     * @description: 根据部门id加载部门下的人员及部门
     * @param structId 部门id
     */
    async loadStructData() {
      const lastLoadTime = Date.now()
      this.lastLoadTime = lastLoadTime
      const structId = this.currentStruct.id
      const req = [
        fetchOrgMemberList(structId, 1, 19),
        fetchChildrenOpenOrgStructList(structId)
      ]
      // 当前人员或者部门置空
      this.currentStructList = []
      this.currentMemberList = []
      this.dataLoading = true
      this.dataError = false
      const res = await Promise.all(req)
      this.dataLoading = false
      if (this.lastLoadTime !== lastLoadTime) {
        return
      }
      // 人员或者部门数据加载失败
      if (res.some(ele => ele.errcode !== 200)) {
        this.dataError = true
        return
      }
      this.currentMemberList = deepGet(res, '[0].data.result', [])
      this.currentMemberPage.pageNumber++
      this.currentMemberPage.allLoaded = !deepGet(res, '[0]data.hasMore', true)
      this.currentStructList = deepGet(res, '[1].data', [])
    },

    /**
     * @description: 获取下一页人员数据
     * @param {*}
     */
    async loadNextPageStaff() {
      // 没有更多的数据
      if (this.currentMemberPage.allLoaded) return
      if (this.currentMemberPage.loading) return
      this.currentMemberPage.loading = true
      const currentStructId = this.currentStruct.id
      const res = await fetchOrgMemberList(
        currentStructId,
        this.currentMemberPage.pageNumber,
        20
      )
      this.currentMemberPage.loading = false
      if (this.currentStruct.id !== currentStructId) {
        // 数据过期
        return
      }
      // 数据记载异常
      if (res.errcode !== 200) {
        this.$toast(res.errmsg)
        return
      }
      // 数据加载成功
      this.currentMemberList.push(...deepGet(res, 'data.result', []))
      this.currentMemberPage.pageNumber++
      this.currentMemberPage.allLoaded = !deepGet(res, 'data.hasMore', true)
    },

    /**
     * @description: 人员部门选择 ckb点击事件
     * @param dataType 数据类型 1人员 2部门
     * @param data 人员或者部门信息
     */
    checkboxClickHandle(dataType, data) {
      if (dataType === 1 && !this.canCheckPerson) return
      for (let i = 0; i < this.selected.length; i++) {
        const item = this.selected[i]
        if (item.dataType !== dataType) continue
        if (
          (dataType === 1 && item.staffId === data.staffId) ||
          (dataType === 2 && item.id === data.id)
        ) {
          this.selected.splice(i, 1)
          return
        }
      }
      data.dataType = dataType
      this.selected.unshift(data)
    },
    /**
     * @description: 部门点击事件
     * @param struct 部门信息
     */
    structClickHandle(struct) {
      this.structPath.push(struct)
      this.reloadData()
    },
    back() {
      window.history.back()
    },
    confirmClickHandle() {
      this.options.confrimCb({
        selectedStructs: this.selectedStructs,
        selectedMembers: this.selectedMembers
      })
      window.history.back()
    },
    popstateHandle() {
      this.options.cancelCb()
    }
  }
}
</script>

<style lang="scss" scoped>
.range-org-staff-selector {
  height: 100vh;
  width: 100vw;
  display: flex;
  flex-direction: column;
  position: relative;
  z-index: 3000;
  background-color: white;
  padding-top: constant(safe-area-inset-top);
  padding-top: env(safe-area-inset-top);
  padding-bottom: constant(safe-area-inset-bottom);
  padding-bottom: env(safe-area-inset-bottom);
  .main {
    flex: 1;
    overflow: auto;
    background-color: #f6f6f6;
  }
  .footer {
    height: 50px;
    display: flex;
    align-items: center;
    box-shadow: 0 -2px 6px 0 rgba(0, 0, 0, 0.4);
    .selected-list {
      flex: 1;
      padding-left: 12px;
      overflow-x: auto;
      display: flex;
      align-items: center;
      height: 100%;
      display: flex;
      li {
        margin-right: 10px;
        flex-shrink: 0;
      }
      li.struct {
        height: 24px;
        line-height: 24px;
        max-width: 84px;
        background: rgba(52, 122, 252, 0.1);
        border-radius: 4px;
        font-size: 12px;
        color: #347afc;
        padding: 0 6px;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
    }
    .selected-btn {
      background: rgba(0, 0, 0, 0.06);
      border-radius: 4px;
      font-size: 12px;
      color: #909399;
      text-align: center;
      line-height: 12px;
      padding: 8px 10px;
      margin: 0 12px;
    }
  }
}
.breadcrumb {
  position: relative;
  &::after {
    content: " ";
    position: absolute;
    height: 1px;
    background-color: rgba(0, 0, 0, 0.1);
    width: 100%;
    left: 0;
    bottom: 0;
    transform: scaleY(0.5);
  }
}
.member-container {
  display: flex;
  flex-wrap: wrap;
  background: white;
  position: relative;
  padding-bottom: 16px;
  &::after {
    content: " ";
    position: absolute;
    height: 1px;
    background-color: rgba(0, 0, 0, 0.1);
    width: 100%;
    left: 0;
    bottom: 0;
    transform: scaleY(0.5);
  }
  li {
    width: 20%;
    margin-top: 16px;
  }
  .head-img {
    box-sizing: border-box;
    position: relative;
    height: 54px;
    width: 54px;
    padding: 3px;
    margin: 0 auto;
    .person-check {
      position: absolute;
      right: 0;
      top: 0;
    }
  }
  .user-name {
    margin-top: 10px;
    font-size: 12px;
    color: #303133;
    text-align: center;
    line-height: 12px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    padding: 0 4px;
  }
}
.struct-container {
  li {
    background-color: white;
    display: flex;
    align-items: center;
    .dep-icon {
      padding: 0 10px 0 16px;
      img {
        width: 20px;
        height: 20px;
      }
    }
    .dep-info {
      flex: 1;
      height: 50px;
      display: flex;
      align-items: center;
      font-size: 16px;
      color: #303133;
      position: relative;
      overflow: hidden;
      .dep-name {
        flex: 1;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
      .dep-check {
        padding: 0 22px 0 10px;
      }
      &::after {
        content: " ";
        position: absolute;
        height: 1px;
        background-color: rgba(0, 0, 0, 0.1);
        width: 100%;
        left: 0;
        bottom: 0;
        transform: scaleY(0.5);
      }
    }
    &:last-child {
      .dep-name::after {
        display: none;
      }
    }
  }
}
.search-container {
  position: absolute;
  height: 100%;
  width: 100%;
  z-index: 1100;
}
.result-container {
  position: absolute;
  height: 100%;
  width: 100%;
  z-index: 1100;
}
.load-more-staff {
  box-sizing: border-box;
  position: relative;
  height: 54px;
  width: 54px;
  padding: 3px;
  margin: 0 auto;
  .btn {
    font-size: 20px;
    width: 48px;
    height: 48px;
    overflow: hidden;
    color: #347afc !important;
  }
}
</style>
