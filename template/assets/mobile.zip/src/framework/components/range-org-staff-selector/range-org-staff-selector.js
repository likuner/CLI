import Vue from 'vue'
import RangeOrgStaffSelector from './index'
import { deepClone } from '@/framework/utils/common'
const DEFAULT_OPTIONS = {
  selectMode: 'PersonAndStruct', //PersonAndStruct、Struct、Person
  maxPerson: null,
  rangeMembers: [],
  rangeStructs: []
}
/**
 * 选人选部门选标签
 * @param {*} params 选中部门、人员、标签
 * eg:
 * {
 *    selectedStructs: [{
 *      id: 部门id,
 *      name: 部门名称
 *    }],
 *    selectedMembers: [{
 *      staffId:人员id,
 *      name: 人员名称
 *    }]
 * }
 *
 * @param {*} options 配置
 * eg.
 * {
 *    selectMode: 选人模式，默认值PersonAndStruct, //PersonAndStruct、Struct、Person
 *    maxPerson: null, 最多选人个数，默认不限制
 *    rangeStructs: [], 部门范围
 *    rangeMembers: [], 人员范围
 * }
 *
 */
export function chooseOrgStaff(params = {}, options = {}) {
  return new Promise(function(resolve) {
    options = Object.assign({}, DEFAULT_OPTIONS, deepClone(options || {}), {
      confrimCb: (data) => {
        instanceDialog.$destroy()
        resolve({ action: 'confirm', data })
      },
      cancelCb: () => {
        instanceDialog.$destroy()
        resolve({ action: 'cancel' })
      }
    })
    const SelectorDilaog = Vue.extend(RangeOrgStaffSelector)
    const instanceDialog = new SelectorDilaog({
      propsData: {
        options: options,
        params: deepClone(params)
      }
    }
    ).$mount()
  })
}
