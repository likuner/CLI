<template>
  <div class="org-staff-skeleton">
    <ul class="member-skeleton">
      <li v-for="i in 10" :key="i">
        <div class="head"></div>
        <div class="user-name"></div>
      </li>
    </ul>
    <ul class="struct-skeleton">
      <li v-for="i in 5" :key="i">
        <div class="dep-icon"></div>
        <div class="dep-name">
          <span></span>
        </div>
      </li>
    </ul>
  </div>
</template>
<script>
export default {
  name: 'org-staff-skeleton'
}
</script>
<style lang="scss" scoped>
.member-skeleton {
  display: flex;
  flex-wrap: wrap;
  background: white;
  position: relative;
  padding-bottom: 16px;
  &::after {
    content: " ";
    position: absolute;
    height: 1px;
    background-color: rgba(0, 0, 0, 0.1);
    width: 100%;
    left: 0;
    bottom: 0;
    transform: scaleY(0.5);
  }
  li {
    width: 20%;
    margin-top: 16px;
  }
  .head {
    box-sizing: border-box;
    position: relative;
    height: 54px;
    width: 54px;
    padding: 3px;
    margin: 0 auto;
    background-color: #f2f3f5;
    border-radius: 4px;
  }
  .user-name {
    height: 12px;
    width: 54px;
    margin: 10px auto 0px;
    background-color: #f2f3f5;
  }
}
.struct-skeleton {
  li {
    background-color: white;
    display: flex;
    align-items: center;
    .dep-icon {
      margin: 0 10px 0 16px;
      width: 20px;
      height: 20px;
      border-radius: 4px;
      background-color: #f2f3f5;
    }
    .dep-name {
      flex: 1;
      height: 50px;
      display: flex;
      align-items: center;
      position: relative;
      span {
        width: 90%;
        height: 20px;
        background-color: #f2f3f5;
      }
      &::after {
        content: " ";
        position: absolute;
        height: 1px;
        background-color: rgba(0, 0, 0, 0.1);
        width: 100%;
        left: 0;
        bottom: 0;
        transform: scaleY(0.5);
      }
    }
    &:last-child {
      .dep-name::after {
        display: none;
      }
    }
  }
}
</style>
