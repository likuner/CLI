<template>
  <div class="search-result" v-if="visible">
    <van-search
      class="top"
      v-model.trim="keyword"
      show-action
      placeholder="请输入搜索关键词"
      @search="onSearch"
      @cancel="onCancel"
      @clear="onClear"
    />
    <div class="member-list">
      <van-list
        style="height: 100%"
        v-model="dataLoading"
        :finished="allLoaded"
        :immediate-check="false"
        :error.sync="dataError"
        @load="loadDataByKeyword"
        error-text="请求失败，点击重新加载"
      >
        <li class="member-info" v-for="item in list" :key="item.staffId">
          <staff-avatar :openContactsCard="false" width="36px" height="36px" :staffId="item.staffId" style="margin:0 20px"></staff-avatar>
          <div class="member-info-body">
            <div class="member-info-text">
              <label class="name">{{ item.name }}</label>
              <department-path :Content="getStaffPath(item)"></department-path>
            </div>
            <van-checkbox
              style="padding: 0 20px;"
              icon-size="16px"
              :value="selectedMemberIds.includes(item.staffId)"
              :disabled="!canCheckPerson"
              @click="checkboxClickHandle(item)"
            />
          </div>
        </li>
        <image-text
          v-show="!dataError && !dataLoading && dataEmpty"
          :image="require('@/framework/assets/images/empty.png')"
          text="未搜索到相关人员"
        ></image-text>
      </van-list>
    </div>
  </div>
</template>

<script>
import DepartmentPath from '@/framework/components/range-org-staff-selector/department-path'
import { searchRangeStatffListByKeyword } from '@/framework/service/org-service'
import { List } from 'vant'
import ImageText from './image-text'
import { deepGet } from '../../utils/common'
import StaffAvatar from '../staff-avatar'

export default {
  name: 'search-result',
  components: {
    [DepartmentPath.name]: DepartmentPath,
    [List.name]: List,
    [ImageText.name]: ImageText,
    [StaffAvatar.name]: StaffAvatar
  },
  data() {
    return {
      // 搜索关键字
      keyword: '',
      // 搜索loading
      dataLoading: false,
      // 数据全部加载
      allLoaded: false,
      // 搜索页数
      pageNo: 1,
      //搜索结果人员信息数组
      list: [],
      // 上次搜索时间
      lastSearchTime: null,
      // 数据加载错误
      dataError: false,
      // 数据为空
      dataEmpty: false
    }
  },
  props: {
    visible: Boolean,
    selectedMembers: {
      type: Array,
      default: function() {
        return []
      }
    },
    rangeStructsIds: {
      type: Array,
      default: function() {
        return []
      }
    },
    canCheckPerson: {
      type: Boolean,
      default: true
    }
  },
  computed: {
    selectedMemberIds() {
      return this.selectedMembers.map(ele => ele.staffId)
    }
  },
  methods: {
    async loadDataByKeyword() {
      if (!this.keyword) {
        this.onClear()
        return
      }
      if (!this.rangeStructsIds.length) {
        this.dataEmpty = true
        return
      }
      const lastSearchTime = Date.now()
      this.lastSearchTime = lastSearchTime
      const res = await searchRangeStatffListByKeyword({
        keyword: this.keyword,
        pageNo: this.pageNo,
        searchScope: this.rangeStructsIds
      })
      if (lastSearchTime !== this.lastSearchTime) {
        // 数据过期
        return
      }
      this.dataLoading = false
      if (res.errcode === 200) {
        const arr = deepGet(res, 'data.result', [])
        this.list.push(...arr)
        this.allLoaded = arr.length !== 20
        this.pageNo++
      } else {
        this.dataError = true
      }
      this.dataEmpty = !this.list.length
    },
    //回车搜索
    onSearch() {
      this.pageNo = 1
      this.list = []
      this.allLoaded = false
      this.loadDataByKeyword()
    },
    onCancel() {
      this.onClear()
      this.$emit('update:visible', false)
    },
    //拼装人员path用于显示
    getStaffPath(staff) {
      return deepGet(staff, 'departments[0].path')
    },
    //清空输入框
    onClear() {
      this.keyword = ''
      this.pageNo = 1
      this.list = []
      this.dataLoading = false
      this.allLoaded = false
      this.dataError = false
      this.dataEmpty = false
    },
    //选中人员
    checkboxClickHandle(item) {
      this.$emit('check-change', item)
    }
  }
}
</script>

<style lang="scss" scoped>
.search-result {
  background: #f6f6f6;
  display: flex;
  flex-direction: column;

  .top {
    height: 44px;
    background: white;
  }

  .member-list {
    flex-grow: 1;
    overflow-y: auto;
    .member-info {
      display: flex;
      align-items: center;
      background: white;
      .member-info-body {
        height: 60px;
        flex-grow: 1;
        border-bottom: 1px solid #f6f6f6;
        display: flex;
        flex-direction: row;
        .member-info-text {
          flex-grow: 1;
          display: flex;
          flex-direction: column;
          justify-content: center;
          width: 100px;
          .name {
            font-size: 16px;
            color: #303133;
          }
        }

        input {
          width: 16px;
          height: 16px;
          align-self: center;
          margin: 0 20px;
        }
      }
    }
  }
}
</style>
