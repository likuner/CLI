<template>
  <div class="network-error">
    <img :src="require('@/framework/assets/images/no-network.png')">
    <span class="tip">当前网络故障，请重试</span>
    <van-button type="primary" size="small" style="margin-top: 40px" @click="refreshClickHandle">刷新</van-button>
  </div>
</template>
<script>
export default {
  name: 'network-error',
  methods: {
    refreshClickHandle() {
      this.$emit('refresh')
    }
  }
}
</script>
<style lang="scss" scoped>
.network-error{
  height: 100%;
  width: 100%;
  background-color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
}
img {
  width: 150px;
  height: auto;
}
.tip {
  font-size: 14px;
  margin-top: 20px;
  color: #909399;
  text-align: center;
  line-height: 14px;
}
</style>
