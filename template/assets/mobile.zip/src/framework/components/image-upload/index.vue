<template>
  <ul class="image-upload">
    <li class="image-item" :style="imageStyle" v-for="(image, index) of list" :key="index">
      <div class="image-container">
        <van-image
          width="100%"
          height="100%"
          v-if="getImageSrc(image)"
          :src="getImageSrc(image)"
          @click="showPreview(index)"
          fit="cover"
        ></van-image>
        <template v-if="!disabled">
          <div class="mask" v-if="image.status !== 'uploaded'" @click ='reloadImg(image)'>
            <van-loading type="spinner" size="24px" color="#fff" v-if="image.status === 'pending'"></van-loading>
            <div class="upload-error" v-if="image.status === 'error'">
              <van-icon name="warning-o" size="24px" />
            </div>
          </div>
        </template>
      </div>
    </li>
    <li
      :style="imageStyle"
      class="image-add image-item"
      @click="addClick"
      v-if="canAdd && !disabled"
    >
      <div class="image-container">
        <van-icon name="photograph" />
      </div>
    </li>
    <van-image-preview
      id="vanImagePreview"
      v-model="vanImagePreview.show"
      :images="previewList"
      :showIndex="false"
      :start-position="vanImagePreview.index"
      :get-container="getContainer"
      @close="vanImagePreviewClose"
      @change="changePreviewIndex"
      @hook:beforeDestroy="clearConfirm"
    >
      <template v-slot:cover>
        <div class="tool-bar">
            <van-icon name="arrow-left" size="22px" @click='$router.back()'/>
            <span>{{vanImagePreview.index + 1 }} / {{previewList.length || 1 }}</span>
            <van-icon name="delete" class="delete-btn" size="22px" @click="deleteClick"/>
        </div>
      </template>
    </van-image-preview>
  </ul>
</template>

<script>
import { getResourceInfoById } from '@/framework/service/file-service'
import { deepClone, deepGet } from '@/framework/utils/common'
import { nativeUploadFileToServer } from '@/framework/service/native-service'
import { getResourceUrl } from '@/framework/service/file-service'
import { Icon, Image, ImagePreview, Dialog } from 'vant'
export default {
  name: 'image-upload',
  data: function() {
    return {
      // 资源数组
      list: [],
      vanImagePreview: {
        show: false,
        index: 0
      }
    }
  },
  components: {
    [Icon.name]: Icon,
    [Image.name]: Image,
    [ImagePreview.Component.name]: ImagePreview.Component
  },
  props: {
    sourceType: {
      type: Array,
      default: function() {
        return ['album', 'camera']
      }
    },
    /**
     * 最大数量
     */
    maxNum: {
      type: Number,
      default: 9
    },
    /**
     * 文件最大大小 B
     */
    maxSize: {
      type: Number
    },
    /**
     * 文件超出后提示
     */
    maxSizeErrorTip: {
      type: String,
      default: '您上传的文件超过限定的大小'
    },
    /**
     * 是否可用
     */
    disabled: {
      type: Boolean,
      default: false
    },
    columnNum: {
      type: Number,
      default: 4
    },
    canPreview: {
      type: Boolean,
      default: true
    },
    initResourceIds: {
      type: Array
    },
    navigationBarBgColor: {
      type: String,
      default: 'ffffff'
    }
  },
  computed: {
    /**
     * 当前文件数量
     */
    count() {
      return this.list ? this.list.length : 0
    },
    /**
     * 当前资源id数组
     */
    resourceIds() {
      return this.list.map(ele => {
        return deepGet(ele, 'resource.resourceId')
      })
    },
    /**
     * 是否可以添加新的资源
     */
    canAdd() {
      return this.count < this.maxNum
    },
    /**
     * 上传状态
     */
    uploadStatus() {
      const result = {
        total: this.list.length,
        uploaded: 0,
        error: 0,
        pending: 0
      }
      this.list.forEach(ele => {
        if (ele.status === 'uploaded') {
          result['uploaded']++
        } else if (ele.status === 'error') {
          result['error']++
        } else if (ele.status === 'pending') {
          result['pending']++
        }
      })
      return result
    },
    /**
     * 图片默认样式
     */
    imageStyle() {
      return {
        width: `${100 / this.columnNum}%`,
        paddingBottom: `${100 / this.columnNum}%`
      }
    },
    /**
     * 图片列表src数组
     */

    previewList() {
      return this.list.map(image => {
        return getResourceUrl(image.resource.resourceId) || image.localSrc
      })
    }
  },
  created() {
    this.initImageList()
  },
  methods: {
    // 获取完整资源列表
    getList() {
      return this.list
    },
    // 获取上传状态
    getUploadStatus() {
      return this.uploadStatus
    },
    // 获取上传文件的resourceid列表
    getResourceIds() {
      return this.resourceIds
    },
    triggerUploadChange(target) {
      this.$emit(
        'upload-change',
        deepClone({
          status: this.uploadStatus,
          resourceIds: this.resourceIds,
          target,
          list: this.list
        })
      )
    },
    /**
     * 删除图片
     */
    deleteClick() {
      Dialog.confirm({
        title: '提示',
        message: '确定要删除此图片吗？删除后将不可恢复。',
        overlay: false,
        confirmButtonColor: '#3388FF'
      })
        .then(() => {
          const idx = this.vanImagePreview.index
          const deletedFile = this.list.splice(idx, 1)[0]
          if (this.list.length === 0) {
            this.vanImagePreview.show = false
          } else if ((this.vanImagePreview.index + 1) > this.list.length) {
            this.vanImagePreview.index = this.list.length - 1
          }
          this.triggerUploadChange(deletedFile)
        })
        .catch(() => {
          console.log('取消')
        })
    },
    /**
     * 初始化imageList
     */
    initImageList() {
      this.list = []
      if (this.initResourceIds) {
        this.initResourceIds.forEach((resourceId, index) => {
          if (resourceId) {
            const image = {
              order: index,
              status: 'uploaded',
              resource: {
                resourceId
              }
            }
            getResourceInfoById(resourceId).then(resourceInfo => {
              if (resourceInfo) {
                this.$set(image, 'resource', resourceInfo)
              }
            })
            this.list.push(image)
          }
        })
      }
    },
    async nativeImageChoose() {
      return new Promise((resolve, reject) => {
        const params = {
          count: this.maxNum - this.count,
          sourceType: this.sourceType,
          success: function(res) {
            resolve(res)
          },
          fail: function(err) {
            console.log(err)
            reject(err)
          }
        }
        window.lx.media.chooseImage(params)
      })
    },
    async addClick() {
      const result = await this.nativeImageChoose()
      const exceedMaxSizeFiles = []
      for (const oFile of result.tempFiles) {
        if (this.maxSize > 0 && oFile.size > this.maxSize) {
          exceedMaxSizeFiles.push(oFile)
          continue
        }
        const localSrc = oFile.base64
        const image = {
          order: this.count,
          status: 'pending',
          localSrc,
          localId: oFile.localId,
          resource: {
            size: oFile.size
          },
          uploadProgress: 0,
          uploadTaskId: ''
        }
        this.list.push(image)
        this.triggerUploadChange(image)
        // 图片上传到服务器
        nativeUploadFileToServer(oFile.localId)
          .then(result => {
            console.log('addClick', result.data)
            if (result && result.errcode === 200) {
              image.status = 'uploaded'
              this.$set(image, 'resource', result.data)
            } else {
              image.status = 'error'
            }
            this.triggerUploadChange(image)
          })
          .catch(err => {
            console.log(err)
            image.status = 'error'
            this.triggerUploadChange(image)
          })
      }
      if (exceedMaxSizeFiles.length > 0) {
        this.$toast.fail(this.maxSizeErrorTip)
        this.triggerExceedMaxSize(exceedMaxSizeFiles)
      }
    },
    /**
     * 获取图片src
     */
    getImageSrc(image) {
      if (!image) return ''
      if (image.localSrc) return image.localSrc
      const resource = image.resource
      if (!resource) return ''
      const imageThumbnailList = resource.imageThumbnailList
      if (!imageThumbnailList) return getResourceUrl(resource.resourceId)
      if (imageThumbnailList[`${resource.resourceId}~400`]) {
        return getResourceUrl(`${resource.resourceId}~400`)
      } else if (imageThumbnailList[`${resource.resourceId}~200`]) {
        return getResourceUrl(`${resource.resourceId}~200`)
      } else if (imageThumbnailList[`${resource.resourceId}~800`]) {
        return getResourceUrl(`${resource.resourceId}~800`)
      }
      return ''
    },
    vanImagePreviewClose() {
      window.lx.ui.setNavigationBarBgColor({
        color: this.navigationBarBgColor
      })
    },
    getContainer() {
      return document.body
    },
    /**
     * 图片展示
     */
    showPreview(idx) {
      if (!this.disabled) {
        window.lx.ui.setNavigationBarBgColor({
          color: '000000'
        })
        this.vanImagePreview.index = idx
        this.vanImagePreview.show = true
        history.pushState('null', '图片选择', null)
        window.addEventListener('popstate', () => {
          this.vanImagePreview.show = false
        })
      } else {
        const params = {
          current: this.previewList[idx],
          urls: this.previewList,
          actions: ['save', 'share']
        }
        console.log(params)
        window.lx.media.previewImage(params)
      }
    },
    triggerExceedMaxSize(target) {
      this.$emit('exceed-max-size', target)
    },
    changePreviewIndex(index) {
      this.vanImagePreview.index = index
    },
    reloadImg(image) {
      if (image.status === 'error') {
        image.status = 'pending'
        nativeUploadFileToServer(image.localId)
          .then(result => {
            console.log('reloadClick', result.data)
            if (result && result.errcode === 200) {
              image.status = 'uploaded'
              this.$set(image, 'resource', result.data)
            } else {
              image.status = 'error'
            }
            this.triggerUploadChange(image)
          })
          .catch(err => {
            console.log('relaodErr', err)
            image.status = 'error'
            this.triggerUploadChange(image)
          })
      }
    },
    clearConfirm() {
      this.$dialog.close()
    }
  }
}
</script>

<style lang="scss" scoped>
/deep/ .van-loading__text {
  color: white;
}
.image-upload {
  display: flex;
  flex-wrap: wrap;
}
.image-item {
  box-sizing: border-box;
  position: relative;
  overflow: hidden;
  .image-container {
    position: absolute;
    top: 3px;
    bottom: 3px;
    left: 3px;
    right: 3px;
    overflow: hidden;
  }
  .mask {
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 9;
    cursor: default;
    text-align: center;
    color: #fff;
    font-size: 20px;
    background-color: rgba(50, 50, 51, 0.88);
    transition: opacity 0.3s;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .upload-delete {
    position: absolute;
    top: 0;
    right: 0;
    padding: 0 0 10px 10px; //增大删除区域
    z-index: 10;
    cursor: pointer;
    .upload-delete-icon {
      width: 16px;
      height: 16px;
      background: rgba(0, 0, 0, 0.7);
      border-radius: 0 0 0 14px;
    }
    i {
      position: absolute;
      right: 1px;
      top: 1px;
      transform: scale(0.8);
    }
  }
}
.image-add {
  .image-container {
    background-color: #f7f8fa;
  }
  .van-icon {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: #dcdee0;
    font-size: 24px;
  }
}
.upload-error {
  font-size: 12px;
}
#vanImagePreview {
  margin-top: constant(safe-area-inset-top);
  margin-top: env(safe-area-inset-top);
  background: black;
  /deep/ .van-image-preview__swipe{
    padding-top: 45px;
  }
  /deep/ .van-image-preview__cover {
    width: 100%;
    .tool-bar {
      padding: 10px 10px 0 10px;
      line-height: 22px;
      color: white;
      position: relative;
      span {
        vertical-align: top;
        margin-left: 10px;
      }
      .delete-btn {
        float: right;
        cursor: pointer;
      }
    }
  }
}
</style>
