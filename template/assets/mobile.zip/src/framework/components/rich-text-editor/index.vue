<template>
  <div class="rich-text-editor" ref="richTextContainer">
    <van-skeleton title animate :row="6" :loading="!dataLoaded">
      <div
        v-if="lazy"
        v-lazy-container="{ selector: 'img' }"
        v-html="richTextInfo.standardRichText"
        class="rich-text-container"
        @click="clickHandle"
      ></div>
      <div
        v-else
        v-html="richTextInfo.standardRichText"
        class="rich-text-container"
        @click="clickHandle"
      ></div>
    </van-skeleton>
  </div>
</template>

<script>
// 富文本组件，当前仅支持富文本的展示，后期可能会添加富文本的编辑
import { getRichTextByCode } from '@/framework/service/rich-text-service'
import { deepGet } from '@/framework/utils/common'
import { Skeleton } from 'vant'
import { getResourceUrl } from '@/framework/service/file-service'

import VueLazyload from 'vue-lazyload'
import Vue from 'vue'

Vue.use(VueLazyload, {
  preLoad: 1.3,
  attempt: 1
})

export default {
  name: 'rich-text-editor',
  data: function() {
    return {
      dataLoaded: false,
      richTextInfo: {
        code: '',
        richText: '',
        standardRichText: ''
      }
    }
  },
  props: {
    code: String,
    actions: {
      type: Array,
      default: function() {
        return ['save', 'share']
      }
    },
    lazy: Boolean
  },
  components: {
    [Skeleton.name]: Skeleton
  },
  watch: {
    code: {
      handler(val) {
        this.resetRichText(val)
      },
      immediate: true
    }
  },
  methods: {
    async resetRichText(code) {
      if (!code) {
        this.dataLoaded = true
        this.richTextInfo.code = ''
        this.richTextInfo.richText = ''
        return
      } else {
        this.dataLoaded = false
        const result = await getRichTextByCode(code)
        this.dataLoaded = true
        if (result.errcode === 200) {
          this.richTextInfo.code = deepGet(result, 'data.code')
          this.richTextInfo.richText = deepGet(result, 'data.richText')
          this.richTextInfo.standardRichText = this.getStandardRichText(this.richTextInfo.richText)
        } else {
          this.$emit('data-load-error', result)
        }
      }
      this.$nextTick(function() {
        this.$emit('render-completed')
      })
    },
    getStandardRichText(richText) {
      const rootElm = document.createElement('div')
      rootElm.innerHTML = richText
      rootElm.querySelectorAll('img').forEach(imgElm => {
        const resourceId = imgElm.getAttribute('data-resource-id')
        // 放置width属性导致的图片变形
        imgElm.removeAttribute('width')
        imgElm.removeAttribute('height')
        if (this.lazy) {
          imgElm.setAttribute(
            'data-src',
            resourceId ? getResourceUrl(resourceId) : imgElm.getAttribute('src')
          )
          imgElm.removeAttribute('src')
        } else {
          imgElm.setAttribute(
            'src',
            resourceId ? getResourceUrl(resourceId) : imgElm.getAttribute('src')
          )
        }
      })
      return rootElm.innerHTML
    },
    clickHandle(event) {
      const target = event.target
      if (!target) return
      if (target.nodeName === 'IMG' && target.getAttribute('src')) {
        const urls = []
        this.$refs.richTextContainer.querySelectorAll('img').forEach(imgElm => {
          urls.push(imgElm.getAttribute('data-src') || imgElm.getAttribute('src'))
        })
        const params = {
          current: target.getAttribute('src'),
          urls
        }
        if (this.actions) {
          params.actions = this.actions
        }
        console.log(params)
        window.lx.media.previewImage(params)
      } else if (
        target.nodeName === 'A' &&
        target.href
      ) {
        event.preventDefault()
        const params = {
          mode: 'webview',
          navigationBarBackgroundColor: '#4E74BB',
          navigationBarFrontStyle: 'white',
          url: target.href
        }
        console.log(params)
        window.lx.ui.openView(params)
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.rich-text-container {
  word-break: break-all;
  /deep/ img {
    width: 100%;
    height: auto !important;
  }
  /deep/ img[lazy="error"],
  /deep/ img[lazy="loading"] {
    width: 100%;
    height: 300px !important;
    background-color: #f2f6fc;
  }
}
</style>
