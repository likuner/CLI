import { login as userLogin, logout as userLogout, getUserInfo } from '@/framework/service/user-service'
import { getRoleList, roleCheck } from '@/api/user'
import { report } from '@/framework/service/track-service'
import { deepGet } from '@/framework/utils/common'
import router from '@/router'

const state = {
  token: '',
  staffId: '',
  userName: '',
  userInfo: null,
  roleList: [],
  currentRole: null,
  lisence: null
}

const mutations = {
  SET_TOKEN: (state, token) => {
    state.token = token
  },
  SET_USERINFO: (state, userinfo) => {
    state.userInfo = userinfo
  },
  SET_STAFF_ID: (state, staffId) => {
    state.staffId = staffId
  },
  SET_USERNAME: (state, userName) => {
    state.userName = userName
  },
  RESET_TOKEN: (state) => {
    state.token = ''
    state.userInfo = null
    state.staffId = ''
    state.userName = ''
  },
  SET_ROLE_LSIT: (state, list) => {
    state.roleList = list || []
  },
  SET_CURRENT_ROLE: (state, role) => {
    state.currentRole = role
  },
  SET_LISENCE: (state, lisence) => {
    state.lisence = lisence
  }
}

const actions = {
  // 用户登录
  async login({ commit }) {
    // 清空之前的数据
    commit('RESET_TOKEN')
    const res = await userLogin()
    if (res.errcode === 200) {
      commit('SET_TOKEN', res.data.token)
      commit('SET_STAFF_ID', res.data.staffId)
      commit('SET_USERNAME', res.data.name)
      commit('SET_LISENCE', res.data.licenseCheckInfo || {})
    }
    // 记录行为日志
    report({ 'actionName': 'login', 'dataSource': 'framework', 'taskType': 'user-login' })

    return !!deepGet(res, 'data.token')
  },
  // 刷新token
  async refreshToken({ dispatch, commit, state }) {
    const result = await userLogin()
    const data = result.data
    // 登录失败
    if (!(result.errcode === 200 && data)) { return false }
    // 登录成功 保存数据
    commit('SET_TOKEN', data.token)
    commit('SET_STAFF_ID', data.staffId)
    commit('SET_USERNAME', data.name)
    commit('SET_LISENCE', data.licenseCheckInfo || {})
    // 当前角色存在->重新绑定角色信息
    console.log('refreshToken', state.currentRole)
    if (state.currentRole && !await dispatch('setCurrentRole', state.currentRole)) {
      // 切换身份失败，身份异常页面
      router.replace({ path: '/error/500' })
      return false
    }
    // 记录行为日志
    report({ 'actionName': 'login', 'dataSource': 'framework', 'taskType': 'user-refresh-token' })
    return !!data.token
  },
  //获取权限列表
  async getRoleList({ commit }) {
    const res = await getRoleList()
    if (res.errcode === 200) {
      commit('SET_ROLE_LSIT', res.data || [])
      return res.data || []
    }
    commit('SET_ROLE_LSIT', null)
    return null
  },
  // 角色切换
  async setCurrentRole({ commit }, role) {
    if (!role) {
      return null
    }
    const res = await roleCheck(role)
    if (res.errcode === 200) {
      const currentRole = Object.assign({}, role, res.data)
      commit('SET_CURRENT_ROLE', currentRole)
      return currentRole
    }
    return null
  },
  // 获取用户信息
  async getUserInfo({ commit, state }, forceRefresh) {
    if (!forceRefresh && state.userInfo) {
      return state.userInfo
    }
    //获取用户信息
    const res = await getUserInfo(forceRefresh)
    if (res.errcode === 200) {
      commit('SET_USERINFO', res.data)
      return res.data
    }
  },
  // 退出登录
  logout({ commit, state }) {
    //TODO 调用登出接口，在服务端登出
    userLogout(state.token)
    commit('SET_TOKEN', '')
  }
}

export const userGetters = {
  token: state => state.user.token,
  userInfo: state => state.user.userInfo,
  userName: state => state.user.userName,
  staffId: state => state.user.staffId,
  domain: state => (state.user.staffId || '').split('-')[0],
  lisence: state => state.user.lisence,
  currentRole: state => state.user.currentRole,
  roleList: state => state.user.roleList
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
