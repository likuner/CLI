import createPersistedState from 'vuex-persistedstate'
import * as Cookies from 'js-cookie'
import { getAppId } from '@/framework/utils/common'

import user, { userGetters } from '@/framework/store/user'
import pageCache, { pageCacheGetters } from '@/framework/store/pageCache'
import settings, { settingsGetters } from '@/framework/store/settings'

// 获取local数据
const localGetItem = function(key) {
  try {
    const localKey = Cookies.get(key)
    return localKey ? localStorage.getItem(localKey) : null
  } catch (e) {
    console.error('vuex-persisted:get', e)
  }
}

// 写入local数据
const localSetItem = function(key, value) {
  const param = { expires: 1 }
  // 开发模式下可以注入到浏览器中
  if (process.env.ENV === 'production') {
    param.secure = true
  }
  // 为解决部分手机setItem异常，添加try catch
  try {
    Cookies.set(key, key, param)
    localStorage.setItem(key, value)
  } catch (e) {
    console.error('vuex-persisted:set', e)
  }
}

// 删除local数据
const localRemoveItem = function(key) {
  const localKey = Cookies.get(key)
  if (localKey) {
    localStorage.removeItem(localKey)
    Cookies.remove(key)
  }
}

export const modules = {
  pageCache,
  user,
  settings
}
export const getters = {
  ...userGetters,
  ...pageCacheGetters,
  ...settingsGetters
}
export function getPlugins(paths = []) {
  return createPersistedState({
    key: `vuex@${getAppId()}`,
    storage: {
      getItem: localGetItem,
      setItem: localSetItem,
      removeItem: localRemoveItem
    },
    paths: [
      'user.token',
      'user.staffId',
      'user.userName',
      'user.lisence',
      ...paths]
  })
}
