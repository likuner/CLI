const state = {
  //客户端设置的字体缩放系数(基于标准字号)    1 - 标准    1.25 - 大号    1.5 - 特大
  textSizeAdjust: 1
}

const mutations = {
  SET_TEXT_SIZE_ADJUST: (state, textSizeAdjust) => {
    state.textSizeAdjust = textSizeAdjust
  }
}

export const settingsGetters = {
  textSizeAdjust: state => state.user.textSizeAdjust
}

export default {
  namespaced: true,
  state,
  mutations
}
