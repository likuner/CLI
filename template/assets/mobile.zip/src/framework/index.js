import Vue from 'vue'
import LxJssdkPlugin from './plugins/lx-jssdk'
import fliterPlugin from './plugins/filter'
import './style/loading.scss'

Vue.use(fliterPlugin)
Vue.use(LxJssdkPlugin)

