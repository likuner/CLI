import { getQueryParams, getAppBaseApi } from '@/framework/utils/common'
import { getAppId } from '../utils/common'
import store from '@/store'
import { inLanxin } from '../utils/dev'
/**
 * 运行环境是否是否在蓝信内
 */
export function isInLanxin() {
  console.warn('该方法将被删除，请使用inlanxin环境变量(import { inLanxin } from "@/framework/utils/dev")')
  return inLanxin
}

/**
 * 获取authcode
 */
export async function getAuthCode() {
  // 在蓝信宿主环境
  if (inLanxin) {
    let i = 1
    // getauthcode重试机制，分别设置2、4、6秒的超时
    let code = ''
    while (i <= 3 && !code) {
      code = await getSDKAuthCode(2000 * i++)
      console.log(code)
    }
    return code
  } else {
    //非宿主内 从url上获取code
    return getQueryParams('code')
  }
}

function getSDKAuthCode(timeout = 2000) {
  return new Promise((resolve) => {
    setTimeout(() => {
      console.log('getAuthCode timeout', timeout)
      resolve(null)
    }, timeout)
    console.log('开始获取authcode')
    window.lx.biz.getAuthCode({
      appId: getAppId(),
      success: function(res) {
        console.log('getAuthCode end')
        resolve(res.authCode)
      },
      fail: function(e) {
        console.error('获取code失败', e)
        resolve(null)
      }
    })
  })
}

const fileQueue = []

/**
 * 队列中文件上传
 */
function uploadFile(immediate = false) {
  if (immediate) {
    const params = fileQueue[0]
    console.log('window.lx.utils.uploadFile', params)
    window.lx.utils.uploadFile(params)
  }
}

function nativeUploadCompluted() {
  fileQueue.shift()
  uploadFile(true)
}

/**
 * jssdk提供的文件上传能力
 */
export function nativeUploadFileToServer(localId) {
  return new Promise((resolve, reject) => {
    const params = {
      url: `${window.location.origin}${getAppBaseApi()}/resource/upload?appId=${getAppId()}`,
      localId,
      name: 'file',
      headers: { 'x-access-token': store.getters.token },
      success: function(res) {
        console.log('success', res.responseBody)
        nativeUploadCompluted()
        try {
          const result = typeof res.responseBody === 'string' ? JSON.parse(res.responseBody) : res.responseBody
          resolve(result)
        } catch (e) {
          resolve(null)
        }
      },
      fail: function(error) {
        console.log('fail', error)
        nativeUploadCompluted()
        reject(error)
      }
    }
    fileQueue.push(params)
    uploadFile(fileQueue.length === 1)
  })
}
