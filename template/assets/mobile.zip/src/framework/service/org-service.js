import request from '@/framework/utils/http-request'
import { deepGet } from '@/framework/utils/common'

/**
 * 根据分支的ID获取分支信息
 */
export function fetchOpenOrgStruct(structId) {
  return request('get', '/org/fetchOpenOrgStruct', { structId })
}

/**
 * 获取分支成员列表
 */
export function fetchOrgMemberList(structId, pageNo, pageSize) {
  const params = structId ? { structId, pageNo, pageSize } : { pageNo, pageSize }
  return request('get', '/org/fetchOrgMemberList', params)
}

/**
 * 获取某分支下全部人员信息
 * @param {*} structId 分支id
 */
export async function fetchALLStructMemberList(structId) {
  let pageNo = 1
  const result = {
    errcode: 200,
    data: []
  }
  let flag = true
  while (flag) {
    const res = await fetchOrgMemberList(structId, pageNo, 50)
    if (res.errcode === 200) {
      result.data.push(...res.data.result)
      if (deepGet(res, 'data.result', []).length < 50) {
        //加载完成
        flag = false
      } else {
        pageNo++
      }
    } else {
      result.errcode = res.errcode
      result.errmsg = res.errmsg
      flag = false
    }
  }
  return result
}

/**
 * 获取分支的子分支列表
 */
export async function fetchChildrenOpenOrgStructList(structId) {
  const params = structId ? { structId } : {}
  const result = await request('get', '/org/fetchChildrenOpenOrgStructList', params)
  if (result.errcode === 200) {
    result.data.forEach(ele => {
      ele.isLeaf = !ele.hasChildren
    })
  }
  return result
}

/**
 * 按照关键字搜索人员
 */
export function searchStatffListByKeyword(keyword, pageNo, pageSize = 20) {
  return request('get', '/org/searchStatffListByKeyword', { keyword, pageNo, pageSize })
}

/**
 * 获取标签分组列表
 */
export function fetchTagGroupList() {
  //"category": 1   1=人员标签
  return request('post', '/org/fetchTagGroupList', { 'category': 1 })
}

/**
 * 根据人员的标签获取人员的列表
 * @param {*} tagId 标签id
 * @param {*} pageNo 页码
 * @param {*} pageSize 每页条数
 */
export function fetchOrgMemberListByOneTag(tagId, pageNo, pageSize = 50) {
  return request('post', '/org/fetchOrgMemberListByOneTag', { tagId, pageNo, pageSize })
}

/**
 * 获取组织信息
 * @param {*} orgId 组织id
 */
export function fetchOpenOrgInfo(orgId) {
  return request('get', '/org/fetchOpenOrgInfo', { orgId })
}

/**
 * 获取获取人员信息
 */
export function fetchOpenOrgMember(staffId) {
  return request('get', '/org/fetchOpenOrgMember', { staffId })
}

/**
 * 获取人员明细信息
 */
export function fetchOpenOrgMemberDetailInfo(staffId) {
  return request('get', '/org/fetchOpenOrgMemberDetailInfo', { staffId })
}

/**
 * 根据标签获取人员ID列表
 */
export function fetchStaffIdListByOneTag(tagId, pageNo = 1, pageSize = 10) {
  return request('post', '/org/fetchStaffIdListByOneTag', { tagId, pageNo, pageSize })
}

/**
 *
 * 根据人员id数组获取人员
 */
export async function fetchOrgMemberListByStaffIds(staffIds) {
  const resData = []
  let count = 0
  while (count < staffIds.length) {
    const res = await request('post', '/org/fetchOpenOrgMemberByList', staffIds.slice(count, count + 50))
    if (res && res.errcode === 200) {
      resData.push(...res.data)
      count = count + 50
    } else {
      return res
    }
  }
  return {
    errcode: 200,
    errmsg: '成功',
    data: resData
  }
}

/**
 *
 * 根据组织id数组获取组织
 */
export async function fetchChildrenStructListByOrgStructList(OrgStructList) {
  const resData = []
  let count = 0
  while (count < OrgStructList.length) {
    const res = await request('post', '/org/fetchOpenOrgStructByList', OrgStructList.slice(count, count + 50))
    if (res && res.errcode === 200) {
      resData.push(...res.data)
      count = count + 50
    } else {
      return res
    }
  }
  return {
    errcode: 200,
    errmsg: '成功',
    data: resData
  }
}

/**
 * 按照关键字在对应范围搜索人员
 */
export function searchRangeStatffListByKeyword(data) {
  data.pageSize = data.pageSize || 20
  data.recursive = true
  return request('post', '/org/v2/searchStatffListByKeyword', data)
}
