import httpRequest, { baseRequest } from '@/framework/utils/http-request'
import { getAuthCode } from '@/framework/service/native-service'
import { getAppBaseApi, deepClone } from '@/framework/utils/common'
import store from '@/store'

/**
 * 获取签名
 */
export function getSignature(timestamp, nonceStr) {
  const params = {
    noncestr: nonceStr,
    timestamp,
    url: window.location.href.split('#')[0]
  }
  return httpRequest('post', '/auth/signature', params)
}

/**
 * 请求：使用code换取token
 * @param {*} code
 */
export function userLogin(authCode) {
  return baseRequest('post', '/user/login', { code: authCode })
}

/**
 * 获取用户信息
 */
export function userTestLogin(staffId) {
  return baseRequest('post', '/user/testLogIn', { staffId })
}

/**
 * 用户登录
 */
let LOGIN_QUEUE = []
let LOGIN_PENDING = false
export function login() {
  return new Promise(function(resolve) {
    LOGIN_QUEUE.push(resolve)
    if (!LOGIN_PENDING) {
      LOGIN_PENDING = true
      loginByDev().then(result => {
        LOGIN_PENDING = false
        LOGIN_QUEUE.forEach(cb => {
          cb(deepClone(result))
        })
        LOGIN_QUEUE = []
      })
    }
  })
}

export async function loginByDev() {
  return process.env.NODE_ENV === 'development' ? userTestLogin(window.localStorage.getItem('staffId')) : userLogin(await getAuthCode())
}

/**
 * 用户登出
 */
export function logout() {
  return httpRequest('post', '/user/logout')
}

/**
 * 获取用户信息
 */
let USERINFO_QUEUE = []
let USERINFO_PENDING = false
export function getUserInfo(forceRefresh) {
  if (forceRefresh) {
    return httpRequest('get', '/user/getUserInfo')
  }
  return new Promise(function(resolve) {
    USERINFO_QUEUE.push(resolve)
    if (!USERINFO_PENDING) {
      USERINFO_PENDING = true
      httpRequest('get', '/user/getUserInfo').then(result => {
        USERINFO_PENDING = false
        USERINFO_QUEUE.forEach(cb => {
          cb(deepClone(result))
        })
        USERINFO_QUEUE = []
      })
    }
  })
}

/**
 * @desc 获取用户信息
 * @param orgId {*组织id}
 * @param staffId {*人员id}
 */
export function isAdmin() {
  return httpRequest('get', '/user/isAdmin')
}

/**
 * 根据员工id获取人员头像的路径，该路径会重定向到用户头像的真实地址
 * @param {*} staffId
 */
export function getStaffAvatar(staffId) {
  return `${getAppBaseApi()}/user/getStaffAvatar?staffId=${staffId}&token=${store.getters.token}`
}
