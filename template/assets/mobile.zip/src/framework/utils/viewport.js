export function pageScale(scale) {
  if (typeof scale !== 'number') return
  console.log('scale', scale)
  const width =
    scale === 1
      ? 'device-width'
      : `${document.documentElement.clientWidth / scale}px`
  document
    .querySelector("meta[name='viewport']")
    .setAttribute(
      'content',
      `width=${width}, initial-scale=${scale}, maximum-scale=${scale}, minimum-scale=${scale}, viewport-fit=cover`
    )
}
