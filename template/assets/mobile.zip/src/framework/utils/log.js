/**
 * 日志持久化
 */
import { getAppId } from '@/framework/utils/common'
// import moment from 'moment'
import Dexie from 'dexie'
const LOG_EXPIRE_TIME = 3 * 24 * 60 * 60 * 1000
const db = new Dexie(`LOG@${getAppId()}`)
db.version(1).stores({ log: '++id,timestamp,level' })
export function startPersistedLog() {
  // 应用初始化时，先删除过期日志
  removeExpireLog()
  // 重写console
  mockConsole()

  // 监听window error
  window.addEventListener('error', handleListenerError, true)
  window.addEventListener('unhandledrejection', handleListenerError, true)
  window.onerror = function(msg, url, lineNo, columnNo, error) {
    // 捕捉错误
    log('error', msg, url, lineNo, columnNo, error)
  }
}

export function stopPersistedLog() {
  window.removeEventListener('error', handleListenerError)
  window.removeEventListener('unhandledrejection', handleListenerError)
}

function handleListenerError(event) {
  if (!event) return
  if (event instanceof PromiseRejectionEvent) {
    const reason = event.reason
    if (typeof reason.toJSON === 'function') {
      const params = reason.toJSON()
      if (params.config && params.config.data) {
        delete params.config.data
      }
      return log('error', 'unhandledrejection', params)
    } else {
      return log('error', 'unhandledrejection', event.reason)
    }
  }

  const target = event.target || event.srcElement
  if (target instanceof HTMLElement) {
    return log('error', '资源加载失败', target.outerHTML)
  }

  return log('error', event)
}

function mockConsole() {
  const methodList = ['log', 'info', 'warn', 'debug', 'error']

  if (!window.console) {
    window.console = {}
  }

  methodList.map(method => {
    window.console[method] = (...args) => log(method, args)
  })
}

const LOG_STACK = []
async function log(level = 'log', ...data) {
  if (data.length === 0) return
  return new Promise((resove, reject) => {
    // 日志入栈
    LOG_STACK.push({ p: { resove, reject }, data, level, timestamp: Date.now() })
    if (LOG_STACK.length === 1) {
      saveLog()
    }
  })
}

async function saveLog() {
  while (LOG_STACK.length) {
    const { p, timestamp, level, data } = LOG_STACK[0]
    try {
      p.resove(await db.log.add({ timestamp, level, data: toString(data) }))
    } catch (err) {
      console.log(err)
      // p.reject(err)
    } finally {
      LOG_STACK.shift()
    }
  }
}
/**
 * 其它格式转字符串
 * @param {*} arr
 */
function toString(arr) {
  return arr.map(ele => {
    try {
      if (Object.prototype.toString.call(ele) === '[object Error]') {
        return `${ele.message} ${ele.stack} `
      } else {
        return JSON.stringify(ele)
      }
    } catch (e) {
      return ele + ''
    }
  }).join(',')
}

/**
 * 删除过期日志
 */
function removeExpireLog() {
  // console.log(db.log.where('timestamp').below(Date.now() - LOG_EXPIRE_TIME).toArray())
  return db.log
    .where('timestamp').below(Date.now() - LOG_EXPIRE_TIME)
    .delete()
}
