import moment from 'moment'
import get from 'lodash.get'
import clonedeep from 'lodash.clonedeep'
import querystring from 'querystring'
/**
 * @desc 函数防抖
 * @param func 函数
 * @param wait 延迟执行毫秒数
 * @param immediate true 表立即执行，false 表非立即执行
 */
export function debounce(func, wait, immediate) {
  let timeout

  return function() {
    const context = this
    const args = arguments

    if (timeout) clearTimeout(timeout)
    if (immediate) {
      const callNow = !timeout
      timeout = setTimeout(() => {
        timeout = null
      }, wait)
      if (callNow) func.apply(context, args)
    } else {
      timeout = setTimeout(function() {
        func.apply(context, args)
      }, wait)
    }
  }
}

export function deepClone(obj) {
  return clonedeep(obj)
}

/**
 * 文件大小格式化转化
 * @param {*} fileSize 文件大小 B
 * @param {*} precision 精度
 */
export function formatFileSize(fileSize, precision) {
  if (!precision) precision = 0
  if (fileSize < 1024) {
    return fileSize.toFixed(precision) + 'B'
  } else if (fileSize < (1024 * 1024)) {
    let temp = fileSize / 1024
    temp = temp.toFixed(precision)
    return temp + 'KB'
  } else if (fileSize < (1024 * 1024 * 1024)) {
    let temp = fileSize / (1024 * 1024)
    temp = temp.toFixed(precision)
    return temp + 'MB'
  } else {
    let temp = fileSize / (1024 * 1024 * 1024)
    temp = temp.toFixed(precision)
    return temp + 'GB'
  }
}

export function shortNum(value) {
  let num = value || 0
  if (isNaN(num)) return ''
  num = num * 1
  if (num <= 9999) return num + ''
  return Math.round(num / 1000) / 10 + '万'
}

export function formatDate(datetime, fmt) {
  if (datetime === null || datetime === undefined) {
    return ''
  } else {
    return moment(datetime).format(fmt)
  }
}

/**
 * 根据minetype获取文件类型
 * @param {*} mimeType
 */
export function getExtNameByMimeType(mimeType) {
  if (mimeType.startsWith('audio/')) {
    return 'audio'
  }
  if (mimeType.startsWith('video/')) {
    const index = mimeType.indexOf('/')
    if (index >= 0) {
      return mimeType.substring(index + 1)
    }
    return 'mov'
  }

  switch (mimeType) {
    case 'image/jpeg':
      return 'jpeg'
    case 'image/png':
      return 'png'
    case 'image/x-ms-bmp':
      return 'bmp'
    case 'application/msword':
    case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
    case 'application/vnd.ms-word.template.macroEnabled.12':
    case 'application/vnd.ms-word.document.macroEnabled.12':
    case 'application/vnd.openxmlformats-officedocument.wordprocessingml.template':
      return 'docx'
    case 'application/vnd.ms-excel':
    case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':
    case 'application/vnd.openxmlformats-officedocument.spreadsheetml.template':
    case 'application/vnd.ms-excel.template.macroEnabled.12':
    case 'application/vnd.ms-excel.sheet.macroEnabled.12':
    case 'application/vnd.ms-excel.sheet.binary.macroEnabled.12':
    case 'application/vnd.ms-excel.addin.macroEnabled.12':
      return 'xlsx'
    case 'application/vnd.ms-powerpoint':
    case 'application/vnd.openxmlformats-officedocument.presentationml.presentation':
    case 'application/vnd.openxmlformats-officedocument.presentationml.template':
    case 'application/vnd.openxmlformats-officedocument.presentationml.slideshow':
    case 'application/vnd.ms-powerpoint.presentation.macroEnabled.12':
    case 'application/vnd.ms-powerpoint.template.macroEnabled.12':
    case 'application/vnd.ms-powerpoint.addin.macroEnabled.12':
    case 'application/vnd.ms-powerpoint.slideshow.macroEnabled.12':
      return 'pptx'
    case 'application/pdf':
      return 'pdf'
    case 'text/html':
      return 'html'
    case 'text/plain':
      return 'txt'
    case 'text/xml':
      return 'xml'

    default:
      break
  }
  return ''
}

export function deepGet(object, path, defaultValue) {
  const ret = get(object, path, defaultValue)
  if (defaultValue !== undefined && ret === null) {
    return defaultValue
  } else {
    return ret
  }
}

export function guid() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    var r = Math.random() * 16 | 0
    var v = c === 'x' ? r : (r & 0x3 | 0x8)
    return v.toString(16)
  })
}

/**
 * 获取base api
 */
export function getAppId() {
  // 优先从window中获取（为了配合生产环境发包，自动出传入）
  return window.VUE_APP_ID === 'APPID' ? process.env.VUE_APP_ID : window.VUE_APP_ID
}

/**
 * 获取base api
 */
export function getAppBaseApi() {
  if (process.env.NODE_ENV !== 'production') {
    // 本地开发使用配置中的baseapi
    return process.env.VUE_APP_BASE_API
  } else {
    // 生产环境，如果注入了baseapi使用注入的值，没有注入则使用默认规则
    const baseApi = new URL('../server', location.origin + location.pathname).pathname
    return window.VUE_APP_BASE_API === 'BASEAPI' || !window.VUE_APP_BASE_API ? baseApi : window.VUE_APP_BASE_API
  }
}

/**
 * 获取路径查询参数
 * @param {*} key
 */
export function getQueryParams(key) {
  return querystring.parse(window.location.search.slice(1))[key] || ''
}

export function formatTime(time, fmt) {
  const date = new Date()
  let t = date.getTime() - time
  const min = 60 * 1000
  if (t < min) return '刚刚'
  const hour = min * 60
  if (t < hour) {
    t = Math.ceil(t / min)
    return `${t}分钟前`
  }
  const day = hour * 24
  if (t < day) {
    t = Math.ceil(t / hour)
    return `${t}小时前`
  }
  const currentYear = date.getFullYear()
  const timeYear = new Date(time).getFullYear()
  if (!fmt) {
    fmt = 'YYYY-MM-DD HH:mm'
  }
  if (currentYear === timeYear) {
    const str = fmt.replace(/y/gi, '')
    const pattern = new RegExp('^[a-zA-Z]')
    if (!pattern.exec(str)) {
      //若首字符不是字母则去掉首个字符
      fmt = str.substr(1, str.length - 1)
    }
  }
  return moment(time).format(fmt)
}

/**
 * 判断当前设备是否是IOS
 */
export function isIOS() {
  const u = navigator.userAgent
  return !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/)
}

/**
 *判断当前设备是否是Android
 */
export function isAndroid() {
  const u = navigator.userAgent.toLowerCase()
  return u.indexOf('Android') > -1 || u.indexOf('Adr') > -1
}

/**
 * 加载js
 * name js文件名称，唯一的key
 * src 资源地址
 */
const LOADED_SCRIPT = new Map()
export async function loadScript(name, src) {
  // 脚本未加载
  if (!LOADED_SCRIPT.has(name)) {
    return new Promise(resolve => {
      LOADED_SCRIPT.set(name, [resolve])
      load(name, src).then(result => {
        const cbList = LOADED_SCRIPT.get(name)
        if (result && result.loaded) {
          cbList.forEach(cb => cb(true))
          LOADED_SCRIPT.set(name, [])
        } else {
          cbList.forEach(cb => cb(false))
          LOADED_SCRIPT.delete(name)
        }
      })
    })
  } else if (LOADED_SCRIPT.get(name).length > 0) {
    // 脚本加载中
    return new Promise(resolve => {
      LOADED_SCRIPT.set(name, LOADED_SCRIPT.get(name).concat(resolve))
    })
  } else {
    // 脚本已加载
    return true
  }
}

function load(name, src, type = 'js') {
  let script
  if (type === 'css') {
    script = document.createElement('link')
    script.rel = 'stylesheet'
    script.href = src
  } else {
    script = document.createElement('script')
    script.type = 'text/javascript'
    script.src = src
  }
  return new Promise(resolve => {
    if (script.readyState) { //IE
      script.onreadystatechange = () => {
        if (script.readyState === 'loaded' || script.readyState === 'complete') {
          script.onreadystatechange = null
          resolve({ script: name, loaded: true })
        }
      }
    } else { //Others
      script.onload = () => {
        console.log(name + 'loaded')
        resolve({ script: name, loaded: true })
      }
    }
    script.onerror = () => resolve({ script: name, loaded: false })
    document.getElementsByTagName('head')[0].appendChild(script)
  })
}

/**
 * 获取默认角色
 * @param {*} roleList
 * @param {*} powerTypeArr
 * @param {*} powerCode
 */
export function getDefaultRole(roleList, powerType = '', powerCode = '') {
  let powerTypeArr = []
  if (powerType) {
    powerTypeArr = powerType.split(',')
  }
  let role = null
  if (powerTypeArr.length) {
    let idx = powerTypeArr.length
    roleList.forEach(ele => {
      const curIdx = powerTypeArr.indexOf(ele.powerType + '')
      if (curIdx > -1 && idx > curIdx && (!powerCode || powerCode === ele.powerCode)) {
        role = ele
        idx = curIdx
      }
    })
  } else if (powerCode) {
    // 只传了powerCode
    for (const ele of roleList) {
      if (ele.powerCode === powerCode) {
        role = ele
        break
      }
    }
  }
  return role
}
