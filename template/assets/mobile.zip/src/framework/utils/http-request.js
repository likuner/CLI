import axios from 'axios'
import store from '@/store'
import { getAppBaseApi, guid } from '@/framework/utils/common'

//默认的请求头
axios.defaults.headers = { 'Content-Type': 'application/json; charset=UTF-8' }
axios.defaults.timeout = 10000
//基础路径
axios.defaults.baseURL = getAppBaseApi()
const Axios = axios.create()

//请求默认添加请求头
Axios.interceptors.request.use(
  config => {
    if (store.getters.token) {
      config.headers['x-access-token'] = store.getters.token
    }
    const id = `m-${guid()}`
    config.headers['x-lanxin-request-rid'] = id
    // 过期，2.0.1之后版本无效，之后代码会删除
    config.headers['app-trace-id'] = id
    return config
  },
  error => {
    return Promise.reject(error)
  }
)

Axios.interceptors.response.use(
  response => {
    return [200, 304].indexOf(response.status) > -1 ? Promise.resolve(response) : Promise.reject(response)
  },
  error => {
    console.error('interceptors-response', error)
    return Promise.reject(error)
  }
)

/**
 *
 * @param {*} method 请求方式
 * @param {*} url 请求url 相对路径，相对于baseurl
 * @param {*} data
 */
export const baseRequest = async(method, url, data = {}) => {
  console.warn('请求调试', method, url, data)
  const httpDefaultOpts = { method: method, url: url }
  if (method === 'post') {
    httpDefaultOpts.data = data || {}
  } else {
    httpDefaultOpts.params = data
  }
  let result
  try {
    result = await Axios(httpDefaultOpts)
    return result.data
  } catch (e) {
    //请求异常
    console.error('httpService', e)
    if (e && e.response && e.response.status === 401) {
      return { errcode: 401, errmsg: '登录已过期', data: null }
    } else {
      return { errcode: 500, errmsg: '请求发生异常', data: null }
    }
  }
}

const httpRequest = async(method, url, data) => {
  const result = await baseRequest(method, url, data)
  if (result.errcode === 401) {
    console.error(401, 401)
    await store.dispatch('user/refreshToken')
    return await baseRequest(method, url, data)
  } else {
    return result
  }
}

export default httpRequest
