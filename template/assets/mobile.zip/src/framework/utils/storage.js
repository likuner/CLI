/**
 * 大数据存储
 */
import localforage from 'localforage'
import { getAppId } from '@/framework/utils/common'

export const cacheStorge = localforage.createInstance({ name: `CACHE@${getAppId()}` })
