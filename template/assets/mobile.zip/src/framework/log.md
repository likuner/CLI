# 更新记录

#### 【2.0.3-alpha.3】2021年9月9日

修改文件列表

framework

package.json

vue.config.js

修改内容

1. 优化打包信息输出
2. 将公共路由抽离，方便之后应用更新
3. 完善vuex本地持久化异常处理
4. 图片上传组件体验优化、bug修改
5. 新增范围选人组件
6. 头像显示组件bug修复，添加是否需打开蓝名片参数
7. 附件上传黑名单优化
8. 图片上传bug修复

#### 【2.0.1-alpha.6】

修改文件列表

framework

router/index

store/index

App.vue

main.js

router-interceptor.js

修改内容

1. 获取用户信息接口优化
2. 应用默认不在随蓝信字体放大而放大
3. 异常页面JS代码提前载入
4. shortNum提取到公共方法并导出
5. 修复第二次进入应用验签失败BUG
6. 优化vuex初始化配置信息
7. 优化lxconfig流程，暴露全局变量lxconfig完成
8. 删除断网页面跳转逻辑

#### 【2.0.1-alpha.5】

修改文件列表

framework

修改内容

1. 添加更多的环境变量导出，例如isIOS、isAndroid、inLanxin等
2. 优化http请求的trace-id参数，添加移动端标识
3. 优化时间格式化方法

#### 【2.0.1-alpha.4】2021年3月12日

修改文件列表

framework

修改内容

1. 优化登录mock数据

#### 【2.0.1-alpha.3】2021年1月29日

修改文件列表

framework
mock/index
mock/role-data
api/user
router-interceptor

修改内容：

1. 移动端添加角色概念，并添加对应的角色列表获取和切换接口
2. 请求头添加唯一标识，配合后端避免nginx重复提交
3. IOS 13.4 图片旋转问题修改
4. user中增加domain全局变量

#### 【1.7】2021年1月15日

文件列表

framework

public

.env.development

.env.production

.env.staging

package.json

vue.config.js

src/App.vue

src/style/reset.scss

src/style/common.scss

src/store/index.js

修改内容

1. 添加行为日志开关，可选择启用还是关闭
2. 添加粘贴板clipboard依赖
3. 支持pc端蓝信卡片消息打开web端页面
4. 更新官网最新的jssdk
5. 图片选择上传、删除优化，提供更多的方法
6. 在titlebar中添加隐藏入口；box-shadow显示优化；不再在组件内提供IOS兼容性支持
7. 兼容新老打包方式获取baseapi
8. 优化store导出
9. vant字体本地化
10. 日志持久化功能添加，可以通过VUE_APP_LOG_PERSISTED属性开启或者关闭
11. 添加公共环境变量
12. 页面级别的IOS兼容优化
13. 优化authcode获取，添加重试机制，重试三次（1.7.1）
14. 修复开发环境testlogin无法切换登录用户bug（1.7.1）
15. index.html、redirect.js兼容安卓5.1优化（1.7.2）
16. 登录相关mock数据优化（1.7.2）
17. 应用初始化loading优化（1.7.3）

#### 【1.6】2020年12月31日

文件列表

framework

router/index.js

style/mixin.scss

package.json

修改内容

1. 根据资源id获取资源路径优化
3. 验签优化，只有在蓝信宿主内再进行验签
3. vuex本地化优化，减少cookie控件的占用
4. 添加超出省略和0.5px border scss函数
5. 添加更多异常的路由页面
6. 资源id换取重定向路径，拼接优化

#### 【1.5】2020年12月11日

文件列表

framework

vue.config

router-interceptor

package.json

修改内容

1. 富文本优化，支持富文本图片懒加载
2. 修复getuserinfo接口mock数据bug
3. 添加移动端选人控件
4. vant字体拉取本地字体文件
5. 统一titlebar返回按钮图标
7. 401、403、404、500、无网络异常页面添加
8. 优化framework内置store导出方式
8. 前端代理更新为最新测试地址
9. 全局路由拦截优化
10. 删除冗余代码及其它代码优化

#### 【1.4】2020年11月13日

文件列表

framework
mock/index.js

修改内容

1. 用户头像bug修改
2. 新增titlebar组件
3. 用户登录mock数据完善
4. 附件上传取消上传bug修复
5. 新增附件上传清空方法
6. 附件上传添加自定义文件大小超出提示语
7. 图片上传添加自定义文件大小超出提示语

#### 【1.3】2020年10月28日

文件列表

framework
.env.development
.env.staging
.env.production
package.json

修改内容

1. 通过base64加密行为日志信息
2. 图片预览组件展示图片功能优化
3. 大文件上传组件优化
4. deepClone方法优化