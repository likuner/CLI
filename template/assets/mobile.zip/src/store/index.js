import Vue from 'vue'
import Vuex from 'vuex'
import { modules, getters, getPlugins } from '@/framework/store'
Vue.use(Vuex)

export default new Vuex.Store({
  modules: {
    // framework 默认module
    ...modules
  },
  getters: {
    // framework 默认getter
    ...getters
  },
  // framework 默认插件
  plugins: [getPlugins()],
  strict: process.env.NODE_ENV !== 'production'
})
