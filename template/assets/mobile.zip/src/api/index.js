import httpRequest from '@/framework/utils/http-request'

/**
* @param {*} params
*/
export function demo(params) {
  return httpRequest('get', '/request/path', params)
}
