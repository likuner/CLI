import request from '@/framework/utils/http-request'

/**
 * 移动端获取权限列表
 * !!!请勿修改函数名称
 */
export async function getRoleList() {
  const result = await request('get', '/custom/power/userList')
  console.log(result)
  if (result.errcode === 200) {
    result.data.forEach(element => {
      element.powerId = `${element.powerCode}@${element.powerType}`
    })
  }
  return result
}

/**
 * 移动端角色切换
 * !!!请勿修改函数名称
 * @param {*} params
 */
export async function roleCheck(params) {
  console.log('roleCheck')
  return request('post', '/custom/power/update', params)
}
