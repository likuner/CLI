<template>
  <div class="home lx-page">
    <div class="lx-container">
      <h1>HOME</h1>
    </div>
  </div>
</template>
<script>
export default {
  name: 'home',
  data() {
    return { }
  }
}
</script>
<style scoped lang="scss">
.lx-container{
  padding: 20px
}
</style>
