# 说明

## 版本

1.4

## 规范

路径参数：entrance=
expand：从扩展屏进入
  
