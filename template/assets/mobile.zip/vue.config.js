const webpack = require('webpack')
const CompressionPlugin = require('compression-webpack-plugin')
const HtmlPrettyConsoleWebpackPlugin = require('html-pretty-console-webpack-plugin')

module.exports = {
  // 基本路径
  publicPath: './',
  productionSourceMap: process.env.ENV !== 'production',
  chainWebpack: config => {
    config.plugins.delete('preload')
    config.plugins.delete('prefetch')

    config
      .plugin('html')
      .tap(args => {
        if (process.env.ENV === 'staging') {
          args[0].externalJs = ['vendors/vconsole.min.js']
        }
        /* 日志持久化 */
        args[0].logPersisted = process.env.VUE_APP_LOG_PERSISTED === 'true'
        args[0].buildDatetime = new Date().toString()
        return args
      })
    config.when(process.env.NODE_ENV !== 'development', config => {
      config.plugin('ignore')
        .use(new webpack.ContextReplacementPlugin(/moment[/\\]locale$/, /zh-cn$/))
      //开启静态GZip 配合nginx gzip_static: on
      config.plugin('compressionPlugin')
        .use(new CompressionPlugin({ test: [/\.js/, /\.css/], threshold: 10240 }))
    })
    config.plugin('html-pretty-console').use(new HtmlPrettyConsoleWebpackPlugin({
      output: [
        { label: '打包时间', value: new Date().toString() }
      ]
    }))
  },
  devServer: {
    // 请求代理
    proxy: {
      '/': {
        target: 'https://app-intranet-blue.t.lanxin.cn/',
        changeOrigin: true,
        ws: true
      }
    }
  }
}
