const webpack = require('webpack')
const GitRevisionPlugin = require('git-revision-webpack-plugin')
const gitRevisionPlugin = new GitRevisionPlugin()
const CompressionPlugin = require('compression-webpack-plugin')
const HtmlPrettyConsoleWebpackPlugin = require('html-pretty-console-webpack-plugin')

module.exports = {
  // 基本路径
  publicPath: './',
  productionSourceMap: false,
  chainWebpack: config => {
    config.plugins.delete('preload')
    config.plugins.delete('prefetch')
    config
      .plugin('html')
      .tap(args => {
        return args
      })
    config.plugin('ignore')
      .use(new webpack.ContextReplacementPlugin(/moment[/\\]locale$/, /zh-cn$/))

    config.when(process.env.NODE_ENV === 'development', config => {
      config.devtool('cheap-source-map')
    })
    config.when(process.env.NODE_ENV !== 'development', config => {
      config.optimization.splitChunks({
        chunks: 'all',
        cacheGroups: {
          common: {
            name: 'chunk-common',
            chunks: 'initial',
            minChunks: 2,
            maxInitialRequests: 5,
            minSize: 0,
            priority: 1,
            reuseExistingChunk: true,
            enforce: true
          },
          libs: {
            name: 'chunk-libs',
            test: /[\\/]node_modules[\\/]/,
            chunks: 'initial',
            priority: 3,
            reuseExistingChunk: true,
            enforce: true
          },
          elementUI: {
            name: 'chunk-elementui',
            test: /[\\/]node_modules[\\/]element-ui[\\/]/,
            chunks: 'all',
            priority: 5,
            reuseExistingChunk: true,
            enforce: true
          },
          xlxs: {
            name: 'chunk-xlxs',
            test: /[\\/]node_modules[\\/]xlxs[\\/]/,
            chunks: 'all',
            priority: 5,
            reuseExistingChunk: true,
            enforce: true
          }
        }
      })

      config.plugin('gitRevisionPlugin').use(gitRevisionPlugin)
      //开启静态GZip 配合nginx gzip_static: on
      config.plugin('compressionPlugin').use(new CompressionPlugin({
        test: [/\.js/, /\.css/],
        //10kb以上生成对应的gzip文件
        threshold: 10240
      }))

      config.plugin('html-pretty-console').use(new HtmlPrettyConsoleWebpackPlugin({
        output: [
          { label: '打包时间', value: new Date().toString() },
          { label: '打包分支', value: `${gitRevisionPlugin.branch()} | ${gitRevisionPlugin.commithash()}` }
        ]
      }))
    })
  },
  devServer: {
    // 请求代理
    proxy: {
      '/': {
        target: 'https://app-intranet-blue.t.lanxin.cn/',
        changeOrigin: true,
        ws: true
      }
    }
  }
}
