const DEFAULT_TITLE = '蓝信'
export default function getPageTitle(pageTitle) {
  return pageTitle || DEFAULT_TITLE
}
