import request from '@/framework/utils/http-request'

/**
 * 获取权限列表
 */
export async function getRoleList() {
  const result = await request('get', '/custom/power/userList')
  if (result.errcode === 200) {
    result.data.forEach(element => {
      element.powerId = `${element.powerCode}@${element.powerType}`
    })
  }
  return result
}

export async function roleCheck(params) {
  return request('post', '/custom/power/update', params)
}
