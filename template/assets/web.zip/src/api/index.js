import request from '@/framework/utils/http-request'

/**
 * 请求示例
 */
export function requestDemo(params) {
  return request('get', '/request/path', params)
}
