import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from '@/store'
import '@/theme/index.css'
import ElementUI from 'element-ui'
import i18n from '@/framework/langs'
import '@/style/element-ui-reset.scss'
import '@/style/common.scss'

import '@/framework/index'

import '@/mock/index'

import './router-interceptor'

Vue.config.productionTip = false

Vue.use(ElementUI, {
  i18n: (key, value) => i18n.t(key, value)
})

new Vue({
  render: h => h(App),
  router,
  store,
  i18n
}).$mount('#app')
