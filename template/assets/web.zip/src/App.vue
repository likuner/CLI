<template>
  <div id="app" style="height: 100%;" v-loading="!loaded && show">
    <router-view @hook:mounted="loaded = true" v-if="show"/>
  </div>
</template>

<script>
import Vue from 'vue'
import { report } from './framework/service/track-service'
import { mapGetters, mapMutations } from 'vuex'
import LisenceDialog from '@/framework/pages/error/lisence/lisence-dialog'
import SuccessDialog from '@/framework/pages/error/lisence/success-dialog'

export default {
  data() {
    return {
      loaded: false,
      show: true
    }
  },
  computed: {
    ...mapGetters(['token', 'roleList', 'lisence', 'isLisenceAdmin'])
  },
  watch: {
    lisence: {
      immediate: true,
      handler(newVal) {
        if (process.env.NODE_ENV !== 'development') {
          if (newVal === null && this.isLisenceAdmin === null) {
            return
          }
          this.openLisenceDialog()
        }
      }
    }
  },
  methods: {
    ...mapMutations('user', ['SET_LISENCE']),
    openLisenceDialog() {
      if (!(this.lisence && this.lisence.status === 1 && this.lisence.remainingDays > 7)) {
        this.show = false
        const self = this
        const options = {
          lisence: self.lisence,
          isLisenceAdmin: self.isLisenceAdmin,
          cancelCbk() {
            console.log('--lisence-dialog-close--')
            self.show = true
          },
          confirmCbk(data) {
            console.log('--lisence-dialog-confirm--')
            self.SET_LISENCE({
              status: 1,
              remainingDays: 8,
              licenseEndTime: Number(data)
            })
            self.openScuuessDialog(data)
          }
        }
        const ALisenceDialog = Vue.extend(LisenceDialog)
        return new ALisenceDialog({
          propsData: {
            options
          }
        }).$mount()
      }
    },
    openScuuessDialog(data) {
      const self = this
      const options = {
        licenseEndTime: data,
        closeCbk() {
          self.show = true
        }
      }
      const ASuccessDialog = Vue.extend(SuccessDialog)
      return new ASuccessDialog({
        propsData: {
          options
        }
      }).$mount()
    }
  },
  created() {
    const trackReport = () => report({ taskType: 'page-leave' }, true)
    window.addEventListener('beforeunload', trackReport)
    this.$once('hook:beforeDestory', () => {
      window.removeEventListener('beforeunload', trackReport)
    })
  }
}
</script>
