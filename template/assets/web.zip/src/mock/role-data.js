const roleList = {
  url: RegExp('custom/power/userList' + '.*'),
  method: 'get',
  data: {
    'errcode': 200,
    'errmsg': '成功',
    'data': [
      {
        'groupName': '应用管理员', //权限分组名称
        'powerCode': '000001', //角色/板块code
        'powerName': 'YFADMIN', //角色/板块名称
        'powerType': 0, // 权限类型 0:应用管理员 1：板块管理员 3:自定义角色管理员 4\5\6
        'powerTypeName': '应用管理员'	 // 权限类型名称
      },
      {
        'groupName': '分支管理员',
        'powerCode': '000002',
        'powerName': '应用开发部',
        'powerType': 1,
        'powerTypeName': '分支管理员'
      },
      {
        'groupName': '自定义角色管理员',
        'powerCode': '000003',
        'powerName': '考勤统计员',
        'powerType': 2,
        'powerTypeName': '自定义角色管理员'
      }
    ]
  }
}

const roleCheck = {
  url: RegExp('custom/power/update' + '.*'),
  method: 'post',
  data: function(params) {
    const reqData = JSON.parse(params.body)
    return {
      'errcode': 200,
      'errmsg': '成功',
      'data': {
        'dataSource': '', // 自定义参数
        'powerType': reqData.powerType
      }
    }
  }
}

export default [
  roleList,
  roleCheck
]
