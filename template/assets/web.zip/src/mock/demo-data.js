/**
 * mock示例
 */

const mockDemo = {
  url: RegExp('/request/path' + '.*'),
  method: 'get',
  data: {
    'errcode': 200,
    'errmsg': '成功',
    'data': {
      'pageNo': 0,
      'pageSize': 0,
      'pages': 0,
      'result': new Array(20).fill(0).map(() => {
        return {
          'id': '@id',
          'name': '@cname',
          'createTime': Date.now()
        }
      }),
      'total': 200
    }
  }
}

export default [
  mockDemo
]
