import Mock from 'mockjs'

// 角色权限列表数据 /userInfo/myRole
import roleData from './role-data'

// ADMIN权限 CMC页面相关数据
import cmcData from '@/framework/mock/cmc-data'

// user相关数据
import userData from '@/framework/mock/user-data'

// 选人相关数据
import orgData from '@/framework/mock/org-data'

// 导出自定义mock数据
import demoData from './demo-data'

Mock.setup({
  timeout: 800 // 设置延迟响应，模拟向后端请求数据
})

const mockArr = [
  ...cmcData,
  ...userData,
  ...orgData,
  ...roleData,
  ...demoData
]

mockArr.forEach(ele => {
  Mock.mock(ele.url, ele.method, ele.data)
})

