import Vue from 'vue'
import Router from 'vue-router'
import getRoutesByRole from './role-router'
import store from '@/store'
import { Loading } from 'element-ui'
import { deepClone } from '@/framework/utils/common'

Vue.use(Router)

/**
 * meta : {
    title: 'title'                   导航名称包一级、二级导航，面包屑导航等
    breadcrumb: [{name:'',path:''}]  在面包屑导航中隐藏
    activeMenu: 'name'               导航展示的活跃路由名称
    hidden: true                     不在导航中显示，默认是false
  }
 */

//基础导航
export const baseRoutes = [
  {
    path: '/switch-identity',
    name: 'switch-identity',
    component: () => import('@/framework/pages/switch-identity/index'),
    meta: {
      title: '身份选择',
      hidden: true
    }
  },
  {
    path: '/error/500',
    name: 'error500',
    component: () => import('@/framework/pages/error/error500')
  },
  {
    path: '/error/403',
    name: 'error403',
    component: () => import('@/framework/pages/error/error403')
  }
]

const createRouter = () => new Router({
  scrollBehavior: () => ({ y: 0 }),
  routes: baseRoutes
})

const router = createRouter()

export async function resetRouter(role) {
  const loading = Loading.service({ lock: true, text: '角色切换中...' })
  const newRouter = createRouter()
  const roleRoutes = await getRoutesByRole(role)
  router.matcher = newRouter.matcher
  router.addRoutes(roleRoutes)
  store.commit('routesCache/SET_ROUTES', deepClone([...baseRoutes, ...roleRoutes]))
  Vue.nextTick(function() { loading.close() })
}

export default router
