import Layout from '@/framework/layout'

const commonRouter = [{
  path: '/error',
  component: Layout,
  hidden: true,
  children: [
    {
      path: '404',
      name: 'Page404',
      component: () => import('@/framework/pages/error/error404'),
      meta: { title: '404', hidden: true }
    }
  ]
},
{
  path: '*',
  redirect: '/error/404'
}
]
/**
 * 应用运营者
 */
const adminRole = [
  ...commonRouter
]

const cmcRole = [{
  path: '/',
  component: Layout,
  redirect: '/home',
  name: 'home',
  children: [
    {
      path: 'home',
      component: () => import('@/pages/home'),
      name: 'home',
      meta: { title: '主页' }
    }
  ],
  meta: { title: '主页' }
},
...commonRouter /* 必须添加且必须在最后 */
]

/**
 * 业务自定义角色
 */
const customRole = [
  ...commonRouter /* 必须添加且必须在最后 */
]
/*
 * 根据角色获取对应的路由
 * @param {*} role
 */
async function getRoutesByRole(role) {
  let result = adminRole
  if (role.powerType === 0) {
    result = adminRole
  }
  if (role.powerType === 1) {
    result = cmcRole
  }
  if (role.powerType === 2) {
    result = customRole
  }
  console.log('getRoutesByRole', result)
  return result
}
export default getRoutesByRole
