import router from '@/router'
import getPageTitle from '@/utils/get-page-title'
import store from '@/store'
import { getQueryParams, getDefaultRole } from '@/framework/utils/common'
import { report } from '@/framework/service/track-service'
import NProgress from 'nprogress' // progress bar
import 'nprogress/nprogress.css' // progress bar style

//获取当前角色
const defaultPowerType = getQueryParams('powerType')
const defaultPowerCode = getQueryParams('powerCode')

const whiteList = ['error500', 'error403'] // 无需认证白名单
router.beforeEach(async(to, from, next) => {
  console.log('this.$route', to)
  NProgress.start()
  let curToken = store.getters.token
  if (whiteList.indexOf(to.name) !== -1) {
    return next() // 在白名单，免登录
  } else if (!curToken) {
    curToken = await store.dispatch('user/login')
  }

  if (!curToken) {
    return next({
      path: '/error/500', query: {
        errmsg: '用户认证失败'
      }, replace: true
    })
  }

  //获取权限列表
  let roleList = store.getters.roleList
  if (!roleList || roleList.length === 0) {
    roleList = await store.dispatch('user/getRoleList')
  }
  if (!roleList) {
    return next({
      path: '/error/500', query: {
        errmsg: '用户权限列表获取失败'
      }, replace: true
    })
  } else if (roleList.length === 0) {
    return next({ path: '/error/403', replace: true })
  }

  let currentRole = store.getters.currentRole || getDefaultRole(roleList, defaultPowerType, defaultPowerCode)
  if (!currentRole && roleList.length === 1) {
    //只有一个角色 默认选中角色
    currentRole = roleList[0]
  }
  // 不存在默认角色，进入身份选择页面，存在则执行访问目标页面
  if (!currentRole) {
    if (to.path !== '/switch-identity') {
      return next({ path: '/switch-identity', replace: true })
    } else {
      return next()
    }
  }

  //页面刷新
  if (to.matched.length === 0) {
    if (store.getters.routes && store.getters.routes.length > 0) {
      return next({ path: '/error/404', replace: true })
    }
    //确权
    if (await store.dispatch('user/setCurrentRole', currentRole)) {
      return next({ ...to, replace: true })
    } else {
      return next({
        path: '/error/500', query: {
          errmsg: '切换权限失败'
        }, replace: true
      })
    }
  }
  return next()
})

router.afterEach((to) => {
  // finish progress bar
  NProgress.done()
  // 设置页头
  document.title = getPageTitle(to.meta ? to.meta.title : '')
  // 行为打点
  report({ actionName: 'see', dataSource: 'framework', taskType: 'route-change', expand: to.meta })
})

