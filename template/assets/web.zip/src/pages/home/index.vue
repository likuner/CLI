<template>
  <div class="home">
    <lx-breadcrumb style="margin-bottom: 40px"></lx-breadcrumb>
    <div class="page-container">
      home
    </div>
  </div>
</template>

<script>
export default {
  name: 'home',
  data: function() {
    return {}
  },
  /* 计算属性 */
  computed: {},
  /* 生命周期钩子 */
  created() {},
  mounted() {},
  destroyed() {},
  /* 方法 */
  methods: {}
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
</style>
