<template>
  <div class="lisence-dialog">
    <el-dialog
      title="提示"
      width="554px"
      top="30vh"
      custom-class="custom-lisence-dialog"
      :append-to-body="true"
      :destroy-on-close="true"
      :show-close="false"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      :visible="dialogVisible"
      :class="{'hidden-dialog-footer':!isWillOutDate && !isLisenceAdmin}"
    >
      <div class="info-box">
        <img :src="require('@/framework/assets/images/warn@2x.png')" class="info-img">
        <div class="info-words info-out-date" v-if="isWillOutDate">当前应用的许可文件将于<span class="date-time">{{outDate}}</span>到期，到期后应用将无法继续使用，请及时续约。续约请联系蓝信管理员申请新的许可文件。</div>
        <div class="info-words" v-else>很抱歉，当前应用缺少许可文件，暂时无法使用，请联系蓝信管理员获取许可文件。</div>
      </div>
      <div
        class="tip-box"
        :class="{'tip-error':uploadFlag===2}"
      >{{tipWords}}</div>
      <span slot="footer" class="dialog-footer">
        <el-button class="cancel-btn" @click="handleCancel" v-if="isWillOutDate">我知道了</el-button>
        <el-button class="import-btn" type="primary" @click="handleImport" :disabled="uploadFlag===1" v-if="isLisenceAdmin">导入许可文件</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { formatDate } from '@/framework/utils/common'
import { openFileChoose } from '@/framework/utils/file'
import { uploadLisence } from '@/framework/service/lisence-service'

export default {
  name: 'lisence-dialog',
  props: {
    options: {
      type: Object,
      default: function() {
        return {}
      }
    }
  },

  data() {
    return {
      dialogVisible: true,
      uploadFlag: 0 // 0 没有上传 1 正在上传 2 上传出错
    }
  },

  components: {},

  /* 计算属性 */
  computed: {
    lisence() {
      return this.options.lisence
    },
    isLisenceAdmin() {
      return this.options.isLisenceAdmin
    },
    isWillOutDate() {
      return this.lisence && this.lisence.status === 1
    },
    outDate() {
      if (!this.lisence || !this.lisence.licenseEndTime) {
        return null
      }
      return formatDate(this.lisence.licenseEndTime, 'YYYY年MM月DD日')
    },
    tipWords() {
      let tips = ''
      if (this.uploadFlag === 1) {
        tips = '正在上传...'
      } else if (this.uploadFlag === 2) {
        tips = '许可文件导入失败/许可文件无效'
      }
      return tips
    }
  },

  /* 生命周期钩子 */
  created() {},
  mounted() {},

  /* 方法 */
  methods: {
    handleCancel() {
      this.dialogVisible = false
      this.options.cancelCbk()
    },
    async handleImport() {
      const file = await openFileChoose()
      console.log(file)
      if (!file) return
      this.uploadFlag = 1
      const formData = new FormData()
      formData.append('file', file)
      const res = await uploadLisence(formData)
      console.log('--lisence-upload-result--:', res)
      if (res && res.errcode === 200) {
        this.uploadFlag = 0
        this.dialogVisible = false
        this.options.confirmCbk(res.data)
      } else {
        this.uploadFlag = 2
      }
    },
    async uploadLisence() {}
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
/deep/{
  .custom-lisence-dialog{
    .el-dialog__header{
      padding-left: 75px;
      background: #FFFFFF;
      .el-dialog__title{
        font-size: 18px;
        color: #303133;
      }
    }
    .el-dialog__body{
      .info-box{
        display: flex;
        align-items: flex-start;
        .info-img{
          flex: 0 0 32px;
          height: 32px;
          margin: 0 17px 0 6px;
        }
        .info-words{
          font-size: 14px;
          line-height: 24px;
          color: #606266;
          margin: 0 30px 0 0;
        }
        .info-out-date{
          .date-time{
            color: #248EFA;
          }
        }
      }
      .tip-box{
        height: 20px;
        font-size: 14px;
        // color: #606266;
        color: #248EFA;
        line-height: 24px;
        margin: 10px 30px 0 55px;
      }
      .tip-error{
        color: #F56C6C;
      }
    }
    .el-dialog__footer{
      border-top: none;
      padding: 20px 30px 14px;
    }
  }
}
.hidden-dialog-footer /deep/{
  .el-dialog__footer{
    display: none;
  }
}
</style>
