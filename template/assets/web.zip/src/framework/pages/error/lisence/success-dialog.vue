<template>
  <div class="success-dialog">
    <el-dialog
      width="554px"
      top="30vh"
      custom-class="custom-success-dialog"
      :append-to-body="true"
      :destroy-on-close="true"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      :visible.sync="dialogVisible"
      @closed="closeDialog"
    >
      <div class="info-box">
        <img :src="require('@/framework/assets/images/success@2x.png')" class="success-img">
        <div class="info-words">
          <div class="tip-words">许可文件导入成功</div>
          <div class="valid-words">许可文件有效期：<span class="valid-date">{{outDate}}</span></div>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { formatDate } from '@/framework/utils/common'

export default {
  name: 'success-dialog',
  props: {
    options: {
      type: Object,
      default: function() {
        return {}
      }
    }
  },

  data() {
    return {
      dialogVisible: true
    }
  },

  components: {},

  /* 计算属性 */
  computed: {
    outDate() {
      if (!this.options || !this.options.licenseEndTime) {
        return null
      }
      return formatDate(this.options.licenseEndTime, 'YYYY年MM月DD日')
    }
  },

  /* 生命周期钩子 */
  created() {},
  mounted() {},

  /* 方法 */
  methods: {
    closeDialog() {
      this.options.closeCbk()
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
/deep/{
  .custom-success-dialog{
    .el-dialog__header{
      background: #FFFFFF;
    }
    .el-dialog__body{
      .info-box{
        display: flex;
        align-items: center;
        padding-bottom: 16px;
        .success-img{
          width: 32px;
          min-width: 32px;
          max-width: 32px;
          height: 32px;
          margin: 0 16px 0 6px;
        }
        .info-words{
          flex: 1 0;
          line-height: 28px;
          .tip-words{
            font-size: 18px;
            font-weight: bold;
            color: #303133;
          }
          .valid-words{
            font-size: 14px;
            color: #606266;
            .valid-date{
              color: #248EFA;
            }
          }
        }
      }
    }
  }
}
</style>
