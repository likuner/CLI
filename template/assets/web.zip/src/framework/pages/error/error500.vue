<template>
  <div class="exception-container">
    <img :src="require('@/framework/assets/images/notfound.png')" class="exception-image" />
    <div class="exception-content">
      <h1>Error</h1>
      <div class="message">抱歉，{{errmsg}}</div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'error500',
  data: function() {
    return {
      errmsg: ''
    }
  },
  created() {
    this.errmsg = this.$route.query.errmsg || '未知错误'
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.exception-container {
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: white;
}
.exception-image {
  width: 430px;
  height: auto;
  margin-right: 50px;
}
h1 {
  color: #434e59;
  font-size: 72px;
  font-weight: 600;
  line-height: 72px;
  margin-bottom: 24px;
}
.message {
  color: rgba(0, 0, 0, 0.45);
  font-size: 20px;
  line-height: 28px;
  margin-bottom: 16px;
}
.back-btn {
  font-size: 18px;
}
</style>
