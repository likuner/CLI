<template>
  <div class="exception-container">
    <img :src="require('@/framework/assets/images/icon_noperssion@2x.png')" class="exception-image" />
    <div class="message">暂无权限，请联系管理员</div>
  </div>
</template>

<script>
export default {}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.exception-container {
  flex-direction: column;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: white;
  color: #999999;
}
.exception-image {
  width: 120px;
  height: auto;
  margin-bottom: 30px;
}
</style>
