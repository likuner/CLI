import Layout from './layout'
export default [
  {
    path: '/framework/settings',
    component: Layout,
    children: [
      {
        path: 'index',
        name: 'framework-index',
        component: () => import('@/framework/pages/settings/index')
      },
      {
        path: 'params',
        name: 'framework-params',
        component: () => import('@/framework/pages/settings/parameter-list')
      }
    ]
  }
]
