<template>
  <div style="padding: 0 60px">
    <el-page-header @back="$router.back()" content="应用设置" style="height: 60px; line-height: 60px"></el-page-header>
    <div class="container">
      <router-view></router-view>
    </div>
  </div>
</template>
<script>
</script>
<style lang="scss" scoped>
.container {
  padding: 30px;
  background-color: white;
  height: 100%;
  box-sizing: border-box;
  overflow: auto;
}
</style>
