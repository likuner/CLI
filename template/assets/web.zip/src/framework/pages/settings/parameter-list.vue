<template>
  <div class="timed-task">
    <div class="search">
      <el-input
        placeholder="输入参数名称"
        v-model.trim="form.name"
        style="margin-right: 10px"
        @keyup.enter.native="searchFn"
        class="search-title"
      ></el-input>
      <el-button @click="searchFn">查询</el-button>
      <el-button @click="reSet">重置</el-button>
      <el-button type="primary" class="add-btn" @click="addParam">新增</el-button>
    </div>
    <data-provider
      :provider="provider"
      :condition="condition"
      v-slot="tableData"
      ref="dataProvider"
    >
      <el-table :data="tableData.data" v-loading="tableData.loading" style="width: 100%">
        <el-table-column prop="id" label="序号" width="60">
          <template slot-scope="scope">
            {{
            ($refs.dataProvider.pageNo-1)*$refs.dataProvider.pageSize+ scope.$index+1
            }}
          </template>
        </el-table-column>
        <el-table-column prop="name" label="参数名称" show-overflow-tooltip></el-table-column>
        <el-table-column prop="paramKey" label="参数编码" show-overflow-tooltip></el-table-column>

        <el-table-column prop="paramValue" label="参数内容" show-overflow-tooltip></el-table-column>

        <el-table-column prop="remark" label="参数说明" show-overflow-tooltip></el-table-column>

        <el-table-column prop="comefrom" label="参数来源" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.comefrom===2?'页面添加':'系统添加'}}</template>
        </el-table-column>
        <el-table-column prop="createUserName" label="创建人" show-overflow-tooltip></el-table-column>
        <el-table-column label="创建时间" show-overflow-tooltip class-name="exam-time">
          <template slot-scope="scope">
            <p
              v-if="scope.row.createTime !== null"
            >{{ scope.row.createTime | date('YYYY-MM-DD HH:mm') }}</p>
          </template>
        </el-table-column>

        <el-table-column fixed="right" label="操作" width="140">
          <template slot-scope="scope">
            <el-dropdown trigger="click">
              <span class="el-dropdown-link">
                <i class="el-icon-more iconClass"></i>
              </span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item icon="el-icon-edit" @click.native="updateParams(scope.row)">修改</el-dropdown-item>
                <el-dropdown-item
                  icon="el-icon-delete"
                  @click.native="deleteParams(scope.row.code)"
                >删除</el-dropdown-item>
                <!-- <el-dropdown-item icon="el-icon-circle-check">立即执行</el-dropdown-item> -->
              </el-dropdown-menu>
            </el-dropdown>
          </template>
        </el-table-column>
      </el-table>
    </data-provider>
    <el-dialog
      :title="this.title"
      :visible.sync="dialogFormVisible"
      :before-close="initDialog"
      width="600px"
    >
      <div class="formCss">
        <el-form :model="form" :rules="rules" ref="form" label-position="right">
          <el-form-item label="参数名称" label-width="120px" prop="name">
            <el-input
              type="text"
              placeholder="请输入参数名称"
              v-model="form.name"
              maxlength="30"
              show-word-limit
            ></el-input>
          </el-form-item>

          <el-form-item label="参数编码" label-width="120px" prop="paramKey">
            <el-input
              type="text"
              placeholder="请输入参数编码"
              v-model="form.paramKey"
              maxlength="30"
              show-word-limit
              :disabled="limitUpdate"
            ></el-input>
          </el-form-item>
          <el-form-item label="参数内容" label-width="120px" prop="paramValue">
            <el-input
              type="text"
              placeholder="请输入参数VALUE"
              v-model="form.paramValue"
              maxlength="30"
              show-word-limit
            ></el-input>
          </el-form-item>

          <el-form-item label="参数说明" label-width="120px" prop="remark">
            <el-input
              type="text"
              placeholder="请输入参数说明"
              v-model="form.remark"
              maxlength="200"
              show-word-limit
            ></el-input>
          </el-form-item>
        </el-form>
      </div>

      <div slot="footer" class="dialog-footer">
        <el-button @click="initDialog()">取 消</el-button>
        <el-button type="primary" @click="submitForm('form')">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import DataProvider from '@/framework/components/data-provider'
import {
  getParamsList,
  addParams,
  updateParams,
  deleteParams
} from '@/framework/service/params-service'
export default {
  name: 'paging-org-list',
  data() {
    return {
      provider: getParamsList,
      condition: {
        organizationCode: this.$route.query.code
      },
      condition1: {
        organizationCode: this.$route.query.code
      },
      dialogFormVisible: false,
      title: '新增',
      limitUpdate: false,
      form: {
        name: '',
        paramKey: null,
        paramValue: null,
        remark: null
      },
      rules: {
        name: [{ required: true, message: '必填项', trigger: 'blur' }],
        paramKey: [{ required: true, message: '必填项', trigger: 'blur' }],
        paramValue: [{ required: true, message: '必填项', trigger: 'blur' }]
      }
    }
  },
  components: {
    [DataProvider.name]: DataProvider
  },
  mounted() {
    //this.condition.organizationCode = this.$route.query.code
    this.condition.searchkey = this.form.name
    this.$refs.dataProvider.reloadData()
  },
  methods: {
    searchFn() {
      this.provider = getParamsList
      this.condition.searchkey = this.form.name
      this.$refs.dataProvider.reloadData()
    },
    addParam() {
      this.dialogFormVisible = true
      this.title = '新增'
      delete this.condition1.code
    },
    reSet() {
      this.form.name = ''
      this.searchFn()
    },
    updateParams(item) {
      if (item.comefrom === 1) {
        this.limitUpdate = true
      }
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.form.name = item.name
        this.form.paramKey = item.paramKey
        this.form.paramValue = item.paramValue
        this.form.remark = item.remark
        this.condition1.code = item.code
        this.title = '修改'
      })
    },
    async deleteParams(code) {
      const result = await this.$confirm(
        '此操作将永久删除该数据, 是否继续?',
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }
      )
      console.log(result)
      if (result === 'confirm') {
        const res = await deleteParams({ code: code })
        if (res.errcode === 200) {
          this.$refs.dataProvider.reloadData()
        }
      }
    },
    initDialog() {
      this.dialogFormVisible = false
      this.title = '新增'
      this.$refs.form.resetFields()

      this.form.name = ''
    },
    submitForm(formName) {
      this.$refs[formName].validate(async valid => {
        if (valid) {
          this.dialogFormVisible = false
          this.condition1.name = this.form.name
          this.condition1.paramKey = this.form.paramKey
          this.condition1.paramValue = this.form.paramValue
          this.condition1.remark = this.form.remark
          this.limitUpdate = false
          let res = null
          if (this.title === '新增') {
            res = await addParams(this.condition1)
          } else {
            res = await updateParams(this.condition1)
          }
          console.log('res')
          console.log(res)
          console.log('res')
          if (res.errcode === 200) {
            this.initDialog()
            this.searchFn()
          } else {
            this.initDialog()
            this.$message.error(res.errmsg)
          }
        } else {
          this.$message.error('验证失败')
          return false
        }
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.search {
  .search-title {
    width: 200px;
  }
  display: flex;
  margin-bottom: 20px;
  .add-btn {
    position: absolute;
    right: 120px;
  }
}
.formCss {
  padding: 10px 50px 0 20px;
}
.dialog-footer {
  margin-left: 220px;
  text-align: left;
}
.operation {
  display: flex;
  justify-content: flex-start;
  flex-wrap: wrap;
}
.iconClass {
  cursor: pointer;
  color: #0486fe;
  font-size: 22px;
}
</style>
