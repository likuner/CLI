<template>
  <el-tabs v-model="activeName" class="container">
    <el-tab-pane label="组织管理" name="1" :lazy="true">
      <PagingOrgList></PagingOrgList>
    </el-tab-pane>
    <el-tab-pane label="定时任务" name="3" :lazy="true">
      <TimedTask></TimedTask>
    </el-tab-pane>
  </el-tabs>
</template>
<script>
import PagingOrgList from './paging-org-list'
import TimedTask from './timed-task'
export default {
  data() {
    return {
      activeName: '1'
    }
  },
  components: {
    PagingOrgList,
    TimedTask
  }
}
</script>
<style lang="scss" scoped>
.container {
  padding: 30px;
  background-color: white;
  height: 100%;
  box-sizing: border-box;
  overflow: auto;
}
</style>
