<template>
  <div class="timed-task">
    <div class="search">
      <el-input
        placeholder="任务名称"
        v-model.trim="form.name"
        style="margin-right: 10px"
        @keyup.enter.native="searchFn"
        class="search-title"
      ></el-input>
      <el-button @click="searchFn">查询</el-button>
      <el-button @click="reSet">重置</el-button>
      <el-button type="primary" class="add-btn" @click="addTask">新增</el-button>
    </div>
    <data-provider
      :provider="provider"
      :condition="condition"
      v-slot="tableData"
      ref="dataProvider"
    >
      <el-table :data="tableData.data" v-loading="tableData.loading" style="width: 100%">
        <el-table-column prop="id" label="序号" width="60">
          <template slot-scope="scope">
            {{
            ($refs.dataProvider.pageNo-1)*$refs.dataProvider.pageSize+ scope.$index+1
            }}
          </template>
        </el-table-column>
        <el-table-column prop="name" label="任务名称" show-overflow-tooltip></el-table-column>

        <el-table-column prop="jobGroup" label="任务组" show-overflow-tooltip></el-table-column>
        <el-table-column prop="beanName" label="任务bean名称" show-overflow-tooltip></el-table-column>
        <el-table-column prop="cron" label="cron表达式" show-overflow-tooltip></el-table-column>

        <el-table-column prop="parameter" label="任务参数" show-overflow-tooltip></el-table-column>
        <el-table-column prop="tag" label="状态" width="100">
          <template slot-scope="scope">
            <el-tag
              :type="scope.row.tag === 'CLOSE' ? 'primary' : 'success'"
              disable-transitions
            >{{ scope.row.status==='OPEN'?'启用':'关闭' }}</el-tag>
          </template>
        </el-table-column>

        <el-table-column label="创建时间" show-overflow-tooltip class-name="exam-time">
          <template slot-scope="scope">
            <p v-if="scope.row.createTime !== null">
              {{
              scope.row.createTime | date('YYYY-MM-DD HH:mm')
              }}
            </p>
          </template>
        </el-table-column>

        <el-table-column fixed="right" label="操作" width="140">
          <template slot-scope="scope">
            <el-dropdown trigger="click">
              <span class="el-dropdown-link">
                <i class="el-icon-more iconClass"></i>
              </span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item icon="el-icon-edit" @click.native="updateTask(scope.row)">修改</el-dropdown-item>
                <el-dropdown-item icon="el-icon-delete" @click.native="deleteTask(scope.row.id)">删除</el-dropdown-item>
                <el-dropdown-item icon="el-icon-video-play" @click.native="pause(scope.row.id)">暂停</el-dropdown-item>
                <el-dropdown-item
                  icon="el-icon-video-pause"
                  @click.native="recover(scope.row.id)"
                >恢复</el-dropdown-item>
                <!-- <el-dropdown-item icon="el-icon-circle-check">立即执行</el-dropdown-item> -->
              </el-dropdown-menu>
            </el-dropdown>
          </template>
        </el-table-column>
      </el-table>
    </data-provider>
    <el-dialog
      :title="this.title"
      :visible.sync="dialogFormVisible"
      :before-close="initDialog"
      width="600px"
    >
      <div class="formCss">
        <el-form :model="form" :rules="rules" ref="form" label-position="right">
          <el-form-item label="bean名称" label-width="120px" prop="beanName">
            <el-input
              type="text"
              placeholder="请输入bean名称"
              v-model="form.beanName"
              maxlength="50"
              show-word-limit
            ></el-input>
          </el-form-item>
          <el-form-item label="任务名称" label-width="120px" prop="name">
            <el-input
              type="text"
              placeholder="请输入方法名称"
              v-model="form.name"
              maxlength="50"
              show-word-limit
            ></el-input>
          </el-form-item>

          <el-form-item label="任务组" label-width="120px" prop="jobGroup">
            <el-input
              type="text"
              placeholder="请输入任务组"
              v-model="form.jobGroup"
              maxlength="50"
              show-word-limit
            ></el-input>
          </el-form-item>

          <el-form-item label="cron表达式" label-width="120px" prop="cron">
            <el-input
              type="text"
              placeholder="请输入cron表达式"
              v-model="form.cron"
              maxlength="50"
              show-word-limit
            ></el-input>
          </el-form-item>

          <el-form-item label="任务参数" label-width="120px" prop="parameter">
            <el-input
              type="text"
              placeholder="请输入任务参数"
              v-model="form.parameter"
              maxlength="1000"
              show-word-limit
            ></el-input>
          </el-form-item>

          <el-form-item label="任务描述" label-width="120px" prop="description">
            <el-input
              type="text"
              placeholder="请输入任务描述"
              v-model="form.description"
              maxlength="50"
              show-word-limit
            ></el-input>
          </el-form-item>
        </el-form>
      </div>

      <div slot="footer" class="dialog-footer">
        <el-button @click="initDialog()">取 消</el-button>
        <el-button type="primary" @click="submitForm('form')">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import DataProvider from '@/framework/components/data-provider'
import {
  jobTaskList,
  addJobTask,
  updateJobTask,
  deleteJobTask,
  pauseJobTask,
  resumeJobTask
} from '@/framework/service/task-service'
export default {
  data() {
    return {
      provider: jobTaskList,
      condition: {},
      condition1: {},
      dialogFormVisible: false,
      title: '新增',
      beanName: '',
      form: {
        beanName: null,
        name: null,
        jobGroup: null,
        parameter: null,
        cron: null,
        description: null
      },
      rules: {
        beanName: [{ required: true, message: '必填项', trigger: 'blur' }],
        name: [{ required: true, message: '必填项', trigger: 'blur' }],
        cron: [{ required: true, message: '必填项', trigger: 'blur' }],
        jobGroup: [{ required: true, message: '必填项', trigger: 'blur' }]
      }
    }
  },
  components: {
    [DataProvider.name]: DataProvider
  },
  mounted() {
    this.$refs.dataProvider.reloadData()
  },
  methods: {
    searchFn() {
      this.condition.name = this.form.name
      this.$refs.dataProvider.reloadData()
    },
    addTask() {
      this.dialogFormVisible = true
      this.title = '新增'
    },
    updateTask(item) {
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.form.beanName = item.beanName
        this.form.name = item.name
        this.form.parameter = item.parameter
        this.form.cron = item.cron
        this.form.description = item.description
        this.form.jobGroup = item.jobGroup
        this.condition1.id = item.id
        this.title = '修改'
      })
    },
    reSet() {
      this.form.name = ''
      this.searchFn()
    },
    async deleteTask(id) {
      const result = await this.$confirm(
        '此操作将永久删除该文件, 是否继续?',
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }
      )
      console.log(result)
      if (result === 'confirm') {
        const res = await deleteJobTask({ id: id })
        if (res.errcode === 200) {
          this.$refs.dataProvider.reloadData()
        }
      }
    },
    async pause(id) {
      const res = await pauseJobTask({ id: id })
      if (res.errcode === 200) {
        this.$refs.dataProvider.reloadData()
      }
    },
    async recover(id) {
      const res = await resumeJobTask({ id: id })
      if (res.errcode === 200) {
        this.$refs.dataProvider.reloadData()
      }
    },
    execute() {},
    initDialog() {
      this.dialogFormVisible = false
      this.title = '新增'
      this.$refs.form.resetFields()
      this.form.name = ''
    },
    submitForm(formName) {
      this.$refs[formName].validate(async valid => {
        if (valid) {
          this.dialogFormVisible = false
          this.condition1.beanName = this.form.beanName
          this.condition1.name = this.form.name
          this.condition1.parameter = this.form.parameter
          this.condition1.cron = this.form.cron
          this.condition1.description = this.form.description
          this.condition1.jobGroup = this.form.jobGroup
          this.condition1.status = 'OPEN'
          let res = null
          if (this.title === '新增') {
            res = await addJobTask(this.condition1)
          } else {
            res = await updateJobTask(this.condition1)
          }
          if (res.errcode === 200) {
            this.initDialog()
            this.$refs.dataProvider.reloadData()
          } else {
            this.initDialog()
            this.$message.error('操作失败')
          }
        } else {
          console.log('error submit!!')
          return false
        }
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.page-container {
  padding: 40px;
  background-color: white;
}
.search {
  .search-title {
    width: 200px;
  }
  display: flex;
  margin-bottom: 20px;
  .add-btn {
    position: absolute;
    right: 120px;
  }
}
.formCss {
  padding: 10px 50px 0 20px;
}
.dialog-footer {
  margin-left: 220px;
  text-align: left;
}
.operation {
  display: flex;
  justify-content: flex-start;
  flex-wrap: wrap;
}
.iconClass {
  cursor: pointer;
  color: #0486fe;
  font-size: 22px;
}
</style>
