<template>
  <div class="role-list">
    <el-row>
      <el-button class="add-role" type="primary" @click="showDialog()">添加</el-button>
    </el-row>
    <data-provider
      :provider="provider"
      :condition="condition"
      v-slot="tableData"
      ref="dataProvider"
    >
      <el-table :data="tableData.data" v-loading="tableData.loading" style="width: 100%">
        <el-table-column prop="cmcName" label="角色名称" width="180"></el-table-column>
        <el-table-column prop="managersName" label="人员" ></el-table-column>
        <el-table-column prop="scopeName" label="管理范围" ></el-table-column>
        <el-table-column label="操作" width="110">
          <template slot-scope="scope">
            <el-link type="primary" @click="showDialog(scope.row, 'edit')">编辑</el-link>
            <el-link type="danger" @click="deleteRole(scope.row)">删除</el-link>
          </template>
        </el-table-column>
      </el-table>
    </data-provider>
  </div>
</template>

<script>
import DataProvider from '@/framework/components/data-provider'
import { getCmcList, deleteCmc } from '@/framework/service/cmc-service'
import { showDialog as showAddRoleDialog } from './add-role/add-role'

export default {
  name: 'role-list',
  data: function() {
    return {
      provider: getCmcList,
      condition: {},
      list: [],
      defaultForm: {
        cmcName: '',
        Managers: [],
        ManageScopes: []
      }
    }
  },
  components: {
    [DataProvider.name]: DataProvider
  },
  mounted() {
    this.$refs.dataProvider.reloadData()
  },
  methods: {
    deleteRole(data) {
      console.log(data)
      this.$confirm('删除操作不可恢复，是否确定删除？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消'
      })
        .then(() => {
          // TODO 调用后台接口 删除cmc
          const loading = this.$loading()
          deleteCmc({ id: data.id })
            .then(res => {
              loading.close()
              if (res.errcode === 200) {
                this.$refs.dataProvider.reloadData()
              }
            })
            .catch(error => {
              console.error(error)
              loading.close()
            })
        })
        .catch(() => {})
    },
    async showDialog(data, type = 'add') {
      const result = await showAddRoleDialog({
        type: type,
        context: data
      })
      console.log(result)
      if (result.action === 'confirm') {
        this.$refs.dataProvider.reloadData()
      }
    }
  }
}
</script>

<style scoped lang="scss">
.role-list {
  padding: 50px;
  .add-role {
    width: 88px;
    height: 30px;
    line-height: 30px;
    padding: 0;
    margin-bottom: 30px;
  }
}
/deep/ {
  .el-link {
    &:first-child {
      margin-right: 12px;
    }
    &:hover {
      text-decoration: none;
      &::after {
        display: none;
      }
    }
  }
  .el-table th {
    background-color: #f7f8fa;
  }
}
</style>
