<template>
  <el-dialog :title="title" :visible="dialogVisible" :before-close="closeDialog" append-to-body>
    <el-form :model="form" :rules="rules" ref="ruleForm">
      <el-form-item label="角色名称" prop="cmcName">
        <el-input v-model="form.cmcName" placeholder="请输入角色名称"></el-input>
      </el-form-item>
      <el-form-item label="角色人员" prop="managers">
        <org-staff-input
          :options="{'selectMode':'Person'}"
          v-model="form.managers"
          placeholder="请选择人员"
        ></org-staff-input>
      </el-form-item>
      <el-form-item label="管理范围" prop="manageScopes">
        <org-staff-input
          :options="{'selectMode':'PersonAndStruct'}"
          v-model="form.manageScopes"
          placeholder="请选择管理范围"
        ></org-staff-input>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="closeDialog" class="ctrl-btn">取 消</el-button>
      <el-button
        type="primary"
        @click="submitForm('ruleForm')"
        class="ctrl-btn"
        :loading="saveLoading"
      >确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
import OrgStaffInput from '@/framework/components/org-staff-selector/org-staff-input'
import { addCmc, updateCmc } from '@/framework/service/cmc-service'
import { deepGet } from '@/framework/utils/common'
export default {
  name: 'add-role',
  data: function() {
    return {
      dialogVisible: true,
      saveLoading: false,
      form: {
        id: '',
        cmcName: '',
        managers: null,
        manageScopes: null
      },
      rules: {
        cmcName: [
          { required: true, message: '请输入角色名称', trigger: 'input' }
        ],
        managers: [
          { required: true, message: '请选择人员', trigger: 'change' }
        ],
        manageScopes: [
          { required: true, message: '请选择管理范围', trigger: 'change' }
        ]
      }
    }
  },
  props: {
    options: {
      type: Object,
      default: function() {
        return {}
      }
    }
  },
  created() {
    const { cmcName, managers, manageScopes, id } = deepGet(this.options, 'context', {})
    if (this.options.type === 'edit') {
      this.form.id = id
    }
    this.form.cmcName = cmcName
    if (managers) {
      this.form.managers = {
        selectedMembers: managers.map(ele => {
          return { staffId: ele.objId, name: ele.objName }
        })
      }
    }
    if (manageScopes) {
      const selectedMembers = []
      const selectedStructs = []
      manageScopes.forEach(ele => {
        if (ele.type === 1) {
          selectedMembers.push({ staffId: ele.objId, name: ele.objName })
        } else if (ele.type === 2) {
          selectedStructs.push({ id: ele.objId, name: ele.objName })
        }
      })
      this.form.manageScopes = { selectedMembers, selectedStructs }
    }
    console.log(this.form)
  },
  computed: {
    title: function() {
      return this.options.type === 'edit' ? '编辑角色' : '新增角色'
    }
  },
  components: {
    [OrgStaffInput.name]: OrgStaffInput
  },
  methods: {
    /**
     * 添加\编辑角色
     */
    async updateCmc(data) {
      let currentFun
      const params = { cmcName: this.form.cmcName }
      if (this.options.type === 'edit') {
        currentFun = updateCmc
        params.id = this.form.id
      } else {
        currentFun = addCmc
      }

      params.managers = this.form.managers.selectedMembers.map(ele => {
        return {
          objId: ele.staffId,
          objName: ele.name,
          type: 1
        }
      })
      params.manageScopes = [
        ...this.form.manageScopes.selectedStructs.map(ele => {
          return {
            objId: ele.id,
            objName: ele.name,
            type: 2
          }
        }),
        ...this.form.manageScopes.selectedMembers.map(ele => {
          return {
            objId: ele.staffId,
            objName: ele.name,
            type: 1
          }
        })
      ]
      this.saveLoading = true
      const result = await currentFun(params)
      this.saveLoading = false
      if (result.errcode !== 200) {
        this.$message({
          type: 'error',
          message: result.errmsg
        })
      } else {
        this.dialogVisible = false
        this.options.confrimCb(this.form)
      }
    },
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.updateCmc()
        } else {
          return false
        }
      })
    },
    closeDialog() {
      this.dialogVisible = false
      this.options.cancelCb()
    }
  }
}
</script>

<style scoped lang="scss">
/deep/ {
  .el-dialog {
    width: 600px;
  }
  .dialog-footer {
    text-align: center;
    .el-button {
      width: 100px;
      height: 34px;
      line-height: 34px;
      padding: 0;
    }
  }
}
</style>
