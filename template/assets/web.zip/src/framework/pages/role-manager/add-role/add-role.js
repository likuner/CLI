import Vue from 'vue'
import AddRole from './index.vue'

export function showDialog(options = {}) {
  console.log(options)
  return new Promise(function(resolve) {
    options = Object.assign({}, options, {
      confrimCb: (data) => {
        resolve({ action: 'confirm', data })
      },
      cancelCb: () => {
        resolve({ action: 'cancel' })
      }
    })
    const AddRoleDilaog = Vue.extend(AddRole)
    new AddRoleDilaog({ propsData: { options }}).$mount()
  })
}
