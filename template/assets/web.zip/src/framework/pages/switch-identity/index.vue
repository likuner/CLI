<template>
  <div class="switch-identity">
    <div class="title">角色切换</div>
    <template v-if="roleGroupList && roleGroupList.length > 0">
      <div class="lx-page-body">
        <div class="switch-identity-list">
          <el-row v-for="(group,index) in roleGroupList" :key="index">
            <template v-if="group.groupName">
              <div class="divider"></div>
              <div class="group-name">{{group.groupName}}</div>
            </template>
            <el-row>
              <el-col
                class="item"
                :xs="8"
                :sm="8"
                :md="8"
                :lg="6"
                :xl="4"
                v-for="role in group.roleList"
                :key="role.powerId"
              >
                <div class="switch-identity-item" @click="roleClick(role)">
                  <span class="switch-identity-item__name">{{role.powerName}}</span>
                  <span class="switch-identity-item__type">{{role.powerTypeName}}</span>
                </div>
              </el-col>
            </el-row>
          </el-row>
        </div>
      </div>
    </template>
    <template v-else>
      <!-- TODO 无权限 -->
      <div>无权限</div>
    </template>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import { Loading } from 'element-ui'
export default {
  name: 'switch-identity',
  data: function() {
    return {}
  },
  computed: {
    ...mapGetters(['roleGroupList'])
  },
  methods: {
    ...mapActions('user', ['setCurrentRole']),
    async roleClick(role) {
      //切换角色 重定向到首页
      const loadingInstance = Loading.service({
        fullscreen: true,
        text: '身份切换中...'
      })
      if (await this.setCurrentRole(role)) {
        this.$router.replace('/')
        loadingInstance.close()
      } else {
        loadingInstance.close()
        this.$notify.error('角色切换异常，请重试')
      }
    }
  }
}
</script>

<style scoped lang="scss">
.switch-identity {
  background-color: #fff;
  padding: 40px 50px;
  margin-bottom: 40px;
  display: flex;
  flex-direction: column;
  box-sizing: border-box;
  .title {
    margin-left: -10px;
    font-family: PingFangSC-Medium;
    font-size: 20px;
    color: #303133;
  }
  .lx-page-header {
    display: flex;
    height: 80px;
    min-height: 80px;
    align-items: center;
    font-family: PingFangSC-Semibold;
    font-size: 20px;
    color: #666666;
    line-height: 20px;
    box-shadow: inset 0 -1px 0 0 rgba(0, 0, 0, 0.1);
    img {
      width: 32px;
      margin-right: 10px;
    }
  }
  .lx-page-body {
    padding-top: 15px;
    .group-name {
      font-size: 20px;
      color: #909399;
    }
    .switch-identity-item {
      position: relative;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      height: 80px;
      padding: 0 20px;
      border: 1px solid #dcdfe6;
      border-radius: 4px;
      margin: 15px 10px;
      cursor: pointer;
      .switch-identity-item__name {
        font-size: 16px;
        color: #303133;
      }
      .switch-identity-item__type {
        color: #909399;
      }
      i {
        font-size: 46px;
        margin-right: 20px;
        color: #96b4ff;
      }
      span {
        color: #666666;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        width: 100%;
        text-align: left;
      }
      &:hover {
        background: #73a0ff;
        box-shadow: 0 0 10px 0 #96b4ff;
        i,
        span {
          color: #fff;
        }
      }
    }
    .el-row {
      margin-left: -10px;
      margin-right: -10px;
    }
    .divider {
      margin: 25px 0;
      display: block;
      height: 5px;
      transform: scale(1, 0.2);
      width: 100%;
      background-color: #ebeef5;
    }
  }
}
</style>
