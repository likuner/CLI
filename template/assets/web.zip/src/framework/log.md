# 更新记录

#### 【2.0.3-alpha.3】2021年9月9日

修改文件列表

framework

public/index.html

package.json

vue.config.js

修改内容

1. 优化打包信息输出
2. 将选人控件、范围选人控件的搜索字数限制为20
3. 附件上传底层方法优化，添加全局文件上传队列，减少超时传输失败问题
4. 优化附件上传黑名单，修复附件logo显示bug
5. web端取消前端超时机制，完全依赖后端
6. 新增前端获取图片缩略图方法
7. 应用隐藏页面开发，包含定时任务，自定义参数等
8. 用户头像获取身份校验
9. 图片上传组件性能优化
11. 视频上传、图片上传、图片裁剪添加text属性

#### 【2.0.1-alpha.6】

修改文件列表

framework

store/index

修改内容

1. 图片裁剪组件优化，关闭时销毁组件
2. 图片上传组件支持fit配置
3. 文件上传BUG修复
4. 获取用户信息接口优化
5. shortNum提取到公共方法并导出
6. 修复第二次进入应用验签失败BUG
7. 优化vuex初始化配置信息
8. 修复范围选人BUG
9. 优化lxconfig流程，暴露全局变量lxconfig完成promise（$JssdkReady）

#### 【2.0.1-alpha.5】

修改文件列表

framework

修改内容

1. 添加环境变量导出，例如isIOS、isAndroid、inLanxin等
2. 优化http请求的trace-id参数，添加web端标识
3. 优化时间格式化方法

#### 【2.0.1-alpha.4】2021年3月12日

修改文件列表：

framework

修改内容：

1. 文件服务升级。大文件上传优化，减轻服务端压力
2. 经纬度选择支持zoom参数，定义地图放大比例
3. openFileChoose限制多选bug修复
4. vuex本地缓存变量优化

#### 【2.0.1-alpha.3】2021年1月29日

修改文件列表：

framework

router-interceptor

修改内容：

1. authcode获取增加超时重试机制
2. 范围选人组件添加搜索功能
3. 文件上传类组件初始化状态BUG修复
4. 用户登录mock数据优化
5. 请求增加唯一标识，配合后端避免nginx重复请求
6. 优化全局路由拦截
7. 用户相关store优化
8. 选人组件选部门BUG修复

#### 【1.7】2021年1月15日

文件列表

framework

public

.env.development

.env.production

.env.staging

router-interceptor.js

修改内容

1. index.html中支持注入web端的版本号
2. 选人、范围选人兼容pc端内置浏览器；
3. 选人、范围选人表单校验bug修复
4. 选人控件，反显部门覆盖bug修复
5. 支持页面主动刷新角色权限列表
6. 分页选人初始化逻辑优化，分多次加载根节点下人员
7. 添加全局配置参数，支持关闭行为数据收集
8. 兼容新老打包方式
9. 默认角色选择优化
10. 内置浏览器打开应用跳转401页面问题修复
11. 修改默认代理地址为新测试环境域名地址

#### 【1.6】2020年12月31日

文件列表

framework

app.vue

main.js

router/role-router.js

package.json

修改内容

1. 选人、范围选人控件优化部门下加载人员逻辑，优化部门下海量人员的全选效率
2. 修复相同路由权限身份切换bug
3. 资源id换取重定向路径，拼接优化
4. 优化只有在蓝信宿主内才进行验证签名
5. 删除lazyload的入口引用
6. 添加超出省略和0.5px border scss函数
7. 修复web端404页面指向错误
8. 更新高德地图key值（1.6.1）
9. 地址选择控件bug修复（1.6.4）

#### 【1.5】2020年12月14日

文件列表
framework

store/index

router/role-router

router-interceptor

修改内容
1. 富文本优化，支持富文本内图片懒加载

2. 修复getuserinfo接口mock数据bug

3. framework内置store引入优化

4. 添加全局设置store，目前支持appName设置

5. 删除无效路由

6. 删除冗余代码及其它代码优化

   


#### 【1.4】2020年11月13日

文件列表
framework

修改内容

1. 删除无效文件worker.js
2. 文件上传类组件取消上传bug修复
3. 文件上传类组件添加清空资源列表方法
4. 文件上传类组件添加maxSizeErrorTip参数，可自定义文件超出大小提示
5. excel导出参数规范
6. 富文本组件web端裂图bug修复
7. 富文本组件添加清除富文本内容方法
8. 修复高德地图在dialog上搜索不出内容bug
9. 默认element主题修改

#### 【1.3】2020年10月28日

文件列表
framework
.env.development
.env.staging
.env.production
package.json

修改内容

1. 资源id导致deepget失效bug修复
2. 行为数据使用base64加密后再上传
3. 优化deepget方法

#### 【1.2】2020年10月21日

1. 附件上传、音频上传组件优化
2. 选人控件删除debugger
3. 修复引入高德地图导致的body滚动条bug