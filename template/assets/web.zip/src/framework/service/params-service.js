import request from '@/framework/utils/http-request'

export function getParamsList(params) {
  return request('get', '/sysParams/list', params)
}
export function addParams(params) {
  return request('post', '/sysParams/add', params)
}
export function updateParams(params) {
  return request('post', '/sysParams/update', params)
}
export function deleteParams(params) {
  return request('get', '/sysParams/delete', params)
}
