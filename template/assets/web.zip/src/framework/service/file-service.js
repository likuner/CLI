import { getFileMd5 } from '@/framework/utils/file'
import httpRequest from '@/framework/utils/http-request'
import { deepGet, guid, getAppId, getAppBaseApi } from '@/framework/utils/common'
import { dataURLtoFile } from '@/framework/utils/file'
import store from '@/store'
const FILE_CHUNK_SIZE = 1024 * 1024 * 5//分块的大小5M S3最小分块大小;

export function getResourceUrl(resourceId) {
  return !resourceId ? null : `${window.location.origin}${getAppBaseApi()}/resource/download?token=${store.getters.token}&resourceId=${resourceId}`
}

/**
 * 根据资源id数组获取资源信息
 * @param {*} resourceIds
 * @param {*} md5
 */
export async function getResourceInfos(resourceIds) {
  const result = await httpRequest('post', '/resource/list', { resourceIds })
  if (result && result.errcode === 200) {
    return result.data
  } else {
    return null
  }
}

/**
 * 根据resourceId获取文件详情
 * @param {*} md5
 */
export async function getResourceInfoById(resourceId) {
  const result = await httpRequest('get', '/resource/get', { resourceId })
  if (result && result.errcode === 200) {
    return deepGet(result, 'data.sysResourceDTO', null)
  } else {
    return null
  }
}

/**
 * 根据md5获取文件详情
 * @param {*} md5
 */
async function getResource(md5, fileName) {
  const result = await httpRequest('get', '/resource/uploadPreCheck', { md5, fileName })
  if (result && result.errcode === 200) {
    return result.data
  } else {
    return null
  }
}

/**
 * 上传文件块到服务器
 * @param {*} file 分块资源
 * @param {*} md5 文件的md5
 * @param {*} partNumber 第几块
 * @param {*} resourceId 资源id
 * @param {*} uploadId 上传id
 */
async function multipartUpload(file, md5, partNumber, fileName) {
  const fd = new FormData()
  fd.append('file', file)
  const result = await httpRequest('post', `/resource/sliceUpload?md5=${md5}&partNumber=${partNumber}&fileName=${encodeURI(fileName)}`, fd)
  if (result && result.errcode === 200) {
    return result.data
  } else {
    console.error(result)
    return null
  }
}

/**
 * 分块文件合并
 * @param {*} fileName
 * @param {*} fileSize
 * @param {*} md5
 * @param {*} mimeType
 * @param {*} partMap
 * @param {*} resourceId
 * @param {*} uploadId
 */
async function multipartCompleted(fileName, fileSize, md5, mimeType, resourceId, extensionInfo = '') {
  const result = await httpRequest('post', `/resource/sliceUpload/completed?resourceId=${resourceId}&extensionInfo=${extensionInfo}`, {
    appId: getAppId(),
    fileName,
    fileSize,
    md5,
    mimeType: mimeType || 'application/octet-stream'
  })
  if (result && result.errcode === 200) {
    return result.data
  } else {
    return null
  }
}

/**
 * 小文件上传
 * @param {*} file 文件资源
 * @param {*} appId 应用id
 * @param {*} md5 资源的md5
 */
async function upload(file, extensionInfo = '', cb) {
  //用于取消上传，小文件上传取消无意义，为保持接口统一
  const taskId = guid()
  const md5 = await getFileMd5(file)
  const resource = await getResource(md5, file.name)
  const resourceInfo = deepGet(resource, 'sysResourceDTO', null)
  if (resourceInfo) {
    cb && cb(100, taskId)
    return resourceInfo
  } else {
    const fd = new FormData()
    fd.append('file', file)
    const result = await httpRequest('post', `/resource/upload?appId=${getAppId()}&extensionInfo=${extensionInfo}`, fd)
    cb && cb(100, taskId)
    if (result && result.errcode === 200) {
      return result.data
    } else {
      return null
    }
  }
}

const cancelUploadTaskId = new Set()
/**
 * 取消上传任务
 * @param {*} taskId 任务id
 */
export function cancelUploadFile(taskId) {
  cancelUploadTaskId.add(taskId)
}
const blobSlice = File.prototype.slice || File.prototype.mozSlice || File.prototype.webkitSlice
/**
 * 分块上传
 * @param {*} file 文件
 * @param {*} extensionInfo 扩展信息
 * @param {*} cb 回调
 */
async function partitionUploadFile(file, extensionInfo = '', cb) {
  const taskId = guid()
  // 把taskId通过回调暴露出去，方便取消上传
  cb && cb(0, taskId)
  const md5 = await getFileMd5(file)
  const resource = await getResource(md5, file.name)
  let resourceInfo = deepGet(resource, 'sysResourceDTO', null)
  let resourceId = deepGet(resourceInfo, 'resourceId')
  //文件已存在
  if (resourceInfo && resource.status === 1) {
    cb && cb(100, taskId)
    return resourceInfo
  }
  //已上传块
  const partInfoMap = deepGet(resource, 'partInfoMap', {})
  const uploadedChuncks = Object.values(partInfoMap)

  //分块的数量
  const chunks = Math.ceil(file.size / FILE_CHUNK_SIZE)
  let currentChunk = 0
  let uploadError = false
  while (currentChunk < chunks) {
    const start = currentChunk * FILE_CHUNK_SIZE
    const end = ((start + FILE_CHUNK_SIZE) >= file.size) ? file.size : start + FILE_CHUNK_SIZE
    const chunkFile = blobSlice.call(file, start, end)
    const chunkMd5 = await getFileMd5(chunkFile)
    //当前块没有上传过
    if (uploadedChuncks.indexOf(chunkMd5) === -1) {
      const res = await multipartUpload(chunkFile, md5, currentChunk + 1, file.name)
      uploadError = !res
      if (!resourceId && res) {
        resourceId = res.resourceId
      }
    }
    //上传失败
    if (uploadError) {
      console.error('上传失败')
      break
    } else if (cancelUploadTaskId.has(taskId)) {
      console.warn('取消上传')
      cancelUploadTaskId.delete(taskId)
      break
    } else {
      cb && cb(end / file.size * 95, taskId)
      currentChunk++
    }
  }
  //没有传完break
  if (currentChunk + 1 < chunks) {
    return null
  } else {
    resourceInfo = await multipartCompleted(file.name, file.size, md5, file.type, resourceId, extensionInfo)
    cb && cb(100, taskId)
    return resourceInfo
  }
}

/**
 * 上传文件到服务端
 * @param {*} file
 * @param {*} cb
 */
// 文件上传队列
const UPLOAD_FILE_QUEUE = []
// 同时上传的最大数量
const UPLOAD_FILE_LIMIT = 3
// 当前在传文件数据
let UPLOADDING_FILE_COUNT = 0
export async function uploadFileToServer(file, extensionInfo = '', cb) {
  return new Promise(resolve => {
    UPLOAD_FILE_QUEUE.push({ resolve, file, extensionInfo, cb })
    uploadNext()
  })
}

async function uploadNext() {
  if (UPLOADDING_FILE_COUNT < UPLOAD_FILE_LIMIT && UPLOAD_FILE_QUEUE.length) {
    const { resolve, file, extensionInfo, cb } = UPLOAD_FILE_QUEUE.shift()
    UPLOADDING_FILE_COUNT++
    const res = await uploadFile(file, extensionInfo, cb)
    UPLOADDING_FILE_COUNT--
    uploadNext()
    resolve(res)
  }
}
async function uploadFile(file, extensionInfo = '', cb) {
  let resourceInfo
  if (file.size <= FILE_CHUNK_SIZE) {
    resourceInfo = await upload(file, extensionInfo, cb)
  } else {
    resourceInfo = await partitionUploadFile(file, extensionInfo, cb)
  }
  return resourceInfo
}

/**
 * 上传base64图片到服务器
 * @param {*} dataurl
 * @param {*} cb
 */
export function uploadBase64ToServer(dataurl, fileName, cb) {
  const file = dataURLtoFile(dataurl, fileName)
  return uploadFileToServer(file, cb)
}

