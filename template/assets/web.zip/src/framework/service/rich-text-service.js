import request from '@/framework/utils/http-request'

/**
 * 根据code获取富文本信息
 * @param {*} code
 */
export function getRichTextByCode(code) {
  return request('get', '/richtext/get', { code })
}

/**
 * 保存富文本信息
 * @param {richText, resourceIdList, code} params
 */
export function saveRichtext(params) {
  return request('post', '/richtext/save', params)
}
