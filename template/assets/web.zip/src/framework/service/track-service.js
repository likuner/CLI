import store from '@/store'
import { guid, getAppId } from '@/framework/utils/common'
import router from '@/router'
import axios from 'axios'

let timer = null
let trackQueue = []

/**
 * params对象包含如下属性
 * dataSource: 数据来源 来源与框架或者应用自定义（framework / app） 默认app
 * taskId: 任务id 不传会默认添加uuid
 * taskType: 用户行为的业务标识用于标识业务数据的类型 数据分类以及控制消费方分类用
 * actionName: 动作标识 区分用户操作 枚举 login\submit\see\stay
 * stayTime: 停留时间 没有可不传
 * expand: 扩展字段
 */
export function report(params, immediate = false) {
  if (process.env.VUE_APP_TRACK_ENABLE !== 'true') {
    return
  }
  if (params) {
    params.userId = store.getters.staffId
    params.appId = getAppId()
    if (!params.dataSource) params.dataSource = 'app'
    if (!params.taskId) params.taskId = guid()
    const route = router.currentRoute
    params.pageName = route.name
    params.pageId = route.fullPath
    params.actionTime = Date.now()
    if (!params.stayTime) params.stayTime = 0
    params.clientType = 'web'
    params.clientInfo = {
      userAgent: window.navigator.userAgent
    }
    trackQueue.push(params)
  }
  if (immediate) {
    reportToServer()
  } else if (!timer) {
    timer = setTimeout(reportToServer, parseInt(process.env.VUE_APP_TRACK_FREQUENCY) * 1000 || 10 * 1000)
  }
}

export function reportToServer() {
  if (!trackQueue || trackQueue.length === 0) return
  if (timer) clearTimeout(timer)
  timer = null
  const data = window.btoa(window.encodeURIComponent(JSON.stringify({
    token: store.getters.token,
    data: trackQueue
  })))
  // navigator.sendBeacon 方法不存在或者返回false ajax重新提交
  if (!navigator.sendBeacon || !navigator.sendBeacon(process.env.VUE_APP_TRACK_URL, data)) {
    const Axios = axios.create({ baseURL: '' })
    Axios({
      method: 'post',
      url: process.env.VUE_APP_TRACK_URL,
      data
    })
  }
  trackQueue = []
}
