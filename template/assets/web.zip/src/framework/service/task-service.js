import request from '@/framework/utils/http-request'

export function jobTaskList(params) {
  return request('get', '/jobTask/list', params)
}
export function addJobTask(params) {
  return request('post', '/jobTask/add', params)
}
export function updateJobTask(params) {
  return request('post', '/jobTask/update', params)
}
export function deleteJobTask(params) {
  return request('get', '/jobTask/delete', params)
}
export function pauseJobTask(params) {
  return request('get', '/jobTask/pause', params)
}
export function resumeJobTask(params) {
  return request('get', '/jobTask/resume', params)
}
