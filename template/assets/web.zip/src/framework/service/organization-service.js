import request from '@/framework/utils/http-request'

export function getOrganizationList(params) {
  return request('get', '/sysOrganization/list', params)
}
export function addOrganization(params) {
  return request('post', '/sysOrganization/add', params)
}
export function updateOrganization(params) {
  return request('post', '/sysOrganization/update', params)
}
