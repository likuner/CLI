import request from '@/framework/utils/http-request'

export async function getCmcList(data) {
  const result = await request('get', '/cmc/list', data)
  if (result.errcode === 200 && result.data && result.data.result) {
    result.data.result.forEach(ele => {
      ele.managersName = nameJoin(ele.managers, 'objName')
      ele.scopeName = nameJoin(ele.manageScopes, 'objName')
    })
  }
  return result
}

function nameJoin(arr, key) {
  const names = []
  if (Array.isArray(arr)) {
    arr.forEach(element => {
      if (element[key] && element[key] !== '') {
        names.push(element[key])
      }
    })
  }
  return names.join(',')
}

export function getMyCmcList(data) {
  return request('get', '/cmc/myCmcList', data)
}

export function addCmc(data) {
  return request('post', '/cmc/add', data)
}

export function updateCmc(data) {
  return request('post', '/cmc/update', data)
}

export function deleteCmc(data) {
  return request('post', `/cmc/delete`, data)
}
