import httpRequest from '@/framework/utils/http-request'

/**
 * 上传安装许可证书
 */
export function uploadLisence(formData) {
  return httpRequest('post', '/license/upload', formData)
}
