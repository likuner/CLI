import request from '@/framework/utils/http-request'

export function isSuperAdmin(params) {
  return request('post', '/superAdmin/isSuperAdmin', params)
}
