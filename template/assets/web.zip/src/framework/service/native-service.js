import { getQueryParams } from '@/framework/utils/common'
import { getAppId } from '../utils/common'
import { inLanxin } from '../utils/dev'
/**
 * 运行环境是否是否在蓝信内
 */
export function isInLanxin() {
  console.warn('该方法将被删除，请使用inlanxin环境变量(import { inLanxin } from "@/framework/utils/dev")')
  return inLanxin
}

/**
 * 获取authcode
 */
export async function getAuthCode() {
  // 在蓝信宿主环境
  if (inLanxin) {
    let i = 1
    // getauthcode重试机制，分别设置2、4、6秒的超时
    let code = ''
    while (i <= 3 && !code) {
      code = await getSDKAuthCode(2000 * i++)
      console.log('getSDKAuthCode', code)
    }
    return code
  } else {
    //非宿主内 从url上获取code
    return getQueryParams('code')
  }
}

async function getSDKAuthCode(timeout = 2000) {
  console.log('开始获取authcode')
  return new Promise(resolve => {
    const timer = setTimeout(() => {
      console.log('getAuthCode timeout', timeout)
      resolve(null)
    }, timeout)
    window.lx.biz.getAuthCode({
      appId: getAppId(),
      success: function(res) {
        console.log('获取code成功', res)
        timer && clearTimeout(timer)
        resolve(res.authCode)
      },
      fail: function(e) {
        console.error('获取code失败', e)
        timer && clearTimeout(timer)
        resolve(null)
      }
    })
  })
}
