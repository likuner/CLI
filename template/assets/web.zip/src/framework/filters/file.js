import { formatFileSize } from '@/framework/utils/common'

export default [{
  name: 'format-filesize',
  value: function(value, opt) {
    return formatFileSize(value, opt)
  }
}]
