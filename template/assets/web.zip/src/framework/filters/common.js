import { deepGet } from '@/framework/utils/common'

export default [{
  name: 'deepGet',
  value: function(object, path, defaultValue) {
    return deepGet(object, path, defaultValue)
  }
}]
