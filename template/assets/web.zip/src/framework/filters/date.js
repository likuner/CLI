import { formatDate, formatTime, formatDuration } from '@/framework/utils/common'

function date(value, opt) {
  return formatDate(value, opt)
}

function time(time, fmt) {
  return formatTime(time, fmt)
}
export default [{
  name: 'date',
  value: date
},
{
  name: 'time',
  value: time
}, {
  name: 'formatDuration',
  value: formatDuration
}]
