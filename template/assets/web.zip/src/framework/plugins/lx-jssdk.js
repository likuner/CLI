import { inLanxin } from '../utils/dev'
import { getAppId } from '../utils/common'
import { getSignature } from '@/framework/service/user-service'

function install(Vue) {
  Vue.prototype.$JssdkReady = new Promise(function(resolve) {
    //jssdk注册错误时回调
    window.lx.error(function(err) {
      console.error('lx.error', err)
      resolve(false)
    })
    window.lx.ready(function() {
      resolve(true)
    })
    //注册sdk
    if (!inLanxin) {
      return resolve(false)
    }
    const timestamp = Date.now()
    const nonceStr = Date.now().toString()
    getSignature(timestamp, nonceStr).then(result => {
      if (!result || !result.data) {
        return resolve(false)
      }
      const params = {
        appId: getAppId(), // 必填，应用的唯一标识
        timestamp, // 必填，生成签名的时间戳，int型
        nonceStr, // 必填，生成签名的随机串
        signature: result.data // 必填，签名
      }
      console.log('lxjssdk-> config -> params', params)
      window.lx.config(params)
    })
  })
}

export default { install }

