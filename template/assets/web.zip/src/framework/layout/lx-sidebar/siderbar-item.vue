<template>
  <el-submenu :index="itemData.name" v-if="itemData.children && itemData.children.length > 0">
    <template slot="title">
      <item :itemData="itemData"></item>
    </template>
    <siderbar-item
      v-for="item of itemData.children"
      :key="item.name"
      :itemData="item"
      :level="level + 1"
      :class="'siderbar-level-'+(level + 1)"
    ></siderbar-item>
  </el-submenu>
  <el-menu-item :index="itemData.name" :key="itemData.name" v-else>
    <item :itemData="itemData"></item>
  </el-menu-item>
</template>

<script>
import Item from './item'
export default {
  name: 'siderbar-item',
  data() {
    return {}
  },
  props: {
    itemData: {
      type: Object,
      required: true
    },
    level: Number
  },
  components: {
    [Item.name]: Item
  },
  computed: {}
}
</script>

<style lang="scss" scoped>
/deep/ .el-menu-item:focus,
.el-menu-item:hover {
  background-color: transparent;
}
</style>
