<template>
  <div class="item" @click="itemClick">
    <i class="prefix-icon" v-if="prefixIcon" :style="prefixIcon"></i>

    <span class="menu-name">
      <el-tooltip effect="dark" :content="orginTitle" placement="right" v-if="orginTitle.length > 8">
        <span style="cursor: pointer;">{{title}}</span>
      </el-tooltip>
      <span style="cursor: pointer;" v-else>{{title}}</span>
    </span>

    <i class="suffix-icon" v-if="suffixIcon" :style="suffixIcon"></i>
  </div>
</template>

<script>
import { deepGet } from '@/framework/utils/common'
export default {
  name: 'item',
  data() {
    return {}
  },
  props: {
    itemData: {
      type: Object,
      required: true
    }
  },
  computed: {
    orginTitle() {
      return deepGet(this.itemData, 'meta.title', '')
    },
    title() {
      if (this.orginTitle.length > 8) {
        return this.orginTitle.slice(0, 8) + '...'
      } else {
        return this.orginTitle
      }
    },
    prefixIcon() {
      const prefix = deepGet(this.itemData, 'meta.prefix')
      let url = ''
      if (typeof prefix === 'string') {
        url = prefix
      } else if (typeof prefix === 'object') {
        url =
          this.activeItemName === this.itemData.name
            ? prefix.active
            : prefix.default
      }

      const result = url ? { 'background-image': `url(${url})` } : ''
      return result
    },
    suffixIcon() {
      const suffix = deepGet(this.itemData, 'meta.suffix')
      let url = ''
      if (typeof suffix === 'string') {
        url = suffix
      } else if (typeof suffix === 'object') {
        url =
          this.activeItemName === this.itemData.name
            ? suffix.active
            : suffix.default
      }

      const result = url ? { 'background-image': `url(${url})` } : ''
      return result
    },
    activeItemName() {
      return this.$route.name
    }
  },
  methods: {
    itemClick() {
      if (this.itemData.children && this.itemData.children.length > 0) return
      if (this.itemData.redirect) {
        this.$router.push(this.itemData.redirect)
      } else {
        this.$router.push(this.itemData)
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.item {
  display: flex;
  align-items: center;
  .menu-name {
    flex: 1;
  }
}
.prefix-icon {
  margin-right: 6px;
  width: 14px;
  height: 14px;
  background-size: 14px 14px;
  display: inline-block;
}
.suffix-icon {
  margin-left: 6px;
  margin-right: 15px;
  width: 14px;
  height: 14px;
  background-size: 14px 14px;
  display: inline-block;
}
</style>
