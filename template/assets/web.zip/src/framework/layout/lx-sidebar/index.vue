<template>
  <div class="lx-sidebar">
    <el-menu class="nav-menu" active-text-color="#0486fe" :default-active="key">
      <template v-for="(item,index) of menuData">
        <siderbar-item :key="item.name" :itemData="item" :level="1" class="siderbar-level-1"></siderbar-item>
        <div class="divider" :key="index" v-if="index !== menuData.length-1"></div>
      </template>
    </el-menu>
  </div>
</template>

<script>
import SidebarItem from './siderbar-item'
export default {
  name: 'lx-sidebar',
  data() {
    return {}
  },
  props: {
    menuData: {
      type: Array,
      required: true
    }
  },
  components: {
    [SidebarItem.name]: SidebarItem
  },
  computed: {
    key() {
      return this.$route.name
    }
  }
}
</script>

<style lang="scss" scoped>
.lx-sidebar {
  position: absolute;
  width: 260px;
  top: 120px;
  left: 0px;
  bottom: 0;
  overflow: auto;
  .home-item {
    height: 56px;
    display: flex;
    align-items: center;
    padding: 0 20px;
    cursor: pointer;
    color: #909399;
    i {
      font-size: 20px;
      margin-right: 5px;
    }
    .is-active {
      color: #0486fe;
    }
  }
  .nav-menu {
    position: absolute;
    min-width: 100%;
  }
}
.divider {
  height: 1px;
  width: 100px;
  background: #e4e7ed;
  margin: 0 10px;
  margin-left: 45px;
}
/deep/ .el-menu {
  border-right: none;
  background-color: transparent;
}
/deep/ .siderbar-level-1 > .item > .menu-name,
/deep/ .siderbar-level-1 > .el-submenu__title > .item > .menu-name {
  font-size: 18px;
  /* 修复全局body{font-size:12px}导致的导航字体变小 */
  * {
      font-size: 18px;
  }
}
/deep/ .siderbar-level-1 > .item > .prefix-icon,
/deep/ .siderbar-level-1 > .item > .suffix-icon,
/deep/ .siderbar-level-1 > .el-submenu__title > .item > .prefix-icon,
/deep/ .siderbar-level-1 > .el-submenu__title > .item > .suffix-icon {
  width: 18px;
  height: 18px;
  background-size: 18px 18px;
}

/deep/ .el-submenu .el-menu-item {
  padding: 0 20px;
}
</style>
