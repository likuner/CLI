<template>
  <div class="navigation" @click="navigationClick">
    <div class="navigation-title">
      <div class="navigation-title-left">
        <img class="lanxin-logo" :src="require('@/framework/assets/images/LOGO@2x.png')" />
        <div class="divider"></div>
        <div class="app-name">{{appName}}</div>
      </div>
      <div class="navigation-title-center">
        <div class="news" @click="visible=true" v-if="showNews">
          <div style="position: relative">
            <div class="notify" v-if="newsNum > 0">
              <span class="heartbit"></span>
              <span class="point"></span>
            </div>
            <img
              :src="require('@/framework/assets/images/ic_message@2x.png')"
              style="width:28px;height:28px"
            />
          </div>
        </div>
        <el-select
          :value="currentRole.powerId"
          :loading="isRoleListLoading"
          loading-text="权限列表刷新中..."
          placeholder="请选择"
          v-if="showRoleSelect"
          @change="roleChange"
          class="role-select"
        >
          <el-option-group
            :label="group.groupName"
            v-for="(group,index) in roleGroupList"
            :key="index"
            class="group-item"
          >
            <el-option
              v-for="role in group.roleList"
              :key="role.powerId"
              :label="role.powerName"
              :value="role.powerId"
            >
              <div class="power-name">{{ role.powerName }}</div>
              <div class="power-type-name">{{ role.powerTypeName }}</div>
            </el-option>
          </el-option-group>
        </el-select>
      </div>
      <el-avatar shape="square" :size="40" :src="staffId | staffId2Avatar">
        <img :src="require('@/framework/assets/images/default-avatar.png')" />
      </el-avatar>
    </div>
    <el-drawer :visible.sync="visible" direction="rtl" destroy-on-close>
      <drawer-inner-component></drawer-inner-component>
    </el-drawer>
  </div>
</template>

<script>
import { mapActions, mapGetters, mapMutations } from 'vuex'
import { isSuperAdmin } from '@/framework/service/super-admin-service'
import settingsRoutes from '@/framework/pages/settings/settings-routes'
import { Loading } from 'element-ui'
export default {
  name: 'lx-nav-menu',
  data: function() {
    return {
      drawer: false,
      value: null,
      lastClickTime: 0,
      clickNum: 0
    }
  },
  components: {
    'drawer-inner-component': () =>
      process.env.VUE_APP_DRAWER_INNER_COMPONENT_PATH &&
      import(process.env.VUE_APP_DRAWER_INNER_COMPONENT_PATH)
  },
  computed: {
    ...mapGetters([
      'roleList',
      'roleGroupList',
      'currentRole',
      'userName',
      'staffId',
      'newsNum',
      'drawerVisible',
      'appName',
      'isRoleListLoading'
    ]),
    visible: {
      get() {
        return this.drawerVisible
      },
      set(val) {
        val ? this.SHOW_DRAWER() : this.HIDDEN_DRAWER()
      }
    },
    showRoleSelect() {
      return this.currentRole && this.roleList && this.roleList.length > 1
    },
    showNews() {
      return this.currentRole && this.newsNum >= 0
    }
  },
  methods: {
    ...mapActions('user', ['setCurrentRole', 'getRoleList', 'logout']),
    ...mapMutations('news', ['SHOW_DRAWER', 'HIDDEN_DRAWER']),
    async roleChange(powerId) {
      const loadingInstance = Loading.service({
        fullscreen: true,
        text: '身份切换中...'
      })
      const role = this.getRoleByCode(powerId)
      if (role && (await this.setCurrentRole(role))) {
        // 修复同路由权限下，身份切换异常
        this.$router.replace(`/?cid=${Date.now()}`)
        loadingInstance.close()
      } else {
        loadingInstance.close()
        this.$notify.error('角色切换异常，请重试')
      }
    },
    getRoleByCode(id) {
      let res
      for (const ele of this.roleList) {
        if (ele.powerId === id) {
          res = ele
          break
        }
      }
      return res
    },
    layoutClick() {
      sessionStorage.clear()
      this.logout()
    },
    async navigationClick() {
      console.log(this.clickNum)
      if (Date.now() - this.lastClickTime < 300) {
        this.clickNum++
      } else {
        this.clickNum = 0
      }
      this.lastClickTime = Date.now()
      if (this.clickNum >= 6) {
        this.clickNum = 0
        // 检查当前登录人是否有权限
        const result = await isSuperAdmin()
        if (result.errcode === 200 && result.data) {
          console.log('settingsRoutes', settingsRoutes)
          this.$router.addRoutes(settingsRoutes)
          this.$router.push('/framework/settings/index')
        }
      }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.navigation {
  overflow: hidden;
  flex-shrink: 0;
  box-shadow: 2px 9px 16px -16px #d3d3d3;
}

.news {
  margin-right: 40px;
  display: flex;
  align-items: center;
  cursor: pointer;
}
/deep/ .el-drawer__body {
  position: relative;
}
/deep/ .el-drawer__header {
  margin-bottom: 20px;
}

.navigation-title {
  height: 80px;
  padding: 0 60px;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: white;
  flex-shrink: 0;
}

.lanxin-logo {
  height: 34px;
  width: auto;
  margin-top: 4px;
}
.app-name {
  font-size: 22px;
  color: #303133;
}
.notify {
  position: relative;
  top: 0px;
  right: 0px;
}
.notify .heartbit {
  position: absolute;
  top: -10px;
  right: -10px;
  height: 16px;
  width: 16px;
  z-index: 10;
  border: 5px solid #ef5350;
  border-radius: 70px;
  animation: heartbit 1s ease-out;
  animation-iteration-count: infinite;
}
.notify .point {
  width: 6px;
  height: 6px;
  border-radius: 30px;
  background-color: #ef5350;
  position: absolute;
  right: 0px;
  top: 0px;
}
@keyframes heartbit {
  0% {
    transform: scale(0);
    opacity: 0;
  }
  25% {
    transform: scale(0.1);
    opacity: 0.1;
  }
  50% {
    transform: scale(0.5);
    opacity: 0.3;
  }
  75% {
    transform: scale(0.8);
    opacity: 0.5;
  }
  100% {
    transform: scale(1);
    opacity: 0;
  }
}

.divider {
  height: 20px;
  width: 1px;
  background: #dcdfe6;
  margin: 0 10px;
}

.navigation-title-left {
  display: flex;
  align-items: center;
  flex-shrink: 0;
  span {
    font-size: 18px;
    margin: -1px 0 0 14px;
  }
}

.navigation-title-center {
  display: flex;
  flex: 1;
  justify-content: flex-end;
  padding: 0 20px;
}

.navigation-title-right {
  display: flex;
  align-items: stretch;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
}
/deep/ .el-select-dropdown__item {
  height: auto;
  line-height: 1.5;
  padding-top: 20px;
  padding-bottom: 16px;
}
.group-item:not(:last-of-type) {
  padding-bottom: 0;
}
.group-item:not(:last-of-type)::after {
  bottom: 0;
}

.power-name {
  font-size: 14px;
  line-height: 14px;
}
.power-type-name {
  font-size: 12px;
  color: #909399;
  margin-top: 10px;
  line-height: 12px;
}
.m-r-10 {
  margin-right: 10px;
}
</style>
