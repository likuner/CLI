<template>
  <div id="main">
    <lx-nav-menu></lx-nav-menu>
    <lx-sidebar class="sidebar" :menuData="menuData" v-show="!hideSideBar"></lx-sidebar>
    <div class="layout-container" ref="layoutContainer" :class="{ 'hide-sidebar': hideSideBar }">
      <div class="lx-page">
        <keep-alive :include="includeComponents">
          <router-view :key="$route.fullPath"></router-view>
        </keep-alive>
      </div>
    </div>
  </div>
</template>

<script>
import LxNavMenu from './lx-nav-menu/index'
import LxSideBar from './lx-sidebar/index'
import { mapGetters } from 'vuex'
import path from 'path'
import { deepGet } from '../utils/common'

export default {
  name: 'layout',
  data() {
    return {
      menuNames: [],
      menuData: []
    }
  },
  components: {
    [LxNavMenu.name]: LxNavMenu,
    [LxSideBar.name]: LxSideBar
  },
  computed: {
    ...mapGetters(['cachedPages', 'routes']),
    includeComponents() {
      return this.cachedPages || []
    },
    key() {
      return this.$route.name
    },
    hideSideBar() {
      return this.menuNames.indexOf(this.key) === -1
    }
  },
  watch: {
    $route: {
      handler() {
        if (this.$refs.layoutContainer) {
          this.$refs.layoutContainer.scrollTop = 0
        }
      },
      immediate: true
    },
    'routes': {
      handler() {
        this.menuNames = []
        this.menuData = this.filterRoutes(this.routes)
      },
      immediate: true
    }
  },
  methods: {
    /**
     * 生成nav
     */
    filterRoutes(routes, basePath) {
      const res = []
      if (!basePath) basePath = '/'
      if (!routes) return res
      routes.forEach(route => {
        const tmp = { ...route }
        tmp.path = path.resolve(basePath, tmp.path)
        const meta = deepGet(tmp, 'meta', {})
        const routeInfo = { isMenu: false }
        if (meta && !meta.hidden && meta.title) {
          res.push(tmp)
          this.menuNames.push(tmp.name)
        }
        if (meta && !meta.breadcrumb && meta.title) {
          meta.breadcrumb = [{ name: meta.title }]
        }
        if (tmp.children && tmp.children.length > 0) {
          tmp.children = this.filterRoutes(tmp.children, tmp.path)
        }
        routeInfo.breadcrumb = meta.breadcrumb
      })
      return res
    }
  }
}
</script>

<style lang="scss" scoped>
#main {
  height: 100%;
  position: relative;
}
#content {
  position: relative;
  flex: 1;
  .lx-breadcrumb {
    margin-bottom: 16px;
    line-height: 22px;
  }
}
.layout-container {
  position: absolute;
  top: 85px;
  left: 260px;
  right: 0px;
  bottom: 0;
  padding: 40px 60px 40px 40px;
  overflow: auto;
  .lx-page {
    height: 100%;
    position: relative;
  }
}
.hide-sidebar {
  left: 20px;
}
</style>
