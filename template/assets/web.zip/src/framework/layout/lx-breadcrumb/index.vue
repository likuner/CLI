<template>
  <div>
    <span class="page-name">{{pageName}}</span>
    <el-breadcrumb
      separator-class="el-icon-arrow-right"
      style="margin-top: 20px"
      v-if="parentList.length > 0"
    >
      <el-breadcrumb-item v-for="(item) in parentList" :key="item.path">
        <span v-if="!item.path" class="no-redirect">{{ item.name }}</span>
        <a v-else @click.prevent="handleLink(item)">{{ item.name }}</a>
      </el-breadcrumb-item>
    </el-breadcrumb>
  </div>
</template>

<script>
import { deepGet } from '@/framework/utils/common'
export default {
  name: 'lx-breadcrumb',
  data: function() {
    return {
      levelList: []
    }
  },
  props: {
    list: Array
  },
  computed: {
    pageName() {
      const l = this.levelList.length
      return deepGet(this.levelList, `[${l - 1}].name`)
    },
    parentList() {
      return this.levelList.slice(0, this.levelList.length - 1)
    }
  },
  watch: {
    $route: {
      handler() {
        console.log('route', this.list, this.getBreadcrumb())
        if (!this.list) {
          this.levelList = this.getBreadcrumb()
        }
      },
      immediate: true
    },
    list: {
      handler(val) {
        console.log('list list', arguments, this.getBreadcrumb())
        this.levelList = val || this.getBreadcrumb()
      },
      immediate: true
    }
  },
  methods: {
    getBreadcrumb() {
      const { meta } = this.$route
      if (meta && meta.breadcrumb) {
        return meta.breadcrumb
      } else {
        return [{ name: deepGet(meta, 'title') }]
      }
    },
    handleLink(item) {
      const { redirect, path } = item
      if (redirect) {
        this.$router.push(redirect)
        return
      }
      if (path === 'back') {
        this.$router.back()
      } else {
        this.$router.push(path || '/')
      }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.page-name {
  font-size: 22px;
  color: #303133;
  margin-bottom: 40px;
}
.no-redirect {
  color: #909399;
}
/deep/ .el-breadcrumb__inner a,
.el-breadcrumb__inner.is-link {
  font-weight: normal;
  color: #0486fe !important;
  cursor: pointer !important;
}
</style>
