export default {
  aspectRatio: 1, //目标图片比例
  title: '选择图片', //dialog title
  maxSize: null, //选择图片的大小限制 单位为B
  encoderOptions: 0.92, //可以从 0 到 1 的区间内选择图片的质量。如果超出取值范围，将会使用默认值 0.92
  file: null
}
