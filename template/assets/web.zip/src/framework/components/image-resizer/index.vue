<template>
  <el-dialog
    :title="this.options.title"
    class="image-resizer"
    :visible="dialogVisible"
    :before-close="closeDialog"
    append-to-body
  >
    <div>
      <div class="header">
        <div class="file-choose">
          <el-input v-model="fileName" placeholder="请选择图片" readonly></el-input>
          <el-button
            type="primary"
            size="small"
            class="choose-image-btn"
            @click="chooseImageClick"
          >选择</el-button>
          <input
            accept="image/png, image/jpeg"
            ref="fileBtn"
            style="display:none"
            name="image"
            type="file"
            @change="fileInputChange"
          />
        </div>
        <div class="tip-error" v-if="error">请上传不超过{{options.maxSize | format-filesize}}的图片</div>
        <div class="tip-text" v-else>
          支持JPG、PNG图片
          <template v-if="options.maxSize">且文件小于{{options.maxSize | format-filesize}}</template>
        </div>
      </div>
      <div class="content">
        <div class="cropper">
          <div class="tip-text">裁剪封面</div>
          <img class="cropper-image" ref="cropperImage" />
        </div>
        <div class="preview">
          <div class="tip-text">预览封面</div>
          <div class="preview-box" ref="previewBox"></div>
        </div>
      </div>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button @click="closeDialog">取 消</el-button>
      <el-button type="primary" @click="confirm">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
import Cropper from 'cropperjs'
import 'cropperjs/dist/cropper.min.css'

export default {
  name: 'image-resizer',
  data() {
    return {
      dialogVisible: true,
      cropper: null,
      insideSrc: '',
      fileName: '',
      error: false
    }
  },
  props: {
    options: {
      type: Object
    }
  },
  watch: {
    insideSrc(src) {
      this.replace(src)
    }
  },

  mounted() {
    this.$nextTick(() => {
      this.cropper = new Cropper(this.$refs.cropperImage, {
        aspectRatio: this.options.aspectRatio,
        preview: this.$refs.previewBox,
        checkCrossOrigin: true
      })
      this.fileName = this.options.file.name
      const reader = new FileReader()
      reader.readAsDataURL(this.options.file)
      reader.onload = event => {
        this.insideSrc = event.srcElement.result
      }
    })
  },
  methods: {
    /**
     * dialog关闭
     */
    closeDialog() {
      this.dialogVisible = false
      this.options.cancelCb()
    },
    /**
     * 确认
     */
    confirm() {
      this.dialogVisible = false
      this.options.confrimCb(this.getImage())
    },
    chooseImageClick() {
      this.$refs.fileBtn.click()
    },
    fileInputChange(event) {
      const files = event.target.files
      if (files && files[0]) {
        const file = files[0]
        if (this.options.maxSize && this.options.maxSize < file.size) {
          this.error = true
          return
        } else {
          this.error = false
        }
        this.fileName = file.name
        const reader = new FileReader()
        reader.readAsDataURL(file)
        reader.onload = event => {
          this.insideSrc = event.srcElement.result
        }
      }
    },
    replace(src) {
      this.cropper.replace(src)
      this.insideSrc = src
    },
    getImage() {
      const canvas = this.cropper.getCroppedCanvas()
      if (canvas) {
        return canvas.toDataURL('image/jpeg', this.options.encoderOptions)
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.file-choose {
  display: flex;
  align-items: center;
}
.content {
  display: flex;
  justify-content: space-between;
  margin-top: 10px;
}
.choose-image-btn {
  width: 100px;
  margin-left: 20px;
}
.cropper {
  width: 320px;
  background-size: 320px;
  .cropper-image {
    height: 320px;
    width: 320px;
    max-width: 100%;
    background-size: 320px;
    background-image: url("./images/default.png");
  }
}
.preview {
  margin-left: 20px;
  width: 260px;
}
.preview-box {
  height: 260px;
  width: 260px;
  margin: 0 auto;
  overflow: hidden;
  border: 1px solid #ebebeb;
}
.tip-text,
.tip-error {
  margin-bottom:10px;
  font-size: 14px;
  color: #303133;
  letter-spacing: 0;
  line-height: 14px;
  margin-top: 5px;
}
.tip-error {
  color: #f56c6c;
}
.text-center {
  text-align: center;
}

/deep/ .el-dialog {
  width: 640px;
  .el-dialog__body {
    padding: 10px 20px;
    flex: 1;
  }
  .el-dialog__footer {
    background-color: #fff;
    .ctrl-btn{
      width: 100px;
    }
  }
}
</style>
