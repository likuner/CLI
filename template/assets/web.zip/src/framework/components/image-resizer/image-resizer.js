import Vue from 'vue'
import ImageResizer from './index'
import DEFAULT_OPTIONS from './options'

export function chooseImage(options = {}) {
  return new Promise(function(resolve) {
    options = Object.assign({}, DEFAULT_OPTIONS, options, {
      confrimCb: (data) => {
        imageResizerComp.$destroy()
        resolve({ action: 'confirm', data })
      },
      cancelCb: () => {
        imageResizerComp.$destroy()
        resolve({ action: 'cancel' })
      }
    })
    const ImageResizerDilaog = Vue.extend(ImageResizer)
    const imageResizerComp = new ImageResizerDilaog({ propsData: { options }}).$mount()
  })
}
