<template>
  <div>
    <div class="image-item" :style="imageStyle" v-if="total">
      <el-image
        style="height:100%;width:100%"
        :style="{ opacity: image.status === 'uploaded' ? 1 : 0.5 }"
        v-if="getImageSrc(image)"
        :src="getImageSrc(image)"
        fit="fill"
      ></el-image>
      <!-- 编辑状态或可以预览 展示遮罩 -->
      <div class="mask" v-if="canPreview || !disabled">
        <i class="el-icon-full-screen" @click="showPreview()" v-if="canPreview"></i>
        <i class="el-icon-delete" @click="deleteClick()" v-if="!disabled"></i>
      </div>
      <div :class="['upload-status', `upload-status-${image.status}`]" v-if="!disabled">
        <i v-if="image.status === 'uploaded'" class="el-icon-check"></i>
        <i v-else-if="image.status === 'error'" class="el-icon-close"></i>
        <i v-else-if="image.status === 'pending'" class="el-icon-upload2"></i>
      </div>
    </div>
    <div :style="imageStyle" class="image-add" @click="addClick" v-if="!total && !disabled">
      <i class="el-icon-plus" style="font-size: 22px;"></i>
      <span v-if="text">{{text}}</span>
    </div>
  </div>
</template>

<script>
import { deepGet, deepClone, formatFileSize } from '@/framework/utils/common'
import { chooseImage } from './image-resizer'
import { openImageChoose, dataURLtoFile } from '@/framework/utils/file'
import {
  getResourceInfoById,
  uploadFileToServer,
  getResourceUrl
} from '@/framework/service/file-service'
import { preview } from '@/framework/components/image-viewer/image-viewer'

export default {
  name: 'image-resizer-input',
  data() {
    return {
      total: 0,
      image: {
        localSrc: null,
        status: 'uploaded',
        uploadProgress: 0,
        uploadTaskId: '',
        resource: {
          resourceId: null
        }
      }
    }
  },
  props: {
    width: {
      type: String,
      default: '120px'
    },
    height: {
      type: String,
      default: '120px'
    },
    margin: {
      type: String,
      default: '6px'
    },
    canPreview: {
      type: Boolean,
      default: true
    },
    initResourceId: {
      type: String
    },
    disabled: {
      type: Boolean,
      default: false
    },
    maxSize: {
      type: Number,
      default: null
    },
    aspectRatio: {
      type: Number,
      default: 1
    },
    encoderOptions: {
      type: Number,
      default: 0.92
    },
    text: {
      type: String,
      default: ''
    }
  },
  watch: {
    initResourceId: {
      handler() {
        this.initImage()
      },
      immediate: true
    }
  },
  computed: {
    imageStyle() {
      return {
        width: this.width,
        height: this.height,
        margin: this.margin
      }
    }
  },
  methods: {
    getImageSrc(image) {
      return (
        image.localSrc || getResourceUrl(
          deepGet(image, `resource.imageThumbnailList.${image.resourceId}~400.resourceId`) ||
            deepGet(image, `resource.imageThumbnailList.${image.resourceId}~200.resourceId`) ||
            deepGet(image, `resource.imageThumbnailList.${image.resourceId}~800.resourceId`) ||
            image.resource.resourceId
        )
      )
    },
    initImage() {
      if (this.initResourceId) {
        this.total = 1
        const image = {
          localSrc: null,
          status: 'uploaded',
          uploadProgress: 0,
          uploadTaskId: '',
          resource: {
            resourceId: this.initResourceId
          }
        }
        getResourceInfoById(this.initResourceId).then(resourceInfo => {
          if (resourceInfo) {
            this.$set(image, 'resource', resourceInfo)
          }
        })
        this.image = image
      } else {
        this.deleteClick()
      }
    },
    async addClick() {
      if (this.disabled) return
      const oFile = await openImageChoose(false)
      if (!oFile) {
        return
      }
      if (this.maxSize && oFile.size > this.maxSize) {
        this.$message(`请上传不超过${formatFileSize(this.maxSize)}的图片`)
        return
      }
      const dialog = await chooseImage({
        file: oFile,
        maxSize: this.maxSize,
        aspectRatio: this.aspectRatio,
        encoderOptions: this.encoderOptions
      })
      if (dialog.action === 'confirm') {
        this.total = 1
        const image = {
          localSrc: dialog.data,
          status: 'pending',
          resource: {
            resourceId: null
          }
        }
        const file = dataURLtoFile(dialog.data, oFile.name)
        uploadFileToServer(file, '', function(uploadProgress, uploadTaskId) {
          // 上传进度
          image.uploadProgress = uploadProgress
          image.uploadTaskId = uploadTaskId
        }).then(resourceInfo => {
          if (resourceInfo) {
            image.status = 'uploaded'
            this.$set(image, 'resource', resourceInfo)
          } else {
            image.status = 'error'
          }
          this.$emit('upload-change', deepClone(this.image))
        })
        this.image = image
        this.$emit('upload-change', deepClone(this.image))
      }
    },
    deleteClick() {
      this.total = 0
      this.image = {
        localSrc: null,
        status: 'uploaded',
        resource: {
          resourceId: null
        }
      }
    },
    showPreview() {
      preview([this.getImageSrc(this.image)], 0)
    }
  },
  created() {
    this.initImage()
  }
}
</script>
<style lang='scss' scoped>
.image-upload {
  display: flex;
  flex-wrap: wrap;
}
.image-item {
  position: relative;
  border-radius: 4px;
  overflow: hidden;
  .mask {
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 9;
    cursor: default;
    text-align: center;
    color: #fff;
    opacity: 0;
    font-size: 20px;
    background-color: rgba(0, 0, 0, 0.5);
    transition: opacity 0.3s;
    display: flex;
    align-items: center;
    justify-content: center;
    i {
      margin: 5px;
      cursor: pointer;
    }
  }
  &:hover {
    .mask {
      opacity: 1;
    }
  }
  .upload-status {
    position: absolute;
    right: -17px;
    top: -7px;
    width: 46px;
    height: 26px;
    text-align: center;
    transform: rotate(45deg);
    i {
      font-size: 12px;
      margin-top: 12px;
      transform: rotate(-45deg);
      color: #fff;
    }
  }
  .upload-status-uploaded {
    background: #409eff;
  }
  .upload-status-error {
    background: #f56c6c;
  }
  .upload-status-pending {
    background: #909399;
  }
}
.image-add {
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1px dashed #c0ccda;
  border-radius: 4px;
  cursor: pointer;
  flex-direction: column;
  color: #999999;
  padding: 10px;
  text-align: center;
  box-sizing: border-box;
  span {
    margin-top: 6px;
  }
}
.image-add:hover {
  border-color: #409eff;
}
</style>
