<template>
  <div class="audio-upload" v-if="!disabled || count > 0" :class="{'disabled': disabled}">
    <ul>
      <li v-for="(audio, index) in list" :key="index">
        <template v-if="!resourceLoaded">
          <div class="skeleton-audio-info">
            <div class="skeleton-audio-type"></div>
            <div class="skeleton-name-size">
              <div class="skeleton-name"></div>
              <div class="skeleton-size"></div>
            </div>
          </div>
        </template>
        <template v-else>
          <div class="audio-info">
            <img :src="require('@/framework/assets/images/file-icons/audio.png')" class="audio-type" />
            <div class="name-size">
              <div class="name o-ellipsis">{{audio | deepGet('resource.fileName')}}</div>
              <div class="size o-ellipsis">
                <span>
                  <i class="el-icon-paperclip"></i>
                  {{audio | deepGet('resource.size', 0) | format-filesize(1)}}
                </span>
                <span style="margin-left:5px" v-if="audio.resource.extension.duration">
                  <i class="el-icon-video-play"></i>
                  {{audio | deepGet('resource.extension.duration') | formatDuration}}
                </span>
              </div>
            </div>
            <div class="ctrl-icons">
              <i class="el-icon-delete" @click="deleteClick(index)" v-if="!disabled"></i>
              <i class="el-icon-download" @click="downloadClick(index)"></i>
            </div>
          </div>
          <div :class="['upload-status', `upload-status-${audio.status}`]" v-if="!disabled">
            <i v-if="audio.status === 'uploaded'" class="el-icon-check"></i>
            <i v-else-if="audio.status === 'error'" class="el-icon-close"></i>
            <i v-else-if="audio.status === 'pending'" class="el-icon-upload2"></i>
          </div>
          <div
            class="bg-progress"
            :style="{'width': audio.uploadProgress + '%'}"
            v-show="audio.status === 'pending'"
          ></div>
        </template>
      </li>
    </ul>
    <div class="add-audio-btn" v-if="canAdd && !disabled">
      <el-button :disabled="!resourceLoaded" type="text" @click="addClick">{{label}}</el-button>
    </div>
  </div>
</template>

<script>
import { deepGet } from '@/framework/utils/common'
import {
  getResourceInfos,
  uploadFileToServer,
  getResourceUrl
} from '@/framework/service/file-service'
import { openAudioChoose, downloadFile } from '../../utils/file'
import Upload from '@/framework/minix/upload'
export default {
  name: 'audio-upload',
  data: function() {
    return {}
  },
  props: {
    label: {
      type: String,
      default: '上传音频'
    },
    initResourceIds: {
      type: Array
    }
  },
  mixins: [Upload],
  created() {
    this.initAudioList()
  },
  methods: {
    /**
     * 初始化audioList
     */
    initAudioList() {
      if (!this.initResourceIds || this.initResourceIds.length === 0) {
        this.resourceLoaded = true
        return
      }
      this.list = this.initResourceIds.map((resourceId, index) => {
        return {
          order: index,
          status: 'uploaded',
          resource: {
            resourceId,
            extension: {}
          }
        }
      })
      getResourceInfos(this.initResourceIds).then(resourceInfoMap => {
        if (resourceInfoMap) {
          this.list.forEach(audio => {
            const resourceInfo = resourceInfoMap[audio.resource.resourceId]
            if (resourceInfo) {
              this.$set(audio, 'resource', resourceInfo)
              try {
                resourceInfo.extension =
                JSON.parse(resourceInfo.extensionInfo) || {}
              } catch (e) {
                resourceInfo.extension = {}
                console.error(e)
              }
            }
          })
        }
        this.resourceLoaded = true
      })
    },
    /**
     * 添加文件
     */
    async addClick(fileArr) {
      let oaudioList
      if (Array.isArray(fileArr)) {
        oaudioList = fileArr
      } else {
        oaudioList = await openAudioChoose(true)
      }
      const exceedMaxSizeFiles = []
      for (const oFile of oaudioList) {
        if (!this.canAdd) break
        if (this.maxSize > 0 && oFile.size > this.maxSize) {
          exceedMaxSizeFiles.push(oFile)
          continue
        }
        const audio = {
          order: this.list.length,
          status: 'pending',
          resource: {
            fileName: oFile.name,
            size: oFile.size,
            mimeType: oFile.type,
            extension: {},
            extensionInfo: ''
          },
          uploadProgress: 0,
          uploadTaskId: ''
        }
        const extension = await this.getAudioExtension(
          URL.createObjectURL(oFile)
        )
        console.log('extension', extension)
        audio.resource.extension = extension
        try {
          audio.resource.extensionInfo = JSON.stringify(extension)
        } catch (e) {
          console.error(e)
        }
        // 图片上传到服务器
        uploadFileToServer(
          oFile,
          encodeURIComponent(audio.resource.extensionInfo),
          function(uploadProgress, uploadTaskId) {
            // 上传进度
            audio.uploadProgress = uploadProgress
            audio.uploadTaskId = uploadTaskId
          }
        ).then(resourceInfo => {
          if (resourceInfo) {
            audio.status = 'uploaded'
            try {
              resourceInfo.extension =
                JSON.parse(resourceInfo.extensionInfo) || {}
            } catch (e) {
              resourceInfo.extension = {}
              console.error(e)
            }
            this.$set(audio, 'resource', resourceInfo)
          } else {
            audio.status = 'error'
          }
          this.triggerUploadChange(audio)
        })
        this.list.push(audio)
        this.triggerUploadChange(audio)
      }
      if (exceedMaxSizeFiles.length > 0) {
        this.$message.error(this.maxSizeErrorTip)
        this.triggerExceedMaxSize(exceedMaxSizeFiles)
      }
    },
    /**
     * 下载文件
     */
    downloadClick(idx) {
      const fileName = deepGet(this.list, `[${idx}].resource.fileName`)
      const resourceId = deepGet(this.list, `[${idx}].resource.resourceId`)
      if (resourceId) {
        downloadFile(getResourceUrl(resourceId), fileName)
      } else {
        this.$message.error('文件下载失败')
      }
    },
    /**
     * 获取视频扩展信息
     * {
     *  duration：视频时长
     * }
     *
     */
    async getAudioExtension(localSrc) {
      return new Promise(resolve => {
        const audio = document.createElement('audio')
        audio.preload = 'metadata'
        audio.onloadedmetadata = function() {
          resolve({ duration: audio.duration })
        }
        audio.onerror = function() {
          resolve({})
        }
        audio.src = localSrc
      })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.audio-upload {
  border: 1px solid #e8e8ec;
  border-radius: 3px;
}
.add-audio-btn {
  display: block;
  height: 36px;
  line-height: 36px;
  text-align: center;
}
ul {
  li {
    position: relative;
    display: flex;
    border-bottom: 1px solid #e8e8ec;
    overflow: hidden;
    .audio-info {
      flex: 1 0 0;
      display: flex;
      overflow: hidden;
      align-items: center;
      padding: 12px 16px;
      .audio-type {
        width: 36px;
        height: 36px;
      }
      .name-size {
        overflow: hidden;
        margin-left: 6px;
        margin-right: 6px;
        flex: 1;
        .name {
          font-size: 14px;
          line-height: 20px;
          height: 20px;
        }
        .size {
          color: #999999;
          height: 16px;
          line-height: 16px;
          font-size: 12px;
        }
      }

      .ctrl-icons {
        font-size: 18px;
        i {
          margin: 2px;
          cursor: pointer;
        }
      }
    }
    .skeleton-audio-info {
      flex: 1 0 0;
      display: flex;
      overflow: hidden;
      align-items: center;
      padding: 12px 16px;
      .skeleton-audio-type {
        width: 36px;
        height: 36px;
        background-color: #ebeef5;
        border-radius: 4px;
      }
      .skeleton-name-size {
        overflow: hidden;
        margin-left: 6px;
        margin-right: 6px;
        flex: 1;
        .skeleton-name {
          width: 80%;
          height: 16px;
          margin-bottom: 6px;
          background-color: #ebeef5;
        }
        .skeleton-size {
          width: 30%;
          height: 12px;
          background-color: #ebeef5;
        }
      }
    }

    .upload-status {
      position: absolute;
      right: -17px;
      top: -7px;
      width: 46px;
      height: 26px;

      text-align: center;
      transform: rotate(45deg);
      i {
        font-size: 12px;
        margin-top: 12px;
        transform: rotate(-45deg);
        color: #fff;
      }
    }
    .upload-status-uploaded {
      background: #409eff;
    }
    .upload-status-error {
      background: #f56c6c;
    }
    .upload-status-pending {
      background: #909399;
    }
    .bg-progress {
      position: absolute;
      height: 100%;
      background-color: #409eff;
      opacity: 0.2;
      z-index: 0;
      transition: width 0.3s;
    }
  }
}
.disabled {
  ul li:last-child {
    border: none;
  }
}
.o-ellipsis {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>
