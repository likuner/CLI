<template>
  <div class="data-provider">
    <slot :data="list" :loading="loading" :total="total"></slot>
    <el-pagination
      v-show="total > 10"
      class="pagination"
      background
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="pageNo"
      :page-sizes="[10, 20, 50, 100, 200]"
      :page-size="20"
      layout="total, sizes, prev, pager, next, jumper"
      :total="total"
    ></el-pagination>
  </div>
</template>

<script>
export default {
  name: 'data-provider',
  data: function() {
    return {
      list: [],
      loading: false,
      total: 0,
      pageNo: 1,
      pageSize: 20
    }
  },
  props: {
    provider: {
      type: Function,
      required: true
    },
    condition: {
      type: Object
    }
  },
  methods: {
    async reloadData() {
      this.pageNo = 1
      return this.loadData()
    },
    async loadData() {
      this.$emit('before-data-load')
      this.loading = true
      await this.$nextTick()
      const res = await this.provider(Object.assign({}, this.condition, { pageSize: this.pageSize, pageNo: this.pageNo }))
      if (res.errcode === 200) {
        const data = res.data
        this.list = data.result
        this.total = data.total
        this.$emit('data-loaded', data)
      } else {
        this.$message.error('数据加载失败')
      }
      this.loading = false
    },
    handleCurrentChange(pageNo) {
      this.pageNo = pageNo
      this.loadData()
    },
    handleSizeChange(pageSize) {
      this.pageSize = pageSize
      this.loadData()
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.pagination {
  margin-top: 20px;
  text-align: right;
}
</style>
