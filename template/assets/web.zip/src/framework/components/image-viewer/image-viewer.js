import Vue from 'vue'
import ImageViewer from './index'

export function preview(urlList, initialIndex) {
  return new Promise(function(resolve) {
    const options = Object.assign({}, { urlList, initialIndex }, {
      onClose: () => {
        ImageViewerInstance.$destroy()
        resolve()
      }
    })
    const ImageViewerConstructor = Vue.extend(ImageViewer)
    const ImageViewerInstance = new ImageViewerConstructor({ propsData: options }).$mount()
  })
}
