import Vue from 'vue'
import OrgStaffSelector from './index'
import { deepClone } from '@/framework/utils/common'
import DEFAULT_OPTIONS from './org-staff-options'

/**
 * 选人选部门选标签
 * @param {*} params 选中部门、人员、标签
 * eg:
 * {
 *    selectedStructs: [{
 *      id: 部门id,
 *      name: 部门名称
 *    }],
 *    selectedMembers: [{
 *      staffId:人员id,
 *      name: 人员名称
 *    }],
 *    selectedTags:[{
 *      tagId: 标签id,
 *      tagName: 标签名称
 *    }]
 * }
 *
 * @param {*} options 配置
 * eg.
 * {
 *    selectMode: 选人模式，默认值PersonAndStruct, //PersonAndStruct、Struct、Person
 *    filter: "", 选标签模式，默认不开启 //Tag、Person
 *    maxPerson: null, 最多选人个数，默认不限制
 * }
 *
 */
export function chooseOrgStaff(params = {}, options = {}) {
  return new Promise(function(resolve) {
    options = Object.assign({}, DEFAULT_OPTIONS, deepClone(options || {}), {
      confrimCb: (data) => {
        selectDialogComp.$destroy()
        resolve({ action: 'confirm', data })
      },
      cancelCb: () => {
        selectDialogComp.$destroy()
        resolve({ action: 'cancel' })
      }
    })
    const SelectorDilaog = Vue.extend(OrgStaffSelector)
    const selectDialogComp = new SelectorDilaog({ propsData: { options: options, params: deepClone(params) }}).$mount()
  })
}
