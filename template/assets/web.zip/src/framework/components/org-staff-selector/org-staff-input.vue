<template>
  <div class="org-staff-input">
    <el-input
      class="tag-input"
      :placeholder="count === 0 ? placeholder : ''"
      suffix-icon="el-icon-arrow-down"
      readonly
      :disabled="disabled"
      ref="elInput"
      @click.native="choose"
    ></el-input>
    <div class="tag-container" ref="tagContainer" @click="choose">
      <template v-if="selectedStructs && selectedStructs.length > 0">
        <el-popover
          placement="top"
          width="300"
          trigger="hover"
          v-if="selectedStructs.length - 1 > 0"
        >
          <div class="tag-list">
            <el-tag
              size="small"
              type="info"
              v-for="item of selectedStructs"
              :key="item.id"
            >{{item.name}}</el-tag>
          </div>
          <el-tag size="small" type="info" class="tag" slot="reference">
            <i class="el-icon-coin"></i>
            {{selectedStructs[0].name}}
            <span
              class="tag-more"
            >+{{selectedStructs.length - 1}}</span>
          </el-tag>
        </el-popover>
        <el-tag size="small" type="info" class="tag" v-else>
          <i class="el-icon-coin"></i>
          {{selectedStructs[0].name}}
        </el-tag>
      </template>
      <template v-if="selectedTags && selectedTags.length > 0">
        <el-popover placement="top" width="300" trigger="hover" v-if="selectedTags.length - 1 > 0">
          <div class="tag-list">
            <el-tag
              size="small"
              type="info"
              v-for="(item, index) of selectedTags"
              :key="index"
            >{{item.tagName}}</el-tag>
          </div>
          <el-tag size="small" type="info" class="tag" slot="reference">
            <i class="el-icon-price-tag"></i>
            {{selectedTags[0].tagName}}
            <span
              class="tag-more"
            >+{{selectedTags.length - 1}}</span>
          </el-tag>
        </el-popover>
        <el-tag size="small" type="info" class="tag" v-else>
          <i class="el-icon-price-tag"></i>
          {{selectedTags[0].tagName}}
        </el-tag>
      </template>
      <template v-if="selectedMembers && selectedMembers.length > 0">
        <el-popover
          placement="top"
          width="300"
          trigger="hover"
          v-if="selectedMembers.length - 1 > 0"
        >
          <div class="tag-list">
            <el-tag
              size="small"
              type="info"
              v-for="(item,index) of selectedMembers"
              :key="index"
            >{{item.name}}</el-tag>
          </div>
          <el-tag size="small" type="info" class="tag" slot="reference">
            <i class="el-icon-user"></i>
            {{selectedMembers[0].name}}
            <span
              class="tag-more"
            >+{{selectedMembers.length - 1}}</span>
          </el-tag>
        </el-popover>
        <el-tag size="small" type="info" class="tag" v-else>
          <i class="el-icon-user"></i>
          {{selectedMembers[0].name}}
        </el-tag>
      </template>
    </div>
  </div>
</template>

<script>
import { chooseOrgStaff } from './org-staff-selector' //选人控件
import ResizeObserver from 'resize-observer-polyfill'
import { deepGet } from '@/framework/utils/common'
import Emitter from '@/framework/minix/emitter'

export default {
  name: 'org-staff-input',
  data() {
    return {
      selectedMembers: [],
      selectedStructs: [],
      selectedTags: []
    }
  },
  mixins: [Emitter],
  props: {
    placeholder: String,
    value: Object,
    disabled: {
      type: Boolean,
      default: false
    },
    options: Object
  },
  computed: {
    count() {
      return (
        deepGet(this.selectedMembers, 'length', 0) +
        deepGet(this.selectedStructs, 'length', 0) +
        deepGet(this.selectedTags, 'length', 0)
      )
    }
  },
  watch: {
    value: {
      handler: function(val, oldVal) {
        if (val) {
          this.selectedStructs = val.selectedStructs
          this.selectedTags = val.selectedTags
          this.selectedMembers = val.selectedMembers
        } else {
          this.selectedStructs = []
          this.selectedTags = []
          this.selectedMembers = []
        }
        if (val !== oldVal) {
          this.dispatch('ElFormItem', 'el.form.change', val)
        }
      },
      immediate: true
    }
  },
  mounted() {
    // tagContainer大小变化时，重新计算input高度
    const ro = new ResizeObserver(() => {
      this.resetInputHeight()
    })
    ro.observe(this.$refs.tagContainer)
    this.$once('hook:beforeDestory', () => {
      ro.unobserve(this.$refs.tagContainer)
    })
  },
  methods: {
    async choose() {
      if (this.disabled) return
      const dialog = await chooseOrgStaff(
        {
          selectedMembers: this.selectedMembers,
          selectedStructs: this.selectedStructs,
          selectedTags: this.selectedTags
        },
        this.options
      )
      if (dialog.action === 'confirm') {
        const { selectedMembers, selectedStructs, selectedTags } = dialog.data
        this.selectedMembers = selectedMembers
        this.selectedStructs = selectedStructs
        this.selectedTags = selectedTags
        const result =
          selectedMembers.length === 0 &&
          selectedStructs.length === 0 &&
          selectedTags.length === 0
            ? null
            : {
              selectedMembers,
              selectedStructs,
              selectedTags
            }
        this.$emit('input', result)
      }
    },

    resetInputHeight() {
      this.$nextTick(() => {
        if (!this.$refs.tagContainer || !this.$refs.elInput) return
        const inputElm = this.$refs.elInput.$el.querySelector('input')
        if (this.count > 0) {
          inputElm.style.height = this.$refs.tagContainer.clientHeight + 'px'
        } else {
          inputElm.style.height = ''
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.org-staff-input {
  position: relative;
  line-height: 40px;
}
/deep/ input {
  cursor: pointer;
}
.tag {
  margin-right: 5px;
}
.tag-list {
  max-height: 200px;
  overflow: auto;
  /deep/ .el-tag {
    margin: 5px;
  }
}
.tag-container {
  position: absolute;
  box-sizing: border-box;
  top: 0;
  z-index: 10;
  width: 100%;
  padding: 0px 30px 0px 15px;
}
.tag-more {
  margin-left: 5px;
  color: #409eff;
}
</style>
