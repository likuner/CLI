<template>
  <el-dialog
    :title="title"
    class="tag-selector"
    :visible="dialogVisible"
    :before-close="closeDialog"
    append-to-body
  >
    <div class="tag-selector-left" :class="'tag-selector-left--'+options.filter">
      <div class="left-container" v-loading="treeLoading">
        <div class="label-list">
          <template v-if="treeError">
            <div class="tree-load-fail">
              <div class="error-tip">
                <img :src="require('@/framework/assets/images/notfound.png')" alt="网站连接异常或数据加载失败" />
                <p>网站连接异常或数据加载失败</p>
              </div>
              <el-button class="retry" size="small" @click="retryBtnClick">重试</el-button>
            </div>
          </template>
          <el-tree
            class="tag-tree"
            node-key="tagId"
            show-checkbox
            :empty-text="treeLoading?'':'暂无数据'"
            :data="treeData"
            :props="defaultProps"
            :render-after-expand="false"
            :default-checked-keys="checkedKeys"
            @check="tagCheck"
            @node-click="nodeClick"
            ref="tree"
          ></el-tree>
        </div>
      </div>
      <div class="right-container">
        <div class="top-container">
          <template v-if="options.filter==='Person'">
            <div class="summary">
              已选人员 {{selectedMembers.length}} 个
              <span
                v-if="options.maxPerson > 0"
              >(最多 {{options.maxPerson}} 个)</span>
            </div>
            <el-tag
              v-for="(item,index) in selectedMembers"
              :key="item.staffId"
              closable
              type="info"
              size="small"
              class="tag"
              :disable-transitions="disableTransitions"
              @close="removeMember(index)"
            >{{item.name}}</el-tag>
          </template>
          <template v-else>
            <el-tag
              v-for="(item,index) in selectedTags"
              :key="index"
              :closable="options.filter==='Tag'?true:false"
              type="info"
              size="small"
              class="tag"
              :disable-transitions="disableTransitions"
              @close="removeTag(index)"
            >{{item.tagName}}</el-tag>
            <div class="no-data" v-if="selectedTags.length===0">请选择标签</div>
          </template>
        </div>
        <div class="bottom-container">
          <template v-if="currentTag.tagId">
            <template v-if="currentCache&&currentCache.userList&&currentCache.userList.length>0">
              <div
                class="peo-list"
                v-infinite-scroll="loadMore"
                :infinite-scroll-disabled="infiniteDisabled"
              >
                <el-tag
                  class="peo-item"
                  v-for="(item,index) in currentCache.userList"
                  :key="index"
                  :disable-transitions="disableTransitions"
                >
                  <el-checkbox
                    :value="selectedMemberIds.indexOf(item.staffId) > -1"
                    :label="item.name"
                    @click.native.prevent="staffCBoxClick(item)"
                    :disabled="staffCheckBoxDisabled"
                  ></el-checkbox>
                </el-tag>
              </div>
              <p v-if="currentCache&&currentCache.loading">加载中...</p>
              <p v-if="currentCache&&currentCache.noMore&&currentCache.userList.length>50">没有更多了</p>
            </template>
            <template v-else>
              <div class="no-data">该标签下暂无人员</div>
            </template>
          </template>
          <template v-else>
            <div class="no-data">请选择标签</div>
          </template>
        </div>
      </div>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button @click="closeDialog" class="ctrl-btn">取 消</el-button>
      <el-button type="primary" @click="confirm" class="ctrl-btn">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
import {
  fetchTagGroupList,
  fetchOrgMemberListByOneTag
} from '@/framework/service/org-service'
import { deepGet } from '@/framework/utils/common'
export default {
  name: 'tag-selector',
  data() {
    return {
      dialogVisible: true,
      disableTransitions: true,
      treeData: null,
      treeLoading: false,
      treeError: false,
      checkedKeys: [],
      cacheTagStaffs: {},
      currentTag: {},
      selectedTags: [],
      selectedMembers: []
    }
  },
  props: {
    options: {
      type: Object,
      default: function() {
        return {}
      }
    },
    params: {
      type: Object,
      default: function() {
        return {}
      }
    }
  },
  computed: {
    /**
     * 员工的checkbox是否可用
     */
    staffCheckBoxDisabled() {
      const { maxPerson } = this.options
      return maxPerson && this.selectedMembers.length >= maxPerson
    },
    /**
     * dialog的title
     */
    title() {
      const idx = ['Tag', 'Person'].indexOf(this.options.filter)
      return ['选择标签', '选择人员'][idx] || '选择'
    },
    /**
     * 加载更多员工是否可用
     */
    infiniteDisabled() {
      return (
        this.currentCache &&
        (this.currentCache.loading || this.currentCache.noMore)
      )
    },
    /**
     * 当前选中标签id
     */
    currentTagId() {
      return deepGet(this.currentTag, 'tagId')
    },
    currentCache() {
      return this.cacheTagStaffs[this.currentTagId]
    },
    //左侧树配置选项
    defaultProps: function() {
      return {
        children: 'tags',
        label: function(data) {
          return data.tagGroupName ? data.tagGroupName : data.tagName
        },
        isLeaf: function(data) {
          return !!data.tagName
        }
      }
    },
    selectedTagIds() {
      return this.selectedTags.map(ele => {
        return ele.tagId
      })
    },
    selectedMemberIds() {
      return this.selectedMembers.map(ele => {
        return ele.staffId
      })
    },
    selectedTagNames() {
      return this.selectedTags.map(ele => {
        return ele.tagName
      })
    },
    selectedMemberNames() {
      return this.selectedMembers.map(ele => {
        return ele.name
      })
    }
  },
  created() {
    //初始化传参
    this.selectedMembers = this.params.selectedMembers
    this.selectedTags = this.params.selectedTags
    this.loadTree()
  },
  methods: {
    /**
     * dialog关闭
     */
    closeDialog() {
      this.dialogVisible = false
      this.options.cancelCb()
    },
    /**
     * 确认
     */
    confirm() {
      this.dialogVisible = false
      this.options.confrimCb({
        selectedTags: this.selectedTags,
        selectedTagNames: this.selectedTagNames,
        selectedMembers: this.selectedMembers,
        selectedMemberNames: this.selectedMemberNames
      })
    },
    //刷新左侧标签树
    retryBtnClick() {
      this.treeError = false
      this.loadTree()
    },
    //加载左侧标签树
    loadTree() {
      this.treeLoading = true
      fetchTagGroupList()
        .then(res => {
          this.treeLoading = false
          if (res.errcode === 200) {
            this.treeData = deepGet(res, 'data', [])
            //TODO 无标签情况显示
            this.checkedKeys = this.selectedTagIds
          } else {
            this.treeError = true
          }
        })
        .catch(err => {
          this.treeLoading = false
          this.treeError = true
          console.error(err)
        })
    },
    /**
     * 监听人员checkBox
     */
    staffCBoxClick(staff) {
      if (this.staffCheckBoxDisabled) return
      //存在 删除
      const idx = this.selectedMemberIds.indexOf(staff.staffId)
      if (idx > -1) {
        this.selectedMembers.splice(idx, 1)
      } else {
        this.selectedMembers.push(staff)
      }
    },
    //鼠标滑动时根据当前标签分页获取人员信息
    async loadMore() {
      if (
        this.currentTagId &&
        this.currentCache.noMore &&
        this.currentCache.pageNo > 1
      ) {
        this.currentCache.loading = true
        await this.getNodesNext()
        this.currentCache.loading = false
      }
    },
    //选人模式下监听选中二级标签时，更新当前选中标签，加载对应人员信息
    async nodeClick(data, node) {
      //非选人模式下 或者选择一级节点不加载数据
      if (node.level === 1 || this.options.filter !== 'Person') return
      if (!this.options.filter === 'Person' || !data.tagId) return
      this.currentTag = data
      await this.getNodesNext()
    },
    //获取人员信息
    async getNodesNext() {
      //已经有缓存数据 直接返回
      if (this.currentCache) {
        return
      } else {
        this.$set(this.cacheTagStaffs, this.currentTagId, {
          pageNo: 1,
          userList: [],
          noMore: false,
          loading: false
        })
      }
      //没有缓存数据初始化缓存数据
      const res = await fetchOrgMemberListByOneTag(
        this.currentTagId,
        this.currentCache.pageNo
      )
      if (res.errcode === 200) {
        const data = deepGet(res, 'data.result', [])
        this.currentCache.userList.push(...data)
        if (deepGet(res, 'data.hasMore')) {
          this.currentCache.pageNo++
        } else {
          this.currentCache.noMore = true
        }
      }
    },
    // 选标签模式下监听左侧标签checkBox选中状态
    tagCheck(data, checkData) {
      this.selectedTags = checkData.checkedNodes.filter(ele => {
        return ele && ele.tagId && ele.tagName
      })
    },
    /**
     * 移除标签
     */
    removeTag(idx) {
      this.selectedTags.splice(idx, 1)
      this.$refs.tree.setCheckedKeys(this.selectedTagIds)
    },
    /**
     * 移除人的选中
     */
    removeMember(idx) {
      this.selectedMembers.splice(idx, 1)
    }
  }
}
</script>

<style lang="scss" scoped>
.tag-selector-left {
  height: 410px;
  display: flex;
  .no-data {
    color: #999999;
    padding: 10px 0;
    font-size: 12px;
  }
}
.left-container {
  height: 100%;
  width: 40%;
  box-sizing: border-box;
  border-right: 1px solid #e9e9e9;
  overflow: auto;
  position: relative;
  .tag-tree {
    position: absolute;
    min-width: 100%;
  }
}
.right-container {
  height: 100%;
  width: 60%;
  box-sizing: border-box;
}
.top-container {
  box-sizing: border-box;
  height: 35%;
  padding: 0 10px;
  overflow-y: auto;
  .summary {
    margin: 10px;
  }
}
.bottom-container {
  box-sizing: border-box;
  height: 65%;
  padding-left: 10px;
  border-top: 1px solid #e9e9e9;
  overflow: hidden;
  .peo-list {
    display: flex;
    flex-wrap: wrap;
    max-height: 290px;
    overflow-y: auto;
    .peo-item {
      margin: 5px;
    }
  }
  p {
    text-align: center;
  }
}
.tag {
  margin: 5px;
}
.tree-load-fail {
  text-align: center;
  .error-tip {
    padding: 20px 20px 10px 20px;
    text-align: center;
    img {
      width: 70%;
    }
  }
  .retry {
    width: 80px;
    margin-top: 10px;
  }
}
/deep/ .el-loading-spinner {
  margin-top: 0;
}
.tag-selector-left--Person .left-container /deep/ {
  .el-tree-node:focus > .el-tree-node__content {
    background-color: #ffffff;
  }
  .is-expanded .is-current > .el-tree-node__content {
    background-color: #f5f7fa !important;
  }
  .el-tree > .is-current > .el-tree-node__content {
    background-color: initial !important;
  }
  .el-checkbox {
    display: none;
  }
}
.tag-selector-left--Tag {
  .bottom-container {
    display: none;
  }
  .top-container {
    height: 100%;
  }
}
/deep/ .el-dialog {
  width: 640px;
  height: 540px;
  .el-dialog__body {
    border-top: 1px solid #e9e9e9;
    border-bottom: 1px solid #e9e9e9;
    padding: 20px;
    flex: 1;
  }
  .el-dialog__footer {
    background-color: #fff;
    text-align: center;
    .ctrl-btn {
      width: 100px;
    }
  }
}
</style>
