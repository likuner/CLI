export default {
  filter: 'Person', //Tag、Person
  maxPerson: 10 //最多选择人数
}
