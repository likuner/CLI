export default {
  selectMode: 'PersonAndStruct', //PersonAndStruct、Struct、Person
  filter: '', //Tag、Person
  maxPerson: null
}
