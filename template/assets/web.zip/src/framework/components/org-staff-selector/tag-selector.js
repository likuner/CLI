import Vue from 'vue'
import TagSelector from './tag-selector.vue'

import DEFAULT_OPTIONS from './tag-options'

export function chooseTagStaff(params = {}, options = {}) {
  return new Promise(function(resolve) {
    options = Object.assign({}, DEFAULT_OPTIONS, options || {}, {
      confrimCb: (data) => {
        selectorDilaogComp.$destroy()
        resolve({ action: 'confirm', data })
      },
      cancelCb: () => {
        selectorDilaogComp.$destroy()
        resolve({ action: 'cancel' })
      }
    })
    const SelectorDilaog = Vue.extend(TagSelector)
    const selectorDilaogComp = new SelectorDilaog({ propsData: { options: options, params }}).$mount()
  })
}
