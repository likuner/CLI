import Vue from 'vue'
import VideoViewer from './index'

export function preview(urlList, initialIndex) {
  return new Promise(function(resolve) {
    const options = Object.assign({}, { urlList, initialIndex }, {
      onClose: () => {
        VideoViewerInstance.$destroy()
        resolve()
      }
    })
    const VideoViewerConstructor = Vue.extend(VideoViewer)
    const VideoViewerInstance = new VideoViewerConstructor({ propsData: options }).$mount()
  })
}
