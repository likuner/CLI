<template>
  <ul class="video-upload">
    <li class="video-item" :style="videoStyle" v-for="(video, index) of list" :key="index">
      <template v-if="getVideoSrc(video)">
        <video :src="getVideoSrc(video)"></video>
        <div class="video-info" style="display:none">
          <span class="file-size" v-if="video.resource.fileSize">{{video | deepGet('resource.size', 0) | format-filesize(1)}}</span>
          <span class="file-duration">{{video | deepGet('resource.extension.duration') | formatDuration}}</span>
        </div>
      </template>
      <i class="el-icon-video-play video-play"></i>
      <!-- 编辑状态或可以预览 展示遮罩 -->
      <div class="mask" v-if="canPreview || !disabled">
        <i class="el-icon-full-screen" @click="showPreview(index)" v-if="canPreview"></i>
        <i class="el-icon-delete" @click="deleteClick(index)" v-if="!disabled"></i>
      </div>
      <div :class="['upload-status', `upload-status-${video.status}`]" v-if="!disabled">
        <i v-if="video.status === 'uploaded'" class="el-icon-check"></i>
        <i v-else-if="video.status === 'error'" class="el-icon-close"></i>
        <i v-else-if="video.status === 'pending'" class="el-icon-upload2"></i>
      </div>
      <div
        class="bg-progress"
        :style="{'height': video.uploadProgress + '%'}"
        v-if="video.status === 'pending'"
      ></div>
    </li>
    <li :style="videoStyle" class="video-add" @click="addVideoClick" v-if="canAdd && !disabled">
      <i class="el-icon-plus" style="font-size: 22px"></i>
      <span v-if="text">{{text}}</span>
    </li>
  </ul>
</template>

<script>
import { getResourceInfoById, uploadFileToServer, getResourceUrl } from '@/framework/service/file-service'
import { openVideoChoose } from '@/framework/utils/file'
import { preview } from '@/framework/components/video-viewer/video-viewer'
import { deepGet } from '../../utils/common'
import Upload from '@/framework/minix/upload'

export default {
  name: 'video-upload',
  data: function() {
    return { }
  },
  props: {
    width: {
      type: String,
      default: '160px'
    },
    height: {
      type: String,
      default: '120px'
    },
    margin: {
      type: String,
      default: '6px'
    },
    canPreview: {
      type: Boolean,
      default: true
    },
    initResourceIds: {
      type: Array
    },
    text: {
      type: String,
      default: ''
    }
  },
  mixins: [Upload],
  computed: {
    /**
     * 图片默认样式
     */
    videoStyle() {
      return {
        width: this.width,
        height: this.height,
        margin: this.margin
      }
    },
    /**
     * 视频列表src数组
     */
    previewList() {
      return this.list.map(ele => {
        return this.getVideoSrc(ele)
      })
    }
  },
  created() {
    this.initVideoList()
  },
  methods: {
    /**
     * 初始化videoList
     */
    initVideoList() {
      this.list = []
      if (this.initResourceIds) {
        this.initResourceIds.forEach((resourceId, index) => {
          const video = {
            order: index,
            status: 'uploaded',
            resource: {
              resourceId,
              extension: {}
            }
          }
          getResourceInfoById(resourceId).then(resourceInfo => {
            if (resourceInfo) {
              try {
                resourceInfo.extension = JSON.parse(resourceInfo.extensionInfo) || {}
              } catch (e) {
                resourceInfo.extension = {}
                console.error(e)
              }
              this.$set(video, 'resource', resourceInfo)
            }
          })
          this.list.push(video)
        })
      }
    },
    async addVideoClick(fileArr) {
      let oFileList
      if (Array.isArray(fileArr)) {
        oFileList = fileArr
      } else {
        oFileList = await openVideoChoose(true)
      }
      const exceedMaxSizeFiles = []
      for (const oFile of oFileList) {
        if (!this.canAdd) break
        if (this.maxSize > 0 && oFile.size > this.maxSize) {
          exceedMaxSizeFiles.push(oFile)
          continue
        }
        const localSrc = URL.createObjectURL(oFile)
        const video = {
          localSrc,
          status: 'pending',
          order: this.count,
          uploadProgress: 0,
          uploadTaskId: '',
          resource: {
            extensionInfo: '',
            extension: {},
            fileName: oFile.fileName,
            size: oFile.size
          }
        }
        const extension = await this.getVideoExtension(localSrc)
        video.resource.extension = extension
        try {
          video.resource.extensionInfo = JSON.stringify(extension)
        } catch (e) { console.error(e) }
        // 图片上传到服务器
        uploadFileToServer(oFile, encodeURIComponent(video.resource.extensionInfo), function(
          uploadProgress,
          uploadTaskId
        ) {
          // 上传进度
          video.uploadProgress = uploadProgress
          video.uploadTaskId = uploadTaskId
        }).then(resourceInfo => {
          if (resourceInfo) {
            video.status = 'uploaded'
            try {
              resourceInfo.extension = JSON.parse(resourceInfo.extensionInfo) || {}
            } catch (e) {
              resourceInfo.extension = {}
              console.error(e)
            }
            this.$set(video, 'resource', resourceInfo)
          } else {
            video.status = 'error'
          }
          this.triggerUploadChange(video)
        })
        this.list.push(video)
        this.triggerUploadChange(video)
      }
      if (exceedMaxSizeFiles.length > 0) {
        this.$message.error(this.maxSizeErrorTip)
        this.triggerExceedMaxSize(exceedMaxSizeFiles)
      }
    },
    /**
     * 获取视频src
     */
    getVideoSrc(video) {
      return video.localSrc || getResourceUrl(deepGet(video, 'resource.resourceId'))
    },
    showPreview(idx) {
      preview(this.previewList, idx)
    },
    /**
     * 获取视频扩展信息
     * {
     *  duration：视频时长
     *  width: 宽
     *  height: 高
     * }
     *
     */
    async getVideoExtension(localSrc) {
      return new Promise(resolve => {
        const video = document.createElement('video')
        video.preload = 'metadata'
        video.onloadedmetadata = function() {
          resolve({ duration: video.duration })
        }
        video.onerror = function() {
          resolve({})
        }
        video.src = localSrc
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.video-upload {
  display: flex;
  flex-wrap: wrap;
}
.video-item {
  position: relative;
  border-radius: 4px;
  overflow: hidden;
  border: 1px dotted lightgray;
  box-sizing: border-box;
  video {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  .video-play {
    position: absolute;
    font-size: 28px;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    z-index: 2;
  }
  .mask {
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 9;
    cursor: default;
    text-align: center;
    color: #fff;
    opacity: 0;
    font-size: 20px;
    background-color: rgba(0, 0, 0, 0.5);
    transition: opacity 0.3s;
    display: flex;
    align-items: center;
    justify-content: center;
    i {
      margin: 5px;
      cursor: pointer;
    }
  }
  &:hover {
    .mask {
      opacity: 1;
    }
  }
  .upload-status {
    position: absolute;
    right: -17px;
    top: -7px;
    width: 46px;
    height: 26px;
    text-align: center;
    transform: rotate(45deg);
    i {
      font-size: 12px;
      margin-top: 12px;
      transform: rotate(-45deg);
      color: #fff;
    }
  }
  .upload-status-uploaded {
    background: #409eff;
  }
  .upload-status-error {
    background: #f56c6c;
  }
  .upload-status-pending {
    background: #909399;
  }
  .bg-progress {
    position: absolute;
    height: 0;
    width: 100%;
    bottom: 0;
    background-color: #409eff;
    opacity: 0.4;
    z-index: 0;
    transition: height 0.3s;
    z-index: 1;
  }
}
.video-add {
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1px dashed #c0ccda;
  border-radius: 4px;
  cursor: pointer;
  flex-direction: column;
  color: #999999;
  padding: 10px;
  text-align: center;
  box-sizing: border-box;
  span {
    margin-top: 6px;
  }
}
.video-add:hover {
  border-color: #409eff;
}
</style>
