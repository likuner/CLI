<template>
  <el-dialog
    title="上传图片"
    class="image-upload"
    :visible="dialogVisible"
    :before-close="closeDialog"
    append-to-body
    width="700px"
  >
    <div class="image-upload-container">
      <image-upload ref="uploader" :canPreview="false"></image-upload>
    </div>

    <div slot="footer" class="dialog-footer" style="text-align: center">
      <el-button @click="closeDialog" style="width:100px">取消</el-button>
      <el-button type="primary" @click="confirmClick" style="width:100px">确认</el-button>
    </div>
  </el-dialog>
</template>

<script>
import ImageUpload from '@/framework/components/image-upload'
export default {
  name: 'image-upload-dialog',
  data() {
    return {
      dialogVisible: true,
      imageList: [],
      imageUploading: false
    }
  },
  props: {
    options: {
      type: Object,
      required: true
    }
  },
  components: {
    [ImageUpload.name]: ImageUpload
  },
  methods: {
    /**
     * dialog关闭
     */
    closeDialog() {
      this.dialogVisible = false
      this.options.cancelCb()
    },
    confirmClick() {
      this.dialogVisible = false
      if (this.$refs.uploader.uploadStatus.pending > 0) {
        this.$message.info('文件上传中，请稍等...')
        return
      }
      if (this.$refs.uploader.uploadStatus.error > 0) {
        this.$message.error(`${this.$refs.uploader.uploadStatus.error}张图片上传失败，请先删除失败文件`)
        return
      }
      this.options.confrimCb(this.$refs.uploader.list)
    }
  }

}
</script>

<style lang="scss" scoped>
.image-upload-container {
  height: 350px;
  overflow: auto;
}
</style>
