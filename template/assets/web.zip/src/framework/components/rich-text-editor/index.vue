<template>
  <div class="rich-text-editor">
    <div v-if="!disabled" v-loading="!(dataLoaded && componentLoaded)" class="tinymce-editor">
      <tinymce-editor
        v-model="richTextInfo.standardRichText"
        ref="tinymceEditor"
        @hook:created="editorCreated"
        @input="valueChange"
      ></tinymce-editor>
    </div>
    <div
      v-else-if="lazy"
      v-loading="!dataLoaded"
      v-html="richTextInfo.standardRichText"
      v-lazy-container="{ selector: 'img' }"
      class="rich-text-container"
    ></div>
    <div
      v-else
      v-loading="!dataLoaded"
      v-html="richTextInfo.standardRichText"
      class="rich-text-container"
    ></div>
  </div>
</template>
<script>
import { deepGet } from '@/framework/utils/common'
import {
  getRichTextByCode,
  saveRichtext
} from '@/framework/service/rich-text-service'
import { getResourceUrl } from '@/framework/service/file-service'
import VueLazyload from 'vue-lazyload'
import Vue from 'vue'

Vue.use(VueLazyload, {
  preLoad: 1.3,
  attempt: 1,
  listenEvents: ['scroll']
})

const TinymceEditor = () => ({
  component: import(/* webpackChunkName: "tinymce-editor" */ './tinymce-editor')
})
export default {
  name: 'rich-text-editor',
  data: function() {
    return {
      componentLoaded: false,
      dataLoaded: false,
      richTextInfo: {
        code: '',
        richText: '',
        standardRichText: '',
        resourceIdMap: {}
      }
    }
  },
  components: {
    TinymceEditor
  },
  props: {
    // 是否可编辑
    disabled: Boolean,
    code: String,
    lazy: Boolean
  },
  watch: {
    code: {
      handler(val) {
        this.resetRichText(val)
      },
      immediate: true
    }
  },
  methods: {
    async resetRichText(code) {
      if (!code) {
        this.dataLoaded = true
        this.richTextInfo.code = ''
        this.richTextInfo.richText = ''
        this.richTextInfo.standardRichText = ''
        this.richTextInfo.resourceIdMap = {}
        return
      } else {
        this.dataLoaded = false
        const result = await getRichTextByCode(code)
        this.dataLoaded = true
        if (result.errcode === 200) {
          this.richTextInfo.code = deepGet(result, 'data.code')
          this.richTextInfo.richText = deepGet(result, 'data.richText')
          this.richTextInfo.resourceIdMap = deepGet(
            result,
            'data.resourceIdMap'
          )
          this.richTextInfo.standardRichText = this.getStandardRichText(
            this.richTextInfo.richText,
            this.richTextInfo.resourceIdMap
          )
        } else {
          this.$emit('data-load-error', result)
        }
        this.$nextTick(function() {
          this.$emit('render-completed')
        })
      }
    },
    getStandardRichText(richText, resourceIdMap) {
      const rootElm = document.createElement('div')
      rootElm.innerHTML = richText
      rootElm.querySelectorAll('img').forEach(imgElm => {
        const resourceId = imgElm.getAttribute('data-resource-id')
        if (this.lazy) {
          imgElm.setAttribute(
            'data-src',
            resourceId ? getResourceUrl(resourceId) : imgElm.getAttribute('src')
          )
          imgElm.removeAttribute('src')
        } else {
          imgElm.setAttribute(
            'src',
            resourceId ? getResourceUrl(resourceId) : imgElm.getAttribute('src')
          )
        }
      })
      return rootElm.innerHTML
    },
    valueChange(val) {
      this.$emit('change', val)
    },
    editorCreated() {
      this.componentLoaded = true
    },
    /**
     * 对外暴露方法
     * 保存富文本
     */
    async save() {
      if (this.disabled) return
      const richTextInfo = this.$refs.tinymceEditor.getRichTextInfo()
      const params = {
        richText: richTextInfo.richText,
        resourceIdList: richTextInfo.resourceIdList.join(',')
      }
      if (this.richTextInfo.code) params.code = this.richTextInfo.code
      const result = await saveRichtext(params)
      if (result.errcode === 200) {
        this.richTextInfo.code = result.data.code
        this.richTextInfo.resourceIdList = result.data.resourceIdList
        this.richTextInfo.richText = result.data.richText
        return result.data
      }
      return null
    },
    /**
     * 外暴露的方法
     * 清空富文本内容
     */
    clear() {
      this.richTextInfo.standardRichText = ''
    }
  }
}
</script>
<style lang="scss" scoped>
.rich-text-editor {
  min-height: 300px;
}
.rich-text-container {
  word-break: break-all;
  /deep/ img {
    max-width: 100% !important;
    height: auto !important;
  }
  /deep/ img[lazy="error"],
  /deep/ img[lazy="loading"] {
    width: 100%;
    height: 300px!important;
    background-color: #F2F6FC;
  }
}
</style>
