import Vue from 'vue'
import ImageUploadDialog from './image-upload-dialog.vue'

const tinymce = window.tinymce
tinymce.PluginManager.add('yfupimgs', function(editor) {
  var pluginName = '多图片上传'
  const yfupimgs = {} //扔外部公共变量，也可以扔一个自定义的位置

  yfupimgs.images_upload_handler = editor.getParam('images_upload_handler', undefined, 'function')
  yfupimgs.images_upload_base_path = editor.getParam('images_upload_base_path', '', 'string')
  yfupimgs.yfupimgs_filetype = editor.getParam('yfupimgs_filetype', '.png,.gif,.jpg,.jpeg', 'string')
  yfupimgs.res = []

  editor.ui.registry.getAll().icons.yfupimgs || editor.ui.registry.addIcon('yfupimgs', '<svg width="24" height="24"><path d="M5 15.7l3.3-3.2c.3-.3.7-.3 1 0L12 15l4.1-4c.3-.4.8-.4 1 0l2 1.9V5H5v10.7zM5 18V19h3l2.8-2.9-2-2L5 17.9zm14-3l-2.5-2.4-6.4 6.5H19v-4zM4 3h16c.6 0 1 .4 1 1v16c0 .6-.4 1-1 1H4a1 1 0 0 1-1-1V4c0-.6.4-1 1-1zm6 8a2 2 0 1 0 0-4 2 2 0 0 0 0 4z" fill-rule="nonzero"></path></svg>')

  const openDialog = async function() {
    const result = await showDialog()
    const images = result.data
    console.log(images)
    if (result.action === 'confirm' && Array.isArray(images) && images.length > 0) {
      let html = ''
      images.forEach(image => {
        html += `<img src="${image.localSrc}" data-resource-id="${image.resource.resourceId}" />`
      })
      editor.insertContent(html)
    }
  }

  editor.ui.registry.addButton('yfupimgs', {
    icon: 'yfupimgs',
    tooltip: pluginName,
    onAction: function() {
      openDialog()
    }
  })
  editor.ui.registry.addMenuItem('yfupimgs', {
    icon: 'yfupimgs',
    text: '图片批量上传...',
    onAction: function() {
      showDialog()
    }
  })
})

function showDialog(options = {}) {
  return new Promise(function(resolve) {
    options = Object.assign({}, options, {
      confrimCb: (data) => {
        imageUploadInstance.$destroy()
        resolve({ action: 'confirm', data })
      },
      cancelCb: () => {
        imageUploadInstance.$destroy()
        resolve({ action: 'cancel' })
      }
    })
    const ImageUploadConstructor = Vue.extend(ImageUploadDialog)
    const imageUploadInstance = new ImageUploadConstructor({ propsData: { options }}).$mount()
  })
}
