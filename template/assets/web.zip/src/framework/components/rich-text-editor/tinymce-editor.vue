<template>
  <editor :init="options" v-model="editorValue" ref="tinymceEditor"></editor>
</template>
<script>
import Editor from '@tinymce/tinymce-vue'
import 'tinymce/tinymce'
import 'tinymce/themes/silver'
import 'tinymce/plugins/image'
import 'tinymce/plugins/fullscreen'
import 'tinymce/plugins/preview'
import 'tinymce/plugins/link'
import 'tinymce/plugins/insertdatetime'
import 'tinymce/plugins/media'
import 'tinymce/plugins/table'
import 'tinymce/plugins/lists'
import 'tinymce/plugins/hr'
import './image-upload-plugin'

import { options } from './config'
/**
 * https://segmentfault.com/a/1190000018358304
 * http://tinymce.ax-z.cn/
 */
export default {
  name: 'tinymce-editor',
  components: { Editor },
  props: {
    value: {
      type: String
    }
  },
  data: function() {
    return {
      options: Object.assign({}, options, {
        setup: (editor) => {
          editor.on('paste', (e) => {
            this.formatOuterImage()
          })
        }
      })
    }
  },
  computed: {
    editorValue: {
      get() {
        return this.value
      },
      set(val) {
        this.$emit('input', val)
      }
    }
  },
  methods: {
    getRichTextInfo() {
      const htmlBody = this.$refs.tinymceEditor.editor.getBody()
      const cloneBody = htmlBody.cloneNode(true)
      const result = {
        orginRichText: htmlBody.innerHTML,
        richText: '',
        resourceIdList: []
      }
      const lxImages = cloneBody.querySelectorAll('img[data-resource-id]')
      for (let i = 0; i < lxImages.length; i++) {
        const element = lxImages[i]
        const resourceId = element.getAttribute('data-resource-id')
        result.resourceIdList.push(resourceId)
        element.setAttribute('src', resourceId)
        element.removeAttribute('data-mce-src')
      }
      result.richText = cloneBody.innerHTML
      return result
    },
    formatOuterImage(elm) {
      const outerImages = this.$refs.tinymceEditor.editor.getBody().querySelectorAll('img:not([data-resource-id])')
      for (let i = 0; i < outerImages.length; i++) {
        const elm = outerImages[i]
        const whiteList = ['src', 'data-resource-id']
        // 已处理过
        if (elm['data-mce-style']) continue
        for (const key in elm) {
          if (!whiteList.includes(key)) {
            elm.removeAttribute(key)
          }
        }
      }
    }
  }
}
</script>
