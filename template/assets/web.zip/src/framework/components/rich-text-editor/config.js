export const toolbar = ['undo redo bold italic underline strikethrough alignleft aligncenter alignright outdent indent blockquote removeformat subscript superscript bullist numlist link insertdatetime yfupimgs table fontsizeselect forecolor backcolor preview hr fullscreen']
export const plugins = ['lists fullscreen image insertdatetime link lists preview table yfupimgs hr']
export const options = {
  max_chars: 2,
  skin_url: 'vendors/tinymce/skins/ui/oxide',
  language_url: 'vendors/tinymce/langs/zh_CN.js',
  language: 'zh_CN',
  plugins: plugins,
  toolbar: toolbar,
  height: 450, //编辑器高度
  min_height: 400,
  browser_spellcheck: true, // 拼写检查
  branding: false, // 去水印
  elementpath: false, //禁用编辑器底部的状态栏
  statusbar: false, // 隐藏编辑器底部的状态栏
  paste_data_images: true, // 允许粘贴图像
  menubar: false, // 隐藏最上方menu
  fontsize_formats: '12pt 13pt 14pt 15pt 16pt 18pt 24pt 36pt'
}
