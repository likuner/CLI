<template>
  <div class="staff-item">
    <el-checkbox
      class="cbox"
      :value="selectedMemberIds.indexOf(source.staffId) > -1"
      :disabled="source.disabled"
      @click.native.prevent="staffCBoxClick"
    ></el-checkbox>
    <div class="staff-info">
      <div class="user-name o-ellipsis">{{source.name}}</div>
      <div class="phone-number o-ellipsis">{{source.mobile}}</div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    index: { // index of current item
      type: Number
    },
    source: { // here is: {uid: 'unique_1', text: 'abc'}
      type: Object,
      default() {
        return {}
      }
    },
    selectedMemberIds: {
      type: Array,
      default() {
        return []
      }
    }
  },
  methods: {
    staffCBoxClick() {
      let parent = this.$parent || this.$root
      let name = parent.$options.name

      while (parent && (!name || name !== 'range-org-staff-selector')) {
        parent = parent.$parent
        if (parent) {
          name = parent.$options.name
        }
      }
      if (parent) {
        const fun = parent.$emit
        fun.apply(parent, ['rangeStaffCBoxClick', this.source])
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.staff-item {
  box-sizing: border-box;
  width: 95%;
  display: flex;
  align-items: center;
  height: 41px;
  padding-left: 10px;
  border: 1px solid #e9e9e9;
  border-radius: 4px;
  overflow: hidden;
  margin-bottom: 10px;
  .staff-info {
    margin-left: 5px;
    overflow: hidden;
    .user-name {
      font-size: 14px;
    }
    .phone-number {
      font-size: 12px;
      color: rgba(0, 0, 0, 0.35);
    }
  }
}
.o-ellipsis {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
</style>
