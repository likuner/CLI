<template>
  <el-dialog :title="title" :visible="dialogVisible" :before-close="closeDialog" append-to-body>
    <div class="main-container">
      <div class="search-container">
        <el-input
          placeholder="请输入人员名称或手机号码"
          v-model="keyword"
          prefix-icon="el-icon-search"
          size="small"
          clearable
          :maxlength="20"
          @input="keywordInput()"
          v-if="options.selectMode !== 'Struct'"
        />
      </div>
      <div class="org-staff-container">
        <div class="org-list" v-loading="orgLoading">
          <template v-if="orgError">
            <div class="tree-load-fail" style>
              <div class="error-tip">
                <img :src="require('@/framework/assets/images/notfound.png')" />
                <p>网站连接异常或数据加载失败</p>
              </div>
              <el-button class="retry" size="small" @click="retryBtnClick">重试</el-button>
            </div>
          </template>
          <el-tree
            v-else
            ref="orgTree"
            class="org-tree"
            node-key="idKey"
            :props="props"
            :load="loadNode"
            empty-text
            lazy
            :default-checked-keys="defaultCheckedKeys"
            :default-expanded-keys="defaultExpandedKeys"
            :show-checkbox="['PersonAndStruct','Struct'].indexOf(options.selectMode) > -1"
            :check-on-click-node="false"
            :check-strictly="true"
            :expand-on-click-node="false"
            @node-click="resetCurrentStruct($event, false)"
            @check="structCheck"
          ></el-tree>
        </div>
        <!-- 第一次加载或者全部加载时显示loading -->
        <div
          class="staff-list"
          v-loading="(currentStructData.loadingText || currentStructData.currentStructMembers.length === 0) && currentStructData.memberLoading"
          :element-loading-text="currentStructData.loadingText"
          v-if="options.selectMode!=='Struct'"
        >
          <virtual-list
            class="virtual-list"
            v-if="currentStructData.currentStructMembers.length > 0"
            :data-key="'staffId'"
            :data-sources="currentStructData.currentStructMembers"
            :extraProps="{selectedMemberIds}"
            :data-component="itemComponent"
            :estimate-size="50"
            @tobottom="loadStructMembers"
          >
            <div slot="header" class="staff-item">
              <el-checkbox class="cbox" :value="false" disabled v-if="!currentStructData.allLoaded"></el-checkbox>
              <el-checkbox
                v-else
                class="cbox"
                v-model="allCBoxChecked"
                :disabled="checkBoxDisabled || allCBoxDisabled"
              ></el-checkbox>
              <div class="staff-info">
                <div class="user-name">全部</div>
              </div>
            </div>
            <div slot="footer" class="members-loading" v-if="currentStructData.memberLoading">
              <i class="el-icon-loading"></i>
              <span style="margin-left:5px;">加载中...</span>
            </div>
          </virtual-list>
          <template v-else>
            <div class="staff-empty">当前分支没有人员</div>
          </template>
          <el-alert
            v-if="currentStructData.currentStructMembers.length && !currentStructData.allLoaded && !currentStructData.memberLoading"
            title="加载全部"
            center
            type="success"
            class="all-staff-btn"
            :closable="false"
            @click.native="loadStructAllMembers"
          ></el-alert>
        </div>
      </div>
      <div
        class="search-result"
        v-show="keyword"
        v-loading="keywordSearchLoading && keywordSearchResult.length === 0"
      >
        <ul
          v-infinite-scroll="loadDataByKeyword"
          :infinite-scroll-disabled="keywordScrollDisabled"
          v-if="keywordSearchResult && keywordSearchResult.length > 0"
        >
          <li
            class="staff-item"
            v-for="(item) in keywordSearchResult"
            :label="item.name"
            :key="item.staffId"
          >
            <el-checkbox
              class="cbox"
              :value="selectedMemberIds.indexOf(item.staffId) > -1"
              :disabled="checkBoxDisabled"
              @click.native.prevent="staffCBoxClick(item)"
            ></el-checkbox>

            <div class="staff-info">
              <div class="user-name o-ellipsis">{{item.name}}</div>
            </div>
          </li>
          <div class="members-loading" v-if="keywordSearchLoading">
            <i class="el-icon-loading"></i>
            <span style="margin-left:5px;">加载中...</span>
          </div>
        </ul>
        <template v-else>
          <div class="no-search-result">未查询到符合条件的结果</div>
        </template>
      </div>
    </div>
    <div class="result-container">
      <div class="summary">
        <template v-if="['PersonAndStruct','Person'].indexOf(options.selectMode) > -1">
          已选人员 {{selectedMembers.length}} 个
          <span
            v-if="options.maxPerson > 0"
          >(最多 {{options.maxPerson}} 个)</span>
        </template>
      </div>
      <ul class="result-list">
        <li v-for="(struct,idx) in selectedStructs" :key="struct.id" @click="removeStruct(idx)">
          <span class="struct o-ellipsis">{{struct.name}}</span>
          <span class="el-icon-close unselect"></span>
        </li>
        <li
          v-for="(member,idx) in selectedMembers"
          :key="member.staffId"
          @click="removeMember(idx)"
        >
          <span class="name o-ellipsis">{{member.name}}</span>
          <span class="mobile-phone-number o-ellipsis">{{member.mobile}}</span>
          <span class="el-icon-close unselect"></span>
        </li>
      </ul>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button @click="closeDialog" class="ctrl-btn" size="medium">取 消</el-button>
      <el-button type="primary" @click="confirm" class="ctrl-btn" size="medium">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
import {
  fetchChildrenOpenOrgStructList,
  fetchOrgMemberList,
  fetchChildrenStructListByOrgStructList,
  fetchOrgMemberListByStaffIds,
  searchRangeStatffListByKeyword
} from '@/framework/service/org-service'
import { debounce } from '@/framework/utils/common'
import RangeStaffCheckboxItem from './range-staff-checkbox-item'
import { deepGet } from '@/framework/utils/common'
import VirtualList from 'vue-virtual-scroll-list'
export default {
  name: 'range-org-staff-selector',
  components: {
    [VirtualList.name]: VirtualList
  },
  props: {
    options: Object,
    params: Object
  },
  data() {
    return {
      itemComponent: RangeStaffCheckboxItem,
      dialogVisible: true,
      props: {
        label: 'name',
        children: 'zones',
        isLeaf: 'isLeaf'
      },
      keywordPageNo: 1,
      defaultCheckedKeys: [],
      defaultExpandedKeys: [],
      currentStructMembers: [],
      selectedStructs: [],
      selectedMembers: [],
      memberLoading: false,
      orgLoading: false,
      orgError: false,
      //关键字搜索的关键字
      keyword: '',
      //正在根据关键字查询数据
      keywordSearchLoading: false,
      //关键字查询结果
      keywordSearchResult: [],
      //关键字查询 没有更多数据
      keywordScrollNoMore: false,
      currentStructData: {
        structId: '',
        memberLoading: false,
        allLoaded: false,
        membersCount: 0,
        currentStructMembers: [],
        pageNo: 1,
        pageSize: 100,
        loadingText: '',
        currentRequest: null,
        error: false
      }
    }
  },
  computed: {
    title() {
      const idx = ['PersonAndStruct', 'Struct', 'Person'].indexOf(
        this.options.selectMode
      )
      return ['选择人员和部门', '选择部门', '选择人员'][idx] || '选择'
    },
    keywordScrollDisabled() {
      return this.keywordScrollNoMore || this.keywordSearchLoading
    },
    /**
     * 全部不可用
     */
    allCBoxDisabled() {
      return (
        this.options.maxPerson &&
        this.currentStructData.currentStructMembers &&
        this.currentStructData.currentStructMembers.filter(ele => {
          return this.selectedMemberIds.indexOf(ele.staffId) === -1
        }).length +
          this.selectedMembers.length >
          this.options.maxPerson
      )
    },
    checkBoxDisabled() {
      return (
        this.options.maxPerson &&
        this.selectedMembers.length >= this.options.maxPerson
      )
    },
    allCBoxChecked: {
      get: function() {
        let result = true
        for (const ele of this.currentStructData.currentStructMembers) {
          if (this.selectedMemberIds.indexOf(ele.staffId) === -1) {
            result = false
            break
          }
        }
        return result
      },
      set: function(newValue) {
        if (newValue) {
          //全选
          const selectedMemberIdSet = new Set(this.selectedMemberIds)
          this.currentStructData.currentStructMembers.forEach(ele => {
            if (!selectedMemberIdSet.has(ele.staffId)) {
              selectedMemberIdSet.add(ele.staffId)
              this.selectedMembers.push(ele)
            }
          })
        } else {
          //取消全选
          const selectedMembers = this.selectedMembers.filter(
            ele =>
              !this.currentStructData.currentStructMembers.some(
                item => item.staffId === ele.staffId
              )
          )
          this.selectedMembers = selectedMembers
        }
      }
    },
    selectedStructIds() {
      const selectedStructIds = []
      this.selectedStructs.forEach(ele => {
        this.options.rangeStructs.forEach(struct => {
          selectedStructIds.push(struct.id + '-' + ele.id)
        })
        if (this.rangeStructsIds.indexOf(ele.id) !== -1) {
          selectedStructIds.push(ele.id)
        }
      })
      return selectedStructIds
    },
    selectedMemberIds() {
      return this.selectedMembers.map(ele => {
        return ele.staffId
      })
    },
    selectedTagIds() {
      return this.selectedTags.map(ele => {
        return ele.tagId
      })
    },
    selectedStructNames() {
      return this.selectedStructs.map(ele => {
        return ele.name
      })
    },
    selectedMemberNames() {
      return this.selectedMembers.map(ele => {
        return ele.name
      })
    },
    selectedTagNames() {
      return this.selectedTags.map(ele => {
        return ele.tagName
      })
    },
    rangeStructsIds() {
      return this.options.rangeStructs.map(ele => {
        return ele.id
      })
    },
    rangePersonIds() {
      return this.options.rangeMembers.map(ele => {
        return ele.staffId
      })
    }
  },
  created() {
    const { selectedStructs, selectedMembers } = this.params
    this.selectedStructs = selectedStructs || []
    this.selectedMembers = selectedMembers || []
    this.options.rangeMembers = this.options.rangeMembers || []
    this.options.rangeStructs = this.options.rangeStructs || []
    this.defaultCheckedKeys = this.selectedStructIds
    this.$on('rangeStaffCBoxClick', this.staffCBoxClick)
  },
  methods: {
    /**
     * dialog关闭
     */
    closeDialog() {
      this.dialogVisible = false
      this.options.cancelCb()
    },
    confirm() {
      this.dialogVisible = false
      this.options.confrimCb({
        selectedStructs: this.selectedStructs,
        selectedStructNames: this.selectedStructNames,
        selectedMembers: this.selectedMembers,
        selectedMemberNames: this.selectedMemberNames
      })
    },
    loadNode(node, resolve) {
      let structId = ''
      if (node.level === 0) {
        this.orgLoading = true
      } else {
        structId = node.data.id
      }
      if (node.level === 0) {
        this.orgLoading = false
        const resolveData = [
          {
            id: 'root-master',
            idKey: 'root-master',
            isLeaf: !(this.options.rangeStructs.length > 0),
            level: 1,
            name: '可选范围',
            disabled: true
          }
        ]
        this.resetCurrentStruct(
          {
            id: 'root-master',
            membersCount: this.options.rangeMembers.length
          },
          true
        )
        resolve(resolveData)
        if (this.rangeStructsIds.length > 0) {
          this.defaultExpandedKeys = ['root-master']
        }
      } else if (node.data.id === 'root-master') {
        if (this.rangeStructsIds.length === 0) {
          this.orgLoading = false
          resolve([])
          return
        }
        fetchChildrenStructListByOrgStructList(this.rangeStructsIds)
          .then(res => {
            this.orgLoading = false
            if (res && res.errcode === 200) {
              const resData = res.data.filter(struct => {
                return struct.name !== null
              })
              resData.forEach(ele => {
                ele.idKey = ele.id
                ele.rootIdKey = ele.id
              })
              resolve(resData || [])
            } else {
              this.orgError = true
              this.orgLoading = false
            }
          })
          .catch(err => {
            console.error(err)
            this.orgError = true
            this.orgLoading = false
          })
      } else {
        fetchChildrenOpenOrgStructList(structId)
          .then(res => {
            this.orgLoading = false
            if (res && res.errcode === 200) {
              res.data.forEach(ele => {
                ele.rootIdKey = node.data.rootIdKey
                ele.idKey = ele.rootIdKey + '-' + ele.id
              })
              resolve(res.data || [])
            }
          })
          .catch(err => {
            console.error(err)
            this.orgError = true
            this.orgLoading = false
          })
      }
    },
    staffCBoxClick(staff) {
      if (this.checkBoxDisabled) return
      //存在 删除
      const idx = this.selectedMemberIds.indexOf(staff.staffId)
      if (idx > -1) {
        this.selectedMembers.splice(idx, 1)
      } else {
        this.selectedMembers.push(staff)
      }
    },
    structCheck(data) {
      if (this.selectedStructIds.indexOf(data.idKey) !== -1) {
        const currentNodes = []
        this.selectedStructs.forEach(ele => {
          if (ele.id !== data.id) {
            currentNodes.push(ele)
          }
        })
        this.selectedStructs = currentNodes
        this.$refs.orgTree.setCheckedKeys(this.selectedStructIds)
      } else {
        this.selectedStructs.push(data)
        this.$refs.orgTree.setCheckedKeys(this.selectedStructIds)
      }
    },
    removeStruct(idx) {
      this.selectedStructs.splice(idx, 1)
      //刷新树的选中
      this.$refs.orgTree.setCheckedKeys(this.selectedStructIds)
    },
    /**
     * 移除人的选中
     */
    removeMember(idx) {
      this.selectedMembers.splice(idx, 1)
    },
    /**
     * 组织树重新加载
     */
    retryBtnClick() {
      this.orgError = false
    },
    /**
     * 关键词输入查询
     */
    keywordInput: debounce(async function() {
      this.keywordPageNo = 1
      this.keywordSearchResult = []
      await this.loadDataByKeyword()
    }, 600),
    /**
     * 关键字查人
     */
    async loadDataByKeyword() {
      if (!this.keyword) return
      if (this.rangeStructsIds.length === 0) {
        this.keywordScrollNoMore = true
        return
      }
      try {
        this.keywordSearchLoading = true
        const res = await searchRangeStatffListByKeyword({
          keyword: this.keyword,
          pageNo: this.keywordPageNo,
          searchScope: this.rangeStructsIds
        })
        if (
          res.errcode === 200 &&
          res.data &&
          res.data.result &&
          res.data.result.length > 0
        ) {
          this.keywordSearchResult.push(...res.data.result)
          this.keywordPageNo++
        } else {
          this.keywordScrollNoMore = true
        }
      } catch (err) {
        console.err(err)
        this.keywordScrollNoMore = true
      } finally {
        this.keywordSearchLoading = false
      }
    },
    /**按照某个字段进行去重 */
    unique(arr, type) {
      const res = new Map()
      return arr.filter(a => !res.has(a[type]) && res.set(a[type], 1))
    },
    /**
     * 加载部门下人员
     */
    async loadStructMembers() {
      if (this.options.selectMode === 'Struct') return
      if (!this.currentStructData.structId) return
      if (this.currentStructData.allLoaded) return
      if (this.currentStructData.memberLoading) return
      this.currentStructData.memberLoading = true
      this.currentStructData.error = false
      const structId = this.currentStructData.structId
      if (structId === 'root-master') {
        if (this.rangePersonIds.length === 0) {
          this.currentStructData.memberLoading = false
          this.currentStructData.currentStructMembers = []
          this.currentStructData.allLoaded = true
          return
        }
        const res = await fetchOrgMemberListByStaffIds(this.rangePersonIds)
        if (structId !== this.currentStructData.structId) {
          return
        }
        this.currentStructData.memberLoading = false
        if (res && res.errcode === 200) {
          this.currentStructData.currentStructMembers = res.data
          this.currentStructData.allLoaded = true
        } else {
          this.currentStructData.error = true
          this.$message.error('数据加载失败')
        }
        return
      }
      const res = await fetchOrgMemberList(
        this.currentStructData.structId,
        this.currentStructData.pageNo,
        this.currentStructData.pageSize
      )
      if (structId !== this.currentStructData.structId) {
        return
      }
      this.currentStructData.memberLoading = false
      if (res && res.errcode === 200) {
        this.currentStructData.currentStructMembers.push(
          ...deepGet(res, 'data.result', [])
        )
        this.currentStructData.pageNo++
        this.currentStructData.allLoaded = !deepGet(res, 'data.hasMore', true)
      } else {
        this.currentStructData.error = true
        this.$message.error('数据加载失败')
      }
    },
    /**
     * 加载部门下所有人员
     */
    async loadStructAllMembers() {
      this.currentStructData.error = false
      const structId = this.currentStructData.structId
      while (
        structId === this.currentStructData.structId &&
        !this.currentStructData.allLoaded &&
        this.dialogVisible
      ) {
        this.currentStructData.loadingText = `已加载${this.currentStructData.currentStructMembers.length}人`
        await this.loadStructMembers()
        if (this.currentStructData.error) {
          this.currentStructData.loadingText = ''
          break
        }
      }
    },
    /**
     * 重置当前部门
     */
    resetCurrentStruct(structInfo) {
      if (structInfo.id === this.currentStructData.structId) {
        return
      }
      this.currentStructData.structId = structInfo.id
      this.currentStructData.allLoaded = false
      this.currentStructData.membersCount = structInfo.membersCount
      this.currentStructData.currentStructMembers = []
      this.currentStructData.pageNo = 1
      this.currentStructData.loadingText = ''
      this.currentStructData.memberLoading = false
      this.loadStructMembers()
    }
  }
}
</script>

<style lang="scss" scoped>
* {
  box-sizing: border-box;
}
.main-container {
  float: left;
  height: 415px;
  width: 66%;
  padding: 0 10px;
  border-right: 1px solid #e9e9e9;
  display: flex;
  flex-direction: column;
}
.search-container {
  display: flex;
  .filter {
    width: 80px;
    height: 34px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    margin-left: 5px;
    border-radius: 4px;
    &:hover {
      background-color: #f0f0f0;
    }
    img {
      width: 16px;
      height: 16px;
    }
  }
}
.result-container {
  float: left;
  height: 415px;
  width: 34%;
  padding: 0 10px;
  display: flex;
  flex-direction: column;
}
.org-staff-container {
  margin-top: 10px;
  overflow: hidden;
  display: flex;
  flex: 1;
}
.org-list {
  flex: 2 1 0;
  overflow: auto;
  position: relative;
}
.staff-list {
  position: relative;
  flex: 1 1 0;
  padding-left: 10px;
  border-left: 1px solid #e9e9e9;
  .virtual-list {
    position: absolute;
    height: 100%;
    width: 100%;
    overflow: auto;
  }
}
.org-tree {
  position: absolute;
  min-width: 100%;
  /deep/ .el-tree-node__label {
    padding-right: 10px;
  }
}
.all-staff-btn {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  cursor: pointer;
  text-align: center;
  z-index: 99;
}
.staff-item {
  box-sizing: border-box;
  width: 95%;
  display: flex;
  align-items: center;
  height: 41px;
  padding-left: 10px;
  border: 1px solid #e9e9e9;
  border-radius: 4px;
  overflow: hidden;
  margin-bottom: 10px;
  .staff-info {
    margin-left: 5px;
    overflow: hidden;
    .user-name {
      font-size: 14px;
    }
    .phone-number {
      font-size: 12px;
      color: rgba(0, 0, 0, 0.35);
    }
  }
}
.staff-empty {
  text-align: center;
  margin-top: 50px;
  color: rgba(0, 0, 0, 0.45);
}
.summary {
  margin: 5px 0 15px 0;
}
.result-list {
  height: 350px;
  overflow-y: auto;
  li {
    height: 35px;
    border: 1px solid #e9e9e9;
    border-radius: 4px;
    padding: 0 10px;
    margin-bottom: 5px;
    overflow: hidden;
    .name {
      display: inline-block;
      width: 35%;
      font-size: 14px;
      line-height: 35px;
    }
    .struct {
      display: inline-block;
      width: 85%;
      font-size: 14px;
      line-height: 35px;
    }
    .unselect {
      display: inline-block;
      float: right;
      line-height: 35px;
      cursor: pointer;
    }
    .mobile-phone-number {
      display: inline-block;
      width: 50%;
      font-size: 12px;
      line-height: 35px;
    }
  }
}
.tree-load-fail {
  text-align: center;
  .error-tip {
    padding: 20px 20px 10px 20px;
    text-align: center;
    img {
      width: 70%;
    }
  }
  .retry {
    width: 80px;
    margin-top: 10px;
  }
}
/deep/ .is-current > .el-tree-node__content {
  background-color: #f5f7fa;
}
.search-result {
  height: 380px;
  margin-top: 7px;
  overflow: auto;
}
.no-search-result {
  text-align: center;
  margin-top: 50px;
  font-size: 14px;
  color: rgba(0, 0, 0, 0.45);
}
.o-ellipsis {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
/deep/ .el-dialog {
  width: 640px;
  .el-dialog__body {
    overflow: hidden;
  }
  .el-dialog__footer {
    text-align: center;
    .ctrl-btn {
      width: 100px;
    }
  }
}
.members-loading {
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #909399;
}
</style>
