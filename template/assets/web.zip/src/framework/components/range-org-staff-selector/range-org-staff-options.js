export default {
  selectMode: 'PersonAndStruct', //PersonAndStruct、Struct、Person
  maxPerson: null,
  rangeMembers: [],
  rangeStructs: []
}
