<template>
  <div class="coordinate-selector" v-loading="loading">
    <el-input class="search-input" v-model="searchText" placeholder="请输入地点名称" v-if="!disabled"></el-input>
    <div ref="mapContainer" class="map-container">
      <el-button v-if="initError" @click="initMap" class="retry">重新加载</el-button>
    </div>
  </div>
</template>
<script>
import { loadScript } from '@/framework/utils/common'
const GDMAP_URL = `https://webapi.amap.com/maps?v=1.4.15&key=2afbd3d10d96ad4e1987e19eaa08b733`
const DEFAULT_COORDINATE = [116.397428, 39.90923]
export default {
  name: 'coordinate-selector',
  data() {
    return {
      loading: false,
      searchText: '',
      map: null,
      geocoder: null,
      initError: false
    }
  },
  props: {
    value: {
      type: Array
    },
    // 初始化放大比例
    zoom: {
      type: Number,
      default: 11,
      validator: function(value) {
        if (value < 3 || value > 18) {
          console.warn('zoom的取值必须在3-18之间')
          return false
        }
        return true
      }
    },
    disabled: Boolean
  },
  created() {
    this.initMap()
  },
  watch: {
    value: {
      handler(val) {
        if (val && val.length > 0 && this.marker) {
          this.marker.setPosition(val)
        }
      },
      immediate: true
    },
    disabled: {
      handler(val) {
        if (this.map) {
          this.map.setStatus({
            dragEnable: !val,
            zoomEnable: !val
          })
        }
      }
    }
  },
  methods: {
    async initMap() {
      this.loading = true
      this.initError = false
      if (await loadScript('amap', GDMAP_URL)) {
        const AMap = window.AMap
        const params = {
          center:
            this.value && this.value.length > 0
              ? this.value
              : DEFAULT_COORDINATE,
          zoom: this.zoom,
          dragEnable: !this.disabled,
          zoomEnable: !this.disabled
        }
        this.map = new AMap.Map(this.$refs.mapContainer, params)
        AMap.service(['AMap.Autocomplete', 'AMap.Geocoder'], () => {
          //地点搜索
          const auto = new AMap.Autocomplete({
            input: this.$el.querySelector('input')
          })
          AMap.event.addListener(auto, 'select', e => this.select(e))

          // 经纬度换地点信息
          this.geocoder = new window.AMap.Geocoder({
            // city 指定进行编码查询的城市，支持传入城市名、adcode 和 citycode
            city: '全国',
            radius: 1000 //范围，默认：500
          })
        })

        // 注册地图点击事件
        this.map.on('click', e => this.mapClick(e))
        this.marker = new AMap.Marker({ map: this.map, bubble: true })
        if (this.disabled || !this.value || this.value.length < 2) {
          this.$emit('input', [...DEFAULT_COORDINATE])
        }
      } else {
        this.initError = true
      }
      this.loading = false
    },
    mapClick(event) {
      if (this.disabled) return
      this.$emit('input', [event.lnglat.getLng(), event.lnglat.getLat()])
    },
    getAddress(lnglat) {
      if (!this.geocoder) return ''
      return new Promise(resolve => {
        this.geocoder.getAddress(lnglat, (status, result) => {
          if (status === 'complete' && result.regeocode) {
            resolve(result.regeocode.formattedAddress)
          } else {
            resolve()
          }
        })
        setTimeout(resolve, 3500)
      })
    },
    select(e) {
      if (e.poi && e.poi.location) {
        this.map.setCenter(e.poi.location)
        this.marker.setPosition(e.poi.location)
        this.$emit('input', [e.poi.location.lng, e.poi.location.lat])
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.coordinate-selector {
  position: relative;
  display: flex;
  align-items: stretch;
  min-height: 300px;
}
.map-container {
  display: flex;
  align-items: center;
  justify-content: center;
  flex: 1;
}
.search-input {
  position: absolute;
  z-index: 99;
  background: transparent;
  top: 20px;
  left: 20px;
  width: 30%;
}
</style>
