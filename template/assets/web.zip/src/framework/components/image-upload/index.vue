<template>
  <ul class="image-upload">
    <draggable handle="#dragHandle" class="image-list" v-model="list" :force-fallback="true" @end="onEnd">
      <li :style="imageStyle" v-for="(image, index) of list" :key="index">
        <div class="image-item">
          <el-image
            class="image-container"
            :style="{opacity: image.status === 'uploaded' ? 1 : 0.5}"
            v-if="getImageSrc(image)"
            :src="getImageSrc(image)"
            :fit="fit"
          >
          </el-image>
          <!-- {{getImageSrc(image)}} -->
          <!-- 编辑状态或可以预览 展示遮罩 -->
          <div class="mask" v-show="canPreview || !disabled">
            <div style="width: 60px">
              <i class="el-icon-full-screen" @click="showPreview(index)" v-if="canPreview"></i>
              <template v-if="!disabled">
                <i id="dragHandle" class="el-icon-rank"></i>
                <i class="el-icon-upload2" @click="replaceClick(index)"></i>
                <i class="el-icon-delete" @click="deleteClick(index)"></i>
              </template>
            </div>
          </div>
          <div :class="['upload-status', `upload-status-${image.status}`]" v-if="!disabled">
            <i v-if="image.status === 'uploaded'" class="el-icon-check"></i>
            <i v-else-if="image.status === 'error'" class="el-icon-close"></i>
            <i v-else-if="image.status === 'pending'" class="el-icon-upload2"></i>
          </div>
        </div>
        <div class="footer">
          <slot :name="'footer-' + index" class="footer"></slot>
        </div>
      </li>
      <li :style="imageStyle" class="image-add" @click="addClick" v-if="canAdd && !disabled">
        <i class="el-icon-plus" style="font-size: 22px;"></i>
        <span v-if="text">{{text}}</span>
      </li>
    </draggable>
  </ul>
</template>

<script>
import {
  getResourceInfoById,
  uploadFileToServer,
  getResourceUrl
} from '@/framework/service/file-service'
import { openImageChoose, resizeImage } from '@/framework/utils/file'
import { preview } from '@/framework/components/image-viewer/image-viewer'
import Upload from '@/framework/minix/upload'
import draggable from 'vuedraggable'
import { deepGet } from '@/framework/utils/common'
export default {
  name: 'image-upload',
  data: function() {
    return {
      resizeImageQueue: [],
      running: false
    }
  },
  props: {
    width: {
      type: String,
      default: '120px'
    },
    height: {
      type: String,
      default: '120px'
    },
    margin: {
      type: String,
      default: '6px'
    },
    canPreview: {
      type: Boolean,
      default: true
    },
    initResourceIds: {
      type: Array
    },
    fit: {
      type: String,
      default: 'cover'
    },
    text: {
      type: String,
      default: ''
    }
  },
  components: { draggable },
  mixins: [Upload],
  computed: {
    /**
     * 图片默认样式
     */
    imageStyle() {
      return {
        width: this.width,
        height: this.height,
        margin: this.margin
      }
    },
    /**
     * 图片列表src数组
     */
    previewList() {
      return this.list.map(image => {
        const resourceId = deepGet(image, 'resource.resourceId')
        return image.orginSrc || getResourceUrl(resourceId) || image.localSrc
      })
    }
  },
  created() {
    this.initImageList()
  },
  methods: {
    /**
     * 初始化imageList
     */
    initImageList() {
      this.list = []
      if (this.initResourceIds) {
        this.initResourceIds.forEach((resourceId, index) => {
          const image = {
            order: index,
            status: 'uploaded',
            resource: {
              resourceId
            }
          }
          getResourceInfoById(resourceId).then(resourceInfo => {
            if (resourceInfo) {
              this.$set(image, 'resource', resourceInfo)
            }
          })
          this.list.push(image)
        })
      }
    },
    async addClick(fileArr) {
      let oFileList
      if (Array.isArray(fileArr)) {
        oFileList = fileArr
      } else {
        oFileList = await openImageChoose(true)
      }
      const exceedMaxSizeFiles = []
      const list = []
      for (const oFile of oFileList) {
        if (this.maxNum && this.list.length + list.length >= this.maxNum) {
          break
        }
        if (this.maxSize > 0 && oFile.size > this.maxSize) {
          exceedMaxSizeFiles.push(oFile)
          continue
        }
        const orginSrc = URL.createObjectURL(oFile)
        const image = {
          order: this.count,
          status: 'pending',
          localSrc: '',
          orginSrc,
          resource: {
            fileName: oFile.fileName,
            size: oFile.size
          },
          uploadProgress: 0,
          uploadTaskId: ''
        }
        this.fillLocalSrc(orginSrc).then(res => {
          image.localSrc = res
        })

        // 图片上传到服务器
        uploadFileToServer(oFile, '', function(uploadProgress, uploadTaskId) {
          // 上传进度
          image.uploadProgress = uploadProgress
          image.uploadTaskId = uploadTaskId
        }).then(resourceInfo => {
          if (resourceInfo) {
            image.status = 'uploaded'
            this.$set(image, 'resource', resourceInfo)
          } else {
            image.status = 'error'
          }
          this.triggerUploadChange(image)
        })
        list.push(image)
        this.triggerUploadChange(image)
      }
      this.list = this.list.concat(list)
      if (exceedMaxSizeFiles.length > 0) {
        this.$message.error(this.maxSizeErrorTip)
        this.triggerExceedMaxSize(exceedMaxSizeFiles)
      }
    },
    async replaceClick(idx) {
      const oFile = await openImageChoose(false)
      if (this.maxSize > 0 && oFile.size > this.maxSize) {
        this.$message.error(this.maxSizeErrorTip)
        this.triggerExceedMaxSize([oFile])
        return
      }
      const orginSrc = URL.createObjectURL(oFile)
      const image = {
        order: this.count,
        status: 'pending',
        localSrc: '',
        orginSrc,
        resource: {
          fileName: oFile.fileName,
          size: oFile.size
        },
        uploadProgress: 0,
        uploadTaskId: ''
      }
      this.fillLocalSrc(orginSrc).then(res => {
        image.localSrc = res
      })
      // 图片上传到服务器
      uploadFileToServer(oFile, '', function(uploadProgress, uploadTaskId) {
        // 上传进度
        image.uploadProgress = uploadProgress
        image.uploadTaskId = uploadTaskId
      }).then(resourceInfo => {
        if (resourceInfo) {
          image.status = 'uploaded'
          this.$set(image, 'resource', resourceInfo)
        } else {
          image.status = 'error'
        }
        this.triggerUploadChange(image)
      })
      this.$set(this.list, idx, image)
      this.triggerUploadChange(image)
    },
    /**
     * 获取图片src
     */
    getImageSrc(image) {
      if (!image) return ''
      if (image.localSrc) return image.localSrc
      const resource = image.resource
      if (!resource || !resource.resourceId) return ''
      return getResourceUrl(`${resource.resourceId}~200`)
    },
    fillLocalSrc(src) {
      return new Promise(resolve => {
        this.resizeImageQueue.push({ resolve, src })
        this.runNext()
      })
    },
    async runNext() {
      if (!this.running && this.resizeImageQueue.length) {
        const { resolve, src } = this.resizeImageQueue.shift()
        this.running = true
        const res = await resizeImage(src, 200)
        this.running = false
        resolve(res)
        this.runNext()
      }
    },
    showPreview(idx) {
      preview(this.previewList, idx)
    },
    onEnd(event) {
      if (event.newIndex === event.oldIndex) return
      this.triggerUploadChange(this.list[event.oldIndex])
    }
  }
}
</script>

<style lang="scss" scoped>
.image-upload {
  display: flex;
  flex-wrap: wrap;
}
.image-list {
  display: flex;
  flex-wrap: wrap;
}
ul {
  li {
    display: flex;
    flex-direction: column;
  }
}
.image-item {
  position: relative;
  border-radius: 4px;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  flex: 1;
  .image-container{
    height: 100%;
    width: 100%;
    position: absolute;
    z-index: 1;
  }
  .mask {
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 9;
    cursor: default;
    text-align: center;
    color: #fff;
    opacity: 0;
    font-size: 20px;
    background-color: rgba(0, 0, 0, 0.5);
    transition: opacity 0.3s;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-wrap: wrap;
    i {
      margin: 5px;
      cursor: pointer;
    }
  }
  &:hover {
    .mask {
      opacity: 1;
    }
  }
  .footer:hover + .mask {
    opacity: 0;
  }
  .upload-status {
    position: absolute;
    right: -17px;
    top: -7px;
    width: 46px;
    height: 26px;
    text-align: center;
    transform: rotate(45deg);
    z-index: 6;
    i {
      font-size: 12px;
      margin-top: 12px;
      transform: rotate(-45deg);
      color: #fff;
    }
  }
  .upload-status-uploaded {
    background: #409eff;
  }
  .upload-status-error {
    background: #f56c6c;
  }
  .upload-status-pending {
    background: #909399;
  }
}
.image-add {
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1px dashed #c0ccda;
  border-radius: 4px;
  cursor: pointer;
  flex-direction: column;
  color: #999999;
  padding: 10px;
  text-align: center;
  box-sizing: border-box;
  span {
    margin-top: 6px;
  }
}
.image-add:hover {
  border-color: #409eff;
}
</style>
