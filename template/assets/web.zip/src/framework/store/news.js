/**
 * 消息
 */
const state = {
  newsNum: -1,
  drawerVisible: false
}

const mutations = {
  SET_NEWS_NUM: (state, num) => {
    state.newsNum = num
  },
  SHOW_DRAWER: (state) => {
    state.drawerVisible = true
  },
  HIDDEN_DRAWER: (state) => {
    state.drawerVisible = false
  }
}

export const newsGetter = {
  newsNum: state => state.news.newsNum,
  drawerVisible: state => state.news.drawerVisible
}

export default {
  namespaced: true,
  state,
  mutations
}

