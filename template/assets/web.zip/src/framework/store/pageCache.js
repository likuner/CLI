const state = {
  pages: []
}

const mutations = {
  ADD_PAGES: (state, pageNameList) => {
    if (!Array.isArray(pageNameList)) {
      pageNameList = [pageNameList]
    }
    pageNameList.forEach(pageName => {
      const idx = state.pages.indexOf(pageName)
      if (idx === -1) {
        state.pages.push(pageName)
      }
    })
  },

  REMOVE_PAGES: (state, pageNameList) => {
    if (!Array.isArray(pageNameList)) {
      pageNameList = [pageNameList]
    }
    pageNameList.forEach(pageName => {
      const idx = state.pages.indexOf(pageName)
      if (idx > -1) {
        state.pages.splice(idx)
      }
    })
  },
  CLEAR: (state) => {
    state.pages = []
  }
}

export const pageCacheGetters = {
  cachedPages: state => state.pageCache.pages
}

export default {
  namespaced: true,
  state,
  mutations
}

