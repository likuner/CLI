import pageCache, { pageCacheGetters } from './pageCache'
import user, { userGetters } from './user'
import routesCache, { routesGetters } from './routesCache'
import news, { newsGetter } from './news'
import settings, { settingsGetter } from './settings'
import createPersistedState from 'vuex-persistedstate'
import { getAppId } from '@/framework/utils/common'

export const modules = {
  pageCache,
  user,
  routesCache,
  news,
  settings
}
export const getters = {
  ...userGetters,
  ...pageCacheGetters,
  ...routesGetters,
  ...newsGetter,
  ...settingsGetter
}
export function getPlugins(paths = []) {
  return createPersistedState(
    {
      key: `vuex@${getAppId()}`,
      paths: [
        'user.token',
        'user.currentRole',
        'user.staffId',
        'user.userName',
        'user.lisence',
        'user.isLisenceAdmin',
        ...paths
      ],
      storage: window.sessionStorage
    }
  )
}
