import { getRoleList, roleCheck } from '@/api/user'
import { login, logout } from '@/framework/service/user-service'
import { getUserInfo } from '@/framework/service/user-service'
import router, { resetRouter } from '@/router'
import { report } from '@/framework/service/track-service'

const resetState = () => {
  return {
    token: '',
    staffId: '',
    userName: '',
    userInfo: null,
    roleList: [],
    currentRole: null,
    lisence: null,
    isLisenceAdmin: null,
    isRoleListLoading: false
  }
}

const state = resetState()

const mutations = {
  RESET_STATE: (state) => {
    Object.assign(state, resetState())
  },
  SET_TOKEN: (state, token) => {
    state.token = token
  },
  SET_STAFF_ID: (state, staffId) => {
    state.staffId = staffId
  },
  SET_USERNAME: (state, userName) => {
    state.userName = userName
  },
  SET_USERINFO: (state, userinfo) => {
    state.userInfo = userinfo
  },
  SET_ROLE_LSIT: (state, list) => {
    state.roleList = list || []
  },
  SET_CURRENT_ROLE: (state, role) => {
    state.currentRole = role
  },
  SET_LISENCE: (state, lisence) => {
    state.lisence = lisence
  },
  SET_IS_LISENCE_ADMIN: (state, isLisenceAdmin) => {
    state.isLisenceAdmin = isLisenceAdmin
  },
  SET_IS_ROLE_LIST_LOADING: (state, isRoleListLoading) => {
    state.isRoleListLoading = isRoleListLoading
  }
}

const actions = {
  // 用户登录
  async login({ commit }) {
    const result = await login()
    const data = result.data || {}
    // 登录失败
    if (!(result.errcode === 200 && data)) { return false }
    // 登录成功 保存数据
    commit('SET_TOKEN', data.token)
    commit('SET_STAFF_ID', data.staffId)
    commit('SET_USERNAME', data.name)
    commit('SET_IS_LISENCE_ADMIN', !!data.isAdmin)
    commit('SET_LISENCE', data.licenseCheckInfo || {})
    // 记录行为日志
    report({ 'actionName': 'login', 'dataSource': 'framework', 'taskType': 'user-login' })
    return !!data.token
  },
  // 刷新token
  async refreshToken({ dispatch, commit, state }) {
    const result = await login()
    const data = result.data || {}
    // 登录失败
    if (!(result.errcode === 200 && data)) { return false }
    // 登录成功 保存数据
    commit('SET_TOKEN', data.token)
    commit('SET_STAFF_ID', data.staffId)
    commit('SET_USERNAME', data.name)
    commit('SET_IS_LISENCE_ADMIN', !!data.isAdmin)
    commit('SET_LISENCE', data.licenseCheckInfo || {})
    // 当前角色存在->重新绑定角色信息
    console.log('refreshToken')
    if (state.currentRole && !await dispatch('setCurrentRole', state.currentRole)) {
      // 切换身份失败
      router.replace({ path: '/error/500', query: { errmsg: '切换权限失败' }})
      return false
    }
    // 记录行为日志
    report({ 'actionName': 'login', 'dataSource': 'framework', 'taskType': 'user-refresh-token' })
    return !!data.token
  },
  //获取权限列表
  async getRoleList({ commit }) {
    commit('SET_IS_ROLE_LIST_LOADING', true)
    const res = await getRoleList()
    commit('SET_IS_ROLE_LIST_LOADING', false)
    if (res.errcode === 200) {
      commit('SET_ROLE_LSIT', res.data)
      return res.data
    }
    return null
  },
  // 刷新权限列表
  async refreshRoleList({ commit }) {
    commit('SET_IS_ROLE_LIST_LOADING', true)
    const res = await getRoleList()
    commit('SET_IS_ROLE_LIST_LOADING', false)
    if (res.errcode === 200) {
      commit('SET_ROLE_LSIT', res.data)
      return res.data
    }
    return null
  },
  // 获取用户信息
  async getUserInfo({ commit, state }, forceRefresh) {
    if (!forceRefresh && state.userInfo) {
      return state.userInfo
    }
    //获取用户信息
    const res = await getUserInfo(forceRefresh)
    if (res.errcode === 200) {
      commit('SET_USERINFO', res.data)
      return res.data
    }
    return null
  },

  // 退出登录
  async logout({ commit, state }) {
    const res = await logout(state.token)
    if (res.errcode === 200) {
      commit('RESET_STATE')
      return true
    }
    return false
  },

  resetToken({ commit }) {
    commit('RESET_STATE')
  },
  setRoleList({ commit }, list) {
    commit('SET_ROLE_LSIT', list)
  },
  setCurrentRole({ commit }, role) {
    return new Promise(resolve => {
      if (!role) {
        resolve(null)
        return
      }
      roleCheck(role).then(async result => {
        if (result.errcode === 200) {
          const currentRole = Object.assign({}, role, result.data)
          commit('SET_CURRENT_ROLE', currentRole)
          await resetRouter(currentRole)
          setTimeout(() => { resolve(currentRole) }, 0)
        } else {
          resolve(null)
        }
      })
    })
  }
}

export const userGetters = {
  token: state => state.user.token,
  roleList: state => state.user.roleList,
  roleGroupList: state => getRoleGroupList(state.user.roleList),
  currentRole: state => state.user.currentRole,
  userInfo: state => state.user.userInfo,
  userName: state => state.user.userName,
  staffId: state => state.user.staffId,
  domain: state => (state.user.staffId || '').split('-')[0],
  lisence: state => state.user.lisence,
  isLisenceAdmin: state => state.user.isLisenceAdmin,
  isRoleListLoading: state => state.user.isRoleListLoading
}

function getRoleGroupList(roleList) {
  const res = []
  const idxMap = new Map()
  const noGroupArr = { roleList: [] }
  for (const role of roleList) {
    const groupName = role.groupName
    if (!groupName) {
      noGroupArr.roleList.push(role)
      continue
    }
    const idx = idxMap.get(groupName)
    if (idx > -1) {
      res[idx].roleList.push(role)
    } else if (groupName) {
      idxMap.set(groupName, res.length)
      res[res.length] = { groupName, roleList: [role] }
    }
  }
  if (noGroupArr.roleList.length > 0) {
    res.unshift(noGroupArr)
  }
  return res
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}

