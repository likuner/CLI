/**
 * APP 相关全局设置
 */
const state = {
  appName: process.env.VUE_APP_NAME || ''
}

const mutations = {
  SET_APP_NAME: (state, appName) => {
    state.appName = appName || process.env.VUE_APP_NAME
  }
}

export const settingsGetter = {
  appName: state => state.settings.appName
}

export default {
  namespaced: true,
  state,
  mutations
}

