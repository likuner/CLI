/**
 * 全局路由缓存 为解决动态路由不在options显示的问题
 */
const state = {
  routes: []
}

const mutations = {
  SET_ROUTES: (state, routes) => {
    state.routes = routes
  }
}

export const routesGetters = {
  routes: state => state.routesCache.routes
}

export default {
  namespaced: true,
  state,
  mutations
}
