import Vue from 'vue'
import './styles/reset.scss'
import LxBreadcrumb from './layout/lx-breadcrumb'
import LxJssdkPlugin from './plugins/lx-jssdk'
import fliterPlugin from './plugins/filter'

Vue.use(fliterPlugin)
Vue.use(LxJssdkPlugin)
Vue.component(LxBreadcrumb.name, LxBreadcrumb)
