import screenfull from 'screenfull'

//全屏是否可用
export const isEnabled = screenfull.isEnabled
//是否是全屏
export const isFullscreen = screenfull.isFullscreen

/**
 * 全屏、取消全屏切换
 */
export function toggle() {
  if (screenfull.isEnabled) {
    screenfull.toggle()
  } else {
    console.warn('当前浏览器不支持全屏')
  }
  return isFullscreen
}

export default screenfull
