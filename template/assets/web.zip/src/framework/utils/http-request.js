import axios from 'axios'
import store from '@/store'
import { getAppBaseApi, guid } from '@/framework/utils/common'
import router from '@/router'
import { inLanxin } from '../utils/dev'

// 默认的请求头
// axios.defaults.timeout = 15000

//基础路径
axios.defaults.baseURL = getAppBaseApi()

const Axios = axios.create()

//请求默认添加请求头
Axios.interceptors.request.use(
  config => {
    if (store.getters.token) {
      config.headers['x-access-token'] = store.getters.token
    }
    const id = `w-${guid()}`
    config.headers['x-lanxin-request-rid'] = id
    // 过期，2.0.1之后版本无效，之后代码会删除
    config.headers['app-trace-id'] = id
    return config
  },
  error => {
    return Promise.reject(error)
  }
)

Axios.interceptors.response.use(
  response => {
    return [200, 304].indexOf(response.status) > -1 ? Promise.resolve(response) : Promise.reject(response)
  },
  error => {
    console.error('interceptors-response', error)
    return Promise.reject(error)
  }
)

/**
 *
 * @param {*} method 请求方式
 * @param {*} url 请求url 相对路径，相对于baseurl
 * @param {*} data
 */
export async function baseRequest(method, url, data) {
  process.env.NODE_ENV && console.log('请求调试', method, url, data)
  const httpDefaultOpts = { method, url }
  data = data || {}
  if (method.toLowerCase() === 'post') {
    httpDefaultOpts.data = data
  } else {
    data.timeStamp = Date.now()
    httpDefaultOpts.params = data
  }
  try {
    const result = await Axios(httpDefaultOpts)
    return result.data
  } catch (e) {
    //请求异常
    console.error('httpService', e)
    if (e && e.response && e.response.status === 401) {
      return { errcode: 401, errmsg: '登录已过期', data: null }
    } else {
      return { errcode: 500, errmsg: '请求发生异常', data: null }
    }
  }
}

const httpRequest = async(method, url, data) => {
  const result = await baseRequest(method, url, data)
  if (result.errcode !== 401) {
    return result
  }
  // 在蓝信宿主内，重新登录
  if (!inLanxin) {
    // 不在蓝信宿主内->跳转认证失败页面
    return router.replace({ path: '/error/500', query: { errmsg: '用户认证失败' }})
  }
  // 重新登录失败->跳转认证失败页面
  if (!await store.dispatch('user/refreshToken')) {
    return router.replace({ path: '/error/500', query: { errmsg: '用户认证失败' }})
  }
  // 重新登录成功->重新发起请求
  return baseRequest(method, url, data)
}

export default httpRequest
