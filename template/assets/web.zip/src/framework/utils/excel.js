import * as XLSX from 'xlsx'
import { openFileChoose } from './file'
const DEFAULT_IMPORT_OPTIONS = {
  header: 1,
  sheetNum: 0
}

async function XLS2Data(xlsFile) {
  return new Promise((resolve) => {
    const reader = new FileReader()
    reader.onload = function(e) {
      const data = e.target.result
      const wb = XLSX.read(data, { type: 'binary' })
      resolve(wb)
    }
    reader.readAsBinaryString(xlsFile)
  })
}
/**
 * 简单的excel导入
 * 不包含合并单元格，默认获取第一个sheet数据
 * options.header
 * options.sheetNum number 解析第几个sheet页面
 */
export async function simpleExcelImport(options) {
  if (options) {
    options = Object.assign({}, DEFAULT_IMPORT_OPTIONS, options)
  } else {
    options = Object.assign({}, DEFAULT_IMPORT_OPTIONS)
  }
  const file = await openFileChoose()
  if (file) {
    //获取sheet对象
    const wb = await XLS2Data(file)
    //读取第一个sheet页面
    const wsname = wb.SheetNames[options.sheetNum]
    const ws = wb.Sheets[wsname]
    //将worksheet对象解析为数据.
    return {
      orginFile: file,
      data: XLSX.utils.sheet_to_json(ws, { header: options.header })
    }
  }
}

const DEFAULT_EXPORT_OPTIONS = {
  fileName: Date.now(),
  sheetName: 'sheet1'
}
/**
 * 简单的excel导出
 * options.fileName 导出excel名称 默认是当前时间戳
 * options.sheetName 导出的sheet名称 默认是sheet1
 * options.wscols 每列的宽度 例如 [{wpx:200}, {wpx:100},{wpx:10}]
 * options.merges 合并单元格参数 例如 [
    { s: { r: 0, c: 0 }, e: { r: 0, c: 2 }}
  ]
 */
export async function simpleExcelExport(arr, options) {
  if (options) {
    options = Object.assign({}, DEFAULT_EXPORT_OPTIONS, options)
  } else {
    options = Object.assign({}, DEFAULT_EXPORT_OPTIONS)
  }
  const wb = XLSX.utils.book_new()
  const ws = XLSX.utils.aoa_to_sheet(arr)
  if (options.wscols) {
    ws['!cols'] = options.wscols
  }
  if (options.merges) ws['!merges'] = options.merges

  XLSX.utils.book_append_sheet(wb, ws, options.sheetName)
  /* 保存文件 */
  XLSX.writeFile(wb, `${options.fileName}.xlsx`)
}
