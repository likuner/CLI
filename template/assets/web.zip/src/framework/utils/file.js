import JSZipUtils from 'jszip-utils'
import { saveAs } from 'file-saver'
import JSZip from 'jszip'
// import Md5Worker from 'worker-loader!@/framework/workers/md5.worker'
import { getResourceUrl } from '@/framework/service/file-service'
import SparkMD5 from 'spark-md5'
/**
 * 打开文件选择对话框
 * args.accept 文件类型
 * args.multiple 是否多选 默认单选 值“multiple”为多选
 * args.maxCount 最多可选 >!的数量有效，默认不限制选择数量
 */
export function openFileChoose(multiple, accept, maxCount) {
  return new Promise((resolve) => {
    const ele = document.createElement('input')
    ele.type = 'file'
    ele.style.display = 'none'
    if (accept) {
      ele.accept = accept
    }
    if (multiple) {
      ele.multiple = 'multiple'
    }
    let count = 0
    if (maxCount > 0) {
      count = maxCount
    }

    document.body.appendChild(ele)
    ele.onchange = () => {
      let files = Array.from(ele.files)
      if (count && files.length > count) {
        files = files.slice(0, count)
      }
      if (ele.multiple) {
        resolve(files)
      } else {
        resolve(files[0])
      }
      document.body.removeChild(ele)
    }
    ele.click()
  })
}

/**
 * 图片选择器
 */
export function openImageChoose(multiple, maxCount) {
  return openFileChoose(multiple, 'image/*', maxCount)
}

/**
 * 视频选择器
 */
export function openVideoChoose(multiple, maxCount) {
  return openFileChoose(multiple, 'video/*', maxCount)
}

/**
 * 音频选择器
 */
export function openAudioChoose(multiple, maxCount) {
  return openFileChoose(multiple, 'audio/*', maxCount)
}

/**
 * 单个文件下载
 * @param {*} url
 * @param {*} fileName
 */
export function downloadFile(url, fileName) {
  saveAs(url, fileName)
}

/**
 * 根据resourceid下载单个文件
 * @param {*} resourceId
 * @param {*} fileName
 */
export function downloadFileByResourceId(resourceId, fileName) {
  saveAs(getResourceUrl(resourceId), fileName || resourceId)
}

/**
 * 文件打包下载
 * @param {*} fileArr 文件数组,包含url和fileName
 * @param {*} zipName
 */
export async function downloadZiP(fileArr = [], zipName) {
  const zip = new JSZip()
  const errFile = []
  for (let i = 0; i < fileArr.length; i++) {
    const ele = fileArr[i]
    if (ele.url) {
      zip.file(ele.fileName || i + 1, await remoteUrl2Blob(ele.url), { binary: true })
    }
    errFile.push(ele)
  }
  const zipContent = await zip.generateAsync({ type: 'blob' })
  saveAs(zipContent, zipName)
  return errFile.length > 0 ? errFile : null
}

/**
 * 资源url转
 * @param {*} url
 */
export async function remoteUrl2Blob(url) {
  return new Promise(function(resolve) {
    JSZipUtils.getBinaryContent(url, function(err, data) {
      if (err) {
        resolve(null)
      } else {
        resolve(data)
      }
    })
  })
}
/**
 * 文件转base64
 * @param {File} file 文件流
 */
export function file2base64(file) {
  return new Promise(resolve => {
    const reader = new FileReader()
    reader.readAsDataURL(file)
    reader.onload = function(e) {
      resolve(e.target.result)
    }
  })
}

/**
 * 获取文件的md5
 * @param {*} file 文件对象
 */
export async function getFileMd5(file) {
  return new Promise(resolve => {
    const blobSlice = File.prototype.slice || File.prototype.mozSlice || File.prototype.webkitSlice
    const chunkSize = 1024 * 1024 * 5
    const chunks = Math.ceil(file.size / chunkSize)
    let currentChunk = 0
    const spark = new SparkMD5.ArrayBuffer()
    const fileReader = new FileReader()

    fileReader.onload = function(e) {
      spark.append(e.target.result)
      currentChunk++
      if (currentChunk < chunks) {
        loadNext()
      } else {
        resolve(spark.end())
      }
    }

    fileReader.onerror = function(error) {
      console.error(error)
      resolve(null)
    }

    function loadNext() {
      const start = currentChunk * chunkSize
      const end = ((start + chunkSize) >= file.size) ? file.size : start + chunkSize
      fileReader.readAsArrayBuffer(blobSlice.call(file, start, end))
    }
    loadNext()
  })
}

/**
 * base64 转 blob二进制文件
 * @param dataurl base64
 */
export function dataURLtoFile(dataurl, fileName) {
  const arr = dataurl.split(','); const mime = arr[0].match(/:(.*?);/)[1]
  const bstr = atob(arr[1]); let n = bstr.length; const u8arr = new Uint8Array(n)
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n)
  }
  const blob = new Blob([u8arr], { type: mime })
  const d = new Date()
  blob.name = fileName
  blob.lastModifiedDate = d
  blob.lastModified = d.getTime()
  blob.webkitRelativePath = ''
  return new File([blob], fileName, { type: mime })
}
/**
 * 获取文件缩略图
 * @param src 文件url
 * @param w 宽度
 * @param h 高度
 */
export function resizeImage(src, w, h) {
  return new Promise(resolve => {
    const canvas = document.createElement('canvas')
    const ctx = canvas.getContext('2d')
    const im = new Image()
    im.onload = function() {
      if (!w && !h) {
        w = this.width
        h = this.height
      } else if (!h) {
        h = w * this.height / this.width
      } else if (!w) {
        w = h * this.width / this.height
      }
      canvas.width = w
      canvas.height = h
      ctx.drawImage(im, 0, 0, w, h)
      resolve(canvas.toDataURL('image/png'))
    }
    im.src = src
  })
}
